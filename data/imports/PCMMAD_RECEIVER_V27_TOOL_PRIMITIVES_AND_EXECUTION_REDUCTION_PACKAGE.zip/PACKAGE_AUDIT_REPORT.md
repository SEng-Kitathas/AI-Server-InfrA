# V27 Tool Primitives and Execution Reduction Report

## Summary
This pass targeted the remaining dynamic looseness in the extracted tool-family modules and a smaller dict-handling seam in `execution_routes.py`.

## Changes
- added shared payload/result primitives module:
  - `pcmmad_receiver/lab_tool_primitives.py`
- migrated:
  - `lab_tools_browser.py`
  - `lab_tools_filesystem.py`
  - `lab_tools_execution.py`
  onto shared `ToolPayload` / `ToolResult` and shared payload coercion helpers
- reduced repeated local payload parsing helpers inside those modules
- reduced some direct dict-style job access in `execution_routes.py`
- lightly simplified mapping coercion in `control_plane_models.py` without weakening strict hydration

## Metrics

### Before
- `lab_tools_browser.py`: {'lines': 249, 'Any': 57, '.get(': 8}
- `lab_tools_filesystem.py`: {'lines': 223, 'Any': 30, '.get(': 11}
- `lab_tools_execution.py`: {'lines': 310, 'Any': 30, '.get(': 19}
- `execution_routes.py`: {'lines': 1354, 'Any': 23, '.get(': 46}
- `control_plane_models.py`: {'lines': 814, 'Any': 65, '.get(': 95}

### After
- `lab_tools_browser.py`: {'lines': 221, 'Any': 0, '.get(': 4}
- `lab_tools_filesystem.py`: {'lines': 202, 'Any': 0, '.get(': 8}
- `lab_tools_execution.py`: {'lines': 307, 'Any': 0, '.get(': 16}
- `execution_routes.py`: {'lines': 1359, 'Any': 24, '.get(': 35}
- `control_plane_models.py`: {'lines': 814, 'Any': 65, '.get(': 95}
- `lab_tool_primitives.py`: {'lines': 57, 'Any': 0, '.get(': 1}

## Interpretation
- the extracted tool-family modules no longer carry explicit `Any` in their local payload/result signatures
- repeated payload folklore was collapsed into one shared primitive layer
- `execution_routes.py` direct `.get(...)` pressure moved down again
- `control_plane_models.py` was not widened; it remained structurally stable while one coercion helper seam was simplified

## Verification
- package-wide `py_compile`: PASS
- stale bytecode excluded from the package
- bundle metadata regenerated for this package

## Honest remaining seams
- `execution_routes.py` still carries residual helper density
- `control_plane_models.py` still has strict-but-verbose hydration paths
- some dynamic plugin/router edges remain intentionally flexible and are not yet maximally elegant
