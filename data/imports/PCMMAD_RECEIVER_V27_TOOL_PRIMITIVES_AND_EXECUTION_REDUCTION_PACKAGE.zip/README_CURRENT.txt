PCMMAD Receiver V27 Tool Primitives and Execution Reduction package.
Compile-verified; stale bytecode excluded.
