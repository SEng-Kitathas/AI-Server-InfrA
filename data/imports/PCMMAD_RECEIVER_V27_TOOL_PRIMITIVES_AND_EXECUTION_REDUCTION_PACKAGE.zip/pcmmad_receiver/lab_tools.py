from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Callable

from context_engine import (
    BadPathError,
    ContextPlaneError,
    NotFoundError,
    extract_archive,
    get_index_cache_stats,
    inspect_archive,
    inspect_model,
    list_archives,
    list_files,
    list_models,
    project_root_path,
    read_file,
    rehydrate_context,
    search_files,
)
from execution_routes import (
    DEFAULT_STDERR_MAX_BYTES,
    DEFAULT_STDOUT_MAX_BYTES,
    DEFAULT_TIMEOUT_SECONDS,
    EXECUTION_MODES,
    MAX_OUTPUT_BYTES,
    MAX_TIMEOUT_SECONDS,
    _RUNNING,
    _finalize,
    _job_dir,
    _read_job,
    _request_optional_positive_int,
    _resolve_cwd,
    _tail_text,
    _write_job,
)
from lab_plugins import load_plugins
from lab_policy import evaluate_tool_call, policy_mode
from lab_schema_validation import validate_payload_schema
from lab_tools_browser import register_browser_tools
from lab_tools_execution import register_execution_tools
from lab_tools_filesystem import register_filesystem_tools
from lab_tools_project import register_project_tools
from lab_tools_state import register_state_tools
from lab_tools_research import register_research_tools
from lab_tools_ops import register_ops_tools
from lab_tools_sop import register_sop_tools
from lab_results import get_result, store_result, summarize_payload
from lab_state import (
    append_reflexion,
    append_session_note,
    end_session,
    get_session,
    pull_andon,
    read_reflexion,
    start_session,
)
from shared_core import TEXT_EXTENSIONS, ensure_parent, get_mount_roots, get_project_root, init_project_layout, mount_summary, resolve_mount_spec, sha256_file, utc_now, validate_project_id
from sop_ingest import (
    ack_chunk as sop_ack_chunk,
    complete_file as sop_complete_file,
    guard_check as sop_guard_check,
    ingestion_status as sop_ingestion_status,
    inspect_package as sop_inspect_package,
    next_chunk as sop_next_chunk,
    register_package as sop_register_package,
    reset_ingestion as sop_reset_ingestion,
)
from control_plane_models import (CapabilityFamilyCard, CompactControlSurfaceDescriptor,
                                  PluginLoadRecord, ServerCapabilityRouterDescriptor,
                                  ToolCatalogResponse, ToolResultEnvelope,
                                  ToolRouterValidationState, ToolSpec)

try:
    from bs4 import BeautifulSoup
except Exception:  # pragma: no cover
    BeautifulSoup = None


class LabToolError(Exception):
    def __init__(self, error_code: str, message: str, status: int = 400, **extra: Any) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.message = message
        self.status = status
        self.extra = extra


_TOOL_REGISTRY: dict[str, ToolSpec] = {}
_PLUGIN_LOADS: list[PluginLoadRecord] = []
_PLUGIN_ERRORS: list[str] = []
_BASE_DIR = Path(__file__).resolve().parent
_TEXT_EXTENSIONS = {ext.lower() for ext in TEXT_EXTENSIONS}
_DEFAULT_GREP_MAX_FILE_BYTES = 2 * 1024 * 1024


def register_tool(
    name: str,
    description: str,
    danger_tier: str = "medium",
    *,
    category: str = "general",
    tags: list[str] | None = None,
    approval_required: bool = False,
    mutating: bool = False,
    input_schema: dict[str, Any] | None = None,
):
    def deco(fn: Callable[[dict[str, Any]], dict[str, Any]]):
        _TOOL_REGISTRY[name] = ToolSpec(
            name=name,
            description=description,
            danger_tier=danger_tier,
            category=category,
            tags=list(tags or []),
            approval_required=approval_required,
            mutating=mutating,
            input_schema=input_schema or {"type": "object"},
            handler=fn,
        )
        return fn

    return deco


def _safe_tool_card(item: ToolSpec) -> dict[str, Any]:
    return item.to_card()


def list_tools() -> list[dict[str, Any]]:
    return [_TOOL_REGISTRY[name].to_card() for name in sorted(_TOOL_REGISTRY)]


def capability_families() -> list[CapabilityFamilyCard]:
    buckets: dict[str, list[ToolSpec]] = {}
    for spec in _TOOL_REGISTRY.values():
        buckets.setdefault(spec.category or "general", []).append(spec)
    families: list[CapabilityFamilyCard] = []
    for name in sorted(buckets):
        specs = buckets[name]
        tag_set = sorted({tag for spec in specs for tag in spec.tags})
        danger_tiers = sorted({str(spec.danger_tier) for spec in specs})
        families.append(
            CapabilityFamilyCard(
                name=name,
                tool_count=len(specs),
                mutating_tools=sum(1 for spec in specs if spec.mutating),
                approval_required_tools=sum(1 for spec in specs if spec.approval_required),
                danger_tiers=danger_tiers,
                tags=tag_set,
            )
        )
    return families


def compact_control_surface_descriptor(*, operation_budget: int = 30, action_count: int = 30) -> CompactControlSurfaceDescriptor:
    return CompactControlSurfaceDescriptor(
        operation_budget=operation_budget,
        action_count=action_count,
        purpose="Compact GPT-safe control surface with bounded imported actions.",
        note="Schema ceilings are not server ceilings. Use lab dispatch, batch, and result-handle flows to reach larger server-native capability families.",
    )


def server_native_router_descriptor() -> ServerCapabilityRouterDescriptor:
    return ServerCapabilityRouterDescriptor(
        dispatch_entrypoint="/lab/dispatch",
        batch_entrypoint="/lab/batch",
        result_handle_entrypoint="/lab/results/get",
        larger_server_native_capability_set=True,
        families=capability_families(),
        notes=[
            "The compact schema is intentionally bounded to preserve GPT import compatibility.",
            "The server-native capability set can remain richer than the imported action surface.",
            "Large results may be materialized server-side and retrieved by handle.",
        ],
    )


def tool_catalog_response(*, operation_budget: int = 30, action_count: int = 30) -> ToolCatalogResponse:
    tools = [_TOOL_REGISTRY[name].to_card() for name in sorted(_TOOL_REGISTRY)]
    return ToolCatalogResponse(
        ok=True,
        count=len(tools),
        tools=tools,
        compact_control_surface=compact_control_surface_descriptor(
            operation_budget=operation_budget,
            action_count=action_count,
        ),
        server_native_router=server_native_router_descriptor(),
        validation=_tool_router_validation_state(),
    )



def _load_plugins() -> None:
    global _PLUGIN_LOADS, _PLUGIN_ERRORS
    _PLUGIN_LOADS = []
    _PLUGIN_ERRORS = []
    try:
        _PLUGIN_LOADS = load_plugins(_BASE_DIR, register_tool)
    except Exception as e:
        _PLUGIN_ERRORS.append(str(e))


_load_plugins()


def _tool_validation_mode() -> str:
    mode = os.environ.get("PCMMAD_TOOL_VALIDATION_MODE", "connected_only").strip().lower()
    if mode not in {"connected_only", "strict"}:
        return "connected_only"
    return mode


def _tool_router_validation_state() -> ToolRouterValidationState:
    connected = bool(_TOOL_REGISTRY)
    api_valid = connected
    reason = None
    if not connected:
        reason = "Tool router has no registered tools."
    return ToolRouterValidationState(
        api_valid=api_valid,
        connected=connected,
        validation_mode=_tool_validation_mode(),
        checked_at=utc_now(),
        reason=reason,
    )



def _raise_validation_error(code: str, message: str, status: int) -> None:
    raise LabToolError(code, message, status)


def _validate_payload_schema(tool_name: str, schema: dict[str, Any] | None, payload: dict[str, Any]) -> None:
    validate_payload_schema(tool_name, schema, payload, raise_error=_raise_validation_error)


def dispatch_tool(tool_name: str, payload: dict[str, Any] | None) -> dict[str, Any]:
    router_validation = _tool_router_validation_state()
    if not router_validation.api_valid or not router_validation.connected:
        raise LabToolError(
            "API_NOT_CONNECTED",
            "Tool router is not connected/valid.",
            503,
            validation=router_validation.to_dict(),
        )
    spec = _TOOL_REGISTRY.get(tool_name)
    if not spec:
        raise LabToolError("UNKNOWN_TOOL", f"Unknown tool: {tool_name}", 404, available_tools=[t["name"] for t in list_tools()])
    payload = payload or {}
    if router_validation.validation_mode == "strict":
        _validate_payload_schema(tool_name, spec.input_schema, payload)
    decision = evaluate_tool_call(spec, payload)
    if not decision.allowed:
        raise LabToolError(
            "APPROVAL_REQUIRED",
            decision.reason,
            403,
            tool=tool_name,
            policy_mode=decision.mode,
            danger_tier=spec.danger_tier,
        )
    if spec.handler is None:
        raise LabToolError("BAD_TOOL_HANDLER", f"Tool {tool_name} has no handler", 500)
    result = spec.handler(payload)
    if not isinstance(result, dict):
        raise LabToolError("BAD_TOOL_RESULT", f"Tool {tool_name} returned non-object result", 500)
    result = _maybe_offload_large_result(tool_name, payload, result)
    envelope = ToolResultEnvelope(
        ok=True,
        tool=tool_name,
        danger_tier=spec.danger_tier,
        policy_mode=decision.mode,
        approved=decision.approved,
        time=utc_now(),
        result=result,
        warning=decision.warning,
    )
    return envelope.to_dict()


def _normalize_project_path(payload: dict[str, Any]) -> str:
    p = payload.get("path")
    return "." if not p else str(p)


def _context_wrap(fn: Callable[[], dict[str, Any]]) -> dict[str, Any]:
    try:
        return fn()
    except BadPathError as e:
        raise LabToolError(e.error_code, str(e), 400)
    except NotFoundError as e:
        raise LabToolError(e.error_code, str(e), 404)
    except ContextPlaneError as e:
        raise LabToolError(e.error_code, str(e), 400)


def _exec_env(payload: dict[str, Any]) -> dict[str, str]:
    env = os.environ.copy()
    for k, v in (payload.get("env") or payload.get("env_allowlist") or {}).items():
        if isinstance(k, str) and isinstance(v, str):
            env[k] = v
    return env


def _read_required_project_id(payload: dict[str, Any]) -> str:
    project_id = str(payload.get("project_id", "")).strip()
    if not project_id:
        raise LabToolError("BAD_REQUEST", "project_id is required", 400)
    return validate_project_id(project_id)


def _ensure_project_layout(payload: dict[str, Any]) -> str:
    project_id = _read_required_project_id(payload)
    init_project_layout(project_id)
    return project_id


def _read_text_preview(path: Path, max_bytes: int) -> tuple[str, bool, int]:
    if max_bytes <= 0:
        raise ValueError('max_bytes must be positive')
    with path.open('rb') as handle:
        data = handle.read(max_bytes + 1)
    truncated = len(data) > max_bytes
    if truncated:
        data = data[:max_bytes]
    return data.decode('utf-8', errors='replace'), truncated, path.stat().st_size


def _iter_text_lines_bounded(path: Path, max_scan_bytes: int):
    bytes_seen = 0
    with path.open('r', encoding='utf-8', errors='replace') as handle:
        for line in handle:
            bytes_seen += len(line.encode('utf-8', errors='replace'))
            if bytes_seen > max_scan_bytes:
                return bytes_seen, True
            yield line.rstrip('\n'), bytes_seen
    return bytes_seen, False


def _stream_grep(path: Path, query: str, limit: int, max_file_bytes: int) -> tuple[list[dict[str, Any]], bool, bool]:
    hits: list[dict[str, Any]] = []
    lowered = query.lower()
    iterator = _iter_text_lines_bounded(path, max_file_bytes)
    partial_scan = False
    skipped_oversized = False
    line_number = 0
    try:
        while True:
            item = next(iterator)
            if not isinstance(item, tuple) or len(item) != 2:
                continue
            line_number += 1
            line, _ = item
            if lowered in line.lower():
                hits.append({"path": str(path), "line": line_number, "text": line[:500]})
                if len(hits) >= limit:
                    partial_scan = True
                    break
    except StopIteration as stop:
        result = stop.value
        if isinstance(result, tuple) and len(result) == 2:
            _, skipped_oversized = result
    return hits, partial_scan, skipped_oversized


def _bounded_zip_entry_text(zf: zipfile.ZipFile, name: str, max_entry_bytes: int) -> dict[str, Any]:
    info = zf.getinfo(name)
    if info.is_dir():
        return {"ok": False, "entry_name": str(name), "error": "entry is a directory"}
    with zf.open(info, 'r') as handle:
        data = handle.read(max_entry_bytes + 1)
    truncated = len(data) > max_entry_bytes or info.file_size > max_entry_bytes
    if truncated:
        data = data[:max_entry_bytes]
    return {
        "ok": True,
        "entry_name": str(name),
        "bytes": len(data),
        "original_bytes": info.file_size,
        "truncated": truncated,
        "content": data.decode('utf-8', errors='replace'),
    }


def _resolve_general_path(payload: dict[str, Any], key: str = "path") -> Path:
    project_id = str(payload.get("project_id", "")).strip() or None
    path_raw = str(payload.get(key, "")).strip()
    if not path_raw:
        raise LabToolError("BAD_REQUEST", f"{key} is required", 400)
    try:
        default_root = get_project_root(project_id) if project_id else None
        return resolve_mount_spec(path_raw, default_root=default_root, allow_absolute=True)
    except Exception as e:
        raise LabToolError("BAD_PATH", str(e), 400)


def _ensure_within_allowed(path: Path) -> Path:
    allowed = [p.resolve() for p in get_mount_roots()]
    resolved = path.resolve()
    if not any(root == resolved or root in resolved.parents for root in allowed):
        raise LabToolError("BAD_PATH", "resolved path escapes mounted roots", 400, mounts=mount_summary())
    return resolved


def _bridge_base_url() -> str:
    return os.environ.get("PCMMAD_BROWSER_BRIDGE_URL", "http://127.0.0.1:4471").rstrip("/")


def _bridge_call(method: str, path: str, payload: dict[str, Any] | None = None, timeout_seconds: int = 30) -> dict[str, Any]:
    url = _bridge_base_url() + path
    data = None
    headers = {"Content-Type": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, headers=headers, data=data, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read()
            text = raw.decode("utf-8", errors="replace")
            try:
                return json.loads(text) if text else {"ok": True}
            except Exception:
                return {"ok": True, "raw": text, "status": getattr(resp, "status", 200)}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise LabToolError("BROWSER_BRIDGE_HTTP_ERROR", f"{e.code}: {body}", e.code)
    except Exception as e:
        raise LabToolError("BROWSER_BRIDGE_UNAVAILABLE", str(e), 502, base_url=_bridge_base_url())


def _bounded_payload_int(
    payload: dict[str, Any],
    key: str,
    *,
    default: int,
    minimum: int,
    maximum: int,
) -> int:
    raw = payload.get(key, default)
    try:
        value = int(raw)
    except Exception as exc:
        raise LabToolError("BAD_REQUEST", f"{key} must be an integer", 400) from exc
    return max(minimum, min(value, maximum))


def _bridge_payload_subset(payload: dict[str, Any], fields: tuple[str, ...] | list[str]) -> dict[str, Any]:
    return {field: payload[field] for field in fields if field in payload}


def _bridge_timeout(
    payload: dict[str, Any],
    *,
    default: int,
    maximum: int,
    key: str = "timeout_seconds",
) -> int:
    return _bounded_payload_int(payload, key, default=default, minimum=1, maximum=maximum)


def _bridge_browser_post(
    payload: dict[str, Any],
    endpoint: str,
    *,
    fields: tuple[str, ...] | list[str],
    timeout_default: int = 30,
    timeout_max: int = 120,
) -> dict[str, Any]:
    return _bridge_call(
        "POST",
        endpoint,
        _bridge_payload_subset(payload, fields),
        _bridge_timeout(payload, default=timeout_default, maximum=timeout_max),
    )


def _bridge_browser_get(
    endpoint: str,
    payload: dict[str, Any],
    *,
    timeout_default: int = 10,
    timeout_max: int = 30,
) -> dict[str, Any]:
    return _bridge_call(
        "GET",
        endpoint,
        None,
        _bridge_timeout(payload, default=timeout_default, maximum=timeout_max),
    )


def _maybe_offload_large_result(tool_name: str, payload: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
    project_id = str(payload.get("project_id", "")).strip()
    force = bool(payload.get("store_result", False))
    try:
        raw = json.dumps(result, ensure_ascii=False)
    except Exception:
        return result
    threshold = int(payload.get("result_handle_threshold_chars", 12000))
    if project_id and (force or len(raw) > threshold):
        meta = store_result(project_id, result, label=str(payload.get("result_label", tool_name)), tool_name=tool_name)
        return {
            "stored": True,
            "handle": meta["handle"],
            "bytes": meta["bytes"],
            "sha256": meta["sha256"],
            "summary": summarize_payload(result),
        }
    return result




def _sop_call(fn: Callable[..., dict[str, Any]], *args: Any, **kwargs: Any) -> dict[str, Any]:
    try:
        return fn(*args, **kwargs)
    except SopError as e:
        raise LabToolError(e.code, e.message, 400, **e.extra)




register_state_tools(
    register_tool,
    error_cls=LabToolError,
    tool_router_validation_state=_tool_router_validation_state,
    policy_mode=policy_mode,
    plugin_loads=_PLUGIN_LOADS,
    plugin_errors=_PLUGIN_ERRORS,
    beautiful_soup=BeautifulSoup,
    bridge_call=_bridge_call,
    enabled_sources=ENABLED_SOURCES,
    enabled_hunt_modes=ENABLED_HUNT_MODES,
    parser_version=PARSER_VERSION,
    get_cache_stats=get_cache_stats,
    get_index_cache_stats=get_index_cache_stats,
    execution_modes=EXECUTION_MODES,
    tool_registry=_TOOL_REGISTRY,
    load_plugins=_load_plugins,
    ensure_project_layout=_ensure_project_layout,
    running_jobs=_RUNNING,
    get_project_root=get_project_root,
    append_reflexion=append_reflexion,
    append_session_note=append_session_note,
    end_session=end_session,
    get_session=get_session,
    pull_andon=pull_andon,
    read_reflexion=read_reflexion,
    start_session=start_session,
    utc_now=utc_now,
)

register_project_tools(
    register_tool,
    error_cls=LabToolError,
    context_wrap=_context_wrap,
    normalize_project_path=_normalize_project_path,
    project_root_path=project_root_path,
    list_files=list_files,
    read_file=read_file,
    search_files=search_files,
    rehydrate_context=rehydrate_context,
    list_models=list_models,
    inspect_model=inspect_model,
    list_archives=list_archives,
    inspect_archive=inspect_archive,
    extract_archive=extract_archive,
    ensure_project_layout=_ensure_project_layout,
    get_project_root=get_project_root,
    ensure_parent=ensure_parent,
    sha256_file=sha256_file,
    utc_now=utc_now,
    request_optional_positive_int=_request_optional_positive_int,
    ensure_within_allowed=_ensure_within_allowed,
    resolve_general_path=_resolve_general_path,
    bounded_zip_entry_text=_bounded_zip_entry_text,
    iter_tree=lambda *args, **kwargs: __import__("power_routes")._iter_tree(*args, **kwargs),
)


register_execution_tools(
    register_tool,
    error_cls=LabToolError,
    request_optional_positive_int=_request_optional_positive_int,
    resolve_cwd=_resolve_cwd,
    exec_env=_exec_env,
    finalize_job=_finalize,
    read_job=_read_job,
    tail_text=_tail_text,
    execution_modes=EXECUTION_MODES,
    max_output_bytes=MAX_OUTPUT_BYTES,
    default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
    default_stdout_max_bytes=DEFAULT_STDOUT_MAX_BYTES,
    default_stderr_max_bytes=DEFAULT_STDERR_MAX_BYTES,
    max_timeout_seconds=MAX_TIMEOUT_SECONDS,
    running_jobs=_RUNNING,
    job_dir=_job_dir,
    write_job=_write_job,
    utc_now=utc_now,
)

register_ops_tools(
    register_tool,
    error_cls=LabToolError,
    get_project_root=get_project_root,
    resolve_cwd=_resolve_cwd,
    exec_env=_exec_env,
    append_reflexion=append_reflexion,
    beautiful_soup=BeautifulSoup,
)

register_research_tools(
    register_tool,
    error_cls=LabToolError,
)

register_filesystem_tools(
    register_tool,
    error_cls=LabToolError,
    resolve_general_path=_resolve_general_path,
    ensure_within_allowed=_ensure_within_allowed,
    request_optional_positive_int=_request_optional_positive_int,
    read_text_preview=_read_text_preview,
    stream_grep=_stream_grep,
    text_extensions=_TEXT_EXTENSIONS,
    default_grep_max_file_bytes=_DEFAULT_GREP_MAX_FILE_BYTES,
    mount_summary=mount_summary,
    get_project_root=get_project_root,
    resolve_mount_spec=resolve_mount_spec,
)

register_sop_tools(
    register_tool,
    error_cls=LabToolError,
    read_required_project_id=_read_required_project_id,
    ensure_project_layout=_ensure_project_layout,
    resolve_general_path=_resolve_general_path,
    sop_call=_sop_call,
    sop_inspect_package=sop_inspect_package,
    sop_register_package=sop_register_package,
    sop_reset_ingestion=sop_reset_ingestion,
    sop_ingestion_status=sop_ingestion_status,
    sop_next_chunk=sop_next_chunk,
    sop_ack_chunk=sop_ack_chunk,
    sop_complete_file=sop_complete_file,
    sop_guard_check=sop_guard_check,
)

register_browser_tools(
    register_tool,
    bridge_call=_bridge_call,
    bridge_payload_subset=_bridge_payload_subset,
    bridge_timeout=_bridge_timeout,
    error_cls=LabToolError,
)
