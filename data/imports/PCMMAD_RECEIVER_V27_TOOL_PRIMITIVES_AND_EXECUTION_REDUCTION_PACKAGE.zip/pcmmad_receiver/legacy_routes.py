from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from flask import Blueprint, jsonify, request

from control_plane_models import CommitLedgerRecord, ManifestDocument, ManifestEntryRecord
from execution_routes import execution_capabilities
from api_wire_models import CompactCapabilitiesResponse
from lab_tools import compact_control_surface_descriptor, server_native_router_descriptor
from shared_core import (
    ALLOWED_OPERATIONS,
    APPEND_ALLOWED_CLASSES,
    ARTIFACT_RELATIVE_MAP,
    PROJECTS_ROOT,
    ROOT,
    append_jsonl,
    capabilities,
    commits_ledger_path_for,
    ensure_parent,
    get_project_root,
    idempotency_path_for,
    init_project_layout,
    load_json,
    manifest_path_for,
    require_valid_api_key,
    resolve_target,
    save_json_atomic,
    sha256_bytes, sha256_file,
    sha256_text,
    utc_now,
)

legacy_bp = Blueprint("legacy", __name__, url_prefix="")


def error_response(error_code: str, message: str, status: int, **extra: Any):
    payload = {"ok": False, "error_code": error_code, "message": message, "time": utc_now()}
    payload.update(extra)
    return jsonify(payload), status


def require_api_key():
    try:
        require_valid_api_key(request.headers)
        return None
    except Exception as e:
        return error_response("UNAUTHORIZED", str(e), 401)


def get_request_json():
    data = request.get_json(silent=False, force=True)
    if not isinstance(data, dict):
        raise ValueError("JSON request body must be an object")
    return data


def get_manifest(project_id: str) -> ManifestDocument:
    raw = load_json(manifest_path_for(project_id), {"updated_at": None, "files": {}})
    return ManifestDocument.from_dict(raw if isinstance(raw, dict) else {})


def save_manifest(project_id: str, manifest: ManifestDocument) -> None:
    manifest.updated_at = utc_now()
    save_json_atomic(manifest_path_for(project_id), manifest.to_dict())


def update_manifest_entry(project_id: str, target: Path, artifact_class: str, sha256: str, size_bytes: int) -> None:
    manifest = get_manifest(project_id)
    rel = str(target.relative_to(get_project_root(project_id)))
    manifest.files[rel] = ManifestEntryRecord(
        artifact_class=artifact_class,
        sha256=sha256,
        bytes=size_bytes,
        updated_at=utc_now(),
    )
    save_manifest(project_id, manifest)


def get_idempotency(project_id: str) -> dict[str, CommitLedgerRecord]:
    raw = load_json(idempotency_path_for(project_id), {})
    if not isinstance(raw, dict):
        return {}
    out: dict[str, CommitLedgerRecord] = {}
    for key, value in raw.items():
        if isinstance(key, str) and isinstance(value, dict):
            out[key] = CommitLedgerRecord.from_dict(value)
    return out


def save_idempotency(project_id: str, data: dict[str, CommitLedgerRecord]) -> None:
    save_json_atomic(idempotency_path_for(project_id), {k: v.to_dict() for k, v in data.items()})


def validate_operation_semantics(operation: str, artifact_class: str, target: Path):
    exists = target.exists()
    if operation == "create" and exists:
        raise ValueError("create is not allowed when target already exists")
    if operation == "update" and not exists:
        raise ValueError("update is not allowed when target does not exist")
    if operation == "append":
        if artifact_class not in APPEND_ALLOWED_CLASSES:
            raise ValueError(f"append is not allowed for artifact_class: {artifact_class}")
        if not exists:
            raise ValueError("append is not allowed when target does not exist")


def get_existing_sha(target: Path) -> str | None:
    if target.exists() and target.is_file():
        return sha256_file(target)
    return None



def _find_commit_record(project_id: str, commit_id: str) -> CommitLedgerRecord | None:
    records_path = commits_ledger_path_for(project_id)
    if not records_path.exists():
        return None
    import json as _json
    with records_path.open("r", encoding="utf-8") as f:
        for line in f:
            try:
                raw = _json.loads(line)
            except Exception:
                continue
            if isinstance(raw, dict) and raw.get("commit_id") == commit_id:
                return CommitLedgerRecord.from_dict(raw)
    return None


@legacy_bp.get("/health")
def health():
    ae = require_api_key()
    if ae:
        return ae
    exec_caps = {}
    try:
        exec_caps = execution_capabilities()
    except Exception:
        exec_caps = {}
    return jsonify(
        {
            "ok": True,
            "status": "online",
            "root": str(ROOT),
            "projects_root": str(PROJECTS_ROOT),
            "time": utc_now(),
            "artifact_classes": sorted(ARTIFACT_RELATIVE_MAP.keys()),
            "capabilities": capabilities(),
            "compact_control_surface": compact_control_surface_descriptor(operation_budget=30, action_count=30).to_dict(),
            "server_native_router": server_native_router_descriptor().to_dict(),
            **exec_caps,
        }
    )


@legacy_bp.get("/capabilities")
def get_capabilities():
    ae = require_api_key()
    if ae:
        return ae
    envelope = CompactCapabilitiesResponse(
        ok=True,
        time=utc_now(),
        capabilities=capabilities(),
        limits={
            "default_read_max_bytes": 50000,
            "default_rehydrate_budget_bytes": 40000,
            "default_search_limit": 30,
            "default_list_limit": 200,
            "default_tree_limit": 500,
            "default_batch_steps": 30,
            **execution_capabilities(),
        },
        compact_control_surface=compact_control_surface_descriptor(operation_budget=30, action_count=30),
        server_native_router=server_native_router_descriptor(),
    )
    return jsonify(envelope.to_dict())


@legacy_bp.post("/project/init")
def project_init():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
        project_id = d.get("project_id", "")
        root = init_project_layout(project_id)
        return jsonify({"ok": True, "project_id": project_id, "project_root": str(root), "created": True})
    except Exception as e:
        return error_response("PROJECT_INIT_FAILED", str(e), 400)


@legacy_bp.post("/project/info")
def project_info():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
        project_id = d.get("project_id", "")
        root = get_project_root(project_id)
        return jsonify(
            {
                "ok": True,
                "project_id": project_id,
                "project_root": str(root),
                "exists": root.exists(),
                "manifest_exists": manifest_path_for(project_id).exists(),
                "ledger_exists": commits_ledger_path_for(project_id).exists(),
            }
        )
    except Exception as e:
        return error_response("PROJECT_INFO_FAILED", str(e), 400)


@legacy_bp.post("/project/manifest")
def project_manifest():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
        project_id = d.get("project_id", "")
        return jsonify({"ok": True, "project_id": project_id, **get_manifest(project_id).to_dict()})
    except Exception as e:
        return error_response("BAD_PROJECT", str(e), 400)


@legacy_bp.post("/project/status")
def project_status_alias():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
        project_id = d.get("project_id", "")
        commit_id = d.get("commit_id", "")
        record = _find_commit_record(project_id, commit_id)
        if record is None:
            return error_response("NOT_FOUND", "commit not found", 404)
        return jsonify({"ok": True, **record.to_dict()})
    except Exception as e:
        return error_response("COMMIT_STATUS_FAILED", str(e), 400)


@legacy_bp.get("/manifest")
def manifest():
    ae = require_api_key()
    if ae:
        return ae
    project_id = request.args.get("project_id", "")
    try:
        return jsonify({"ok": True, "project_id": project_id, **get_manifest(project_id).to_dict()})
    except Exception as e:
        return error_response("BAD_PROJECT", str(e), 400)


@legacy_bp.get("/status/<commit_id>")
def get_commit_status(commit_id: str):
    ae = require_api_key()
    if ae:
        return ae
    project_id = request.args.get("project_id", "")
    try:
        record = _find_commit_record(project_id, commit_id)
        if record is None:
            return error_response("NOT_FOUND", "commit not found", 404)
        return jsonify({"ok": True, **record.to_dict()})
    except Exception as e:
        return error_response("COMMIT_STATUS_FAILED", str(e), 400)


@legacy_bp.post("/plan")
def plan():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
    except Exception as e:
        return error_response("BAD_JSON", str(e), 400)
    project_id = d.get("project_id")
    artifact_class = d.get("artifact_class")
    logical_name = d.get("logical_name")
    operation = d.get("operation")
    content = d.get("content", "")
    provided_sha = d.get("sha256")
    expected_previous_sha = d.get("expected_previous_sha256")
    if operation not in ALLOWED_OPERATIONS:
        return error_response("BAD_OPERATION", f"Unsupported operation: {operation}", 400)
    try:
        init_project_layout(project_id)
        target = resolve_target(project_id, artifact_class, logical_name)
    except Exception as e:
        return error_response("BAD_TARGET", str(e), 400)
    try:
        validate_operation_semantics(operation, artifact_class, target)
    except Exception as e:
        return error_response("BAD_OPERATION_SEMANTICS", str(e), 400)
    current_sha = get_existing_sha(target)
    if expected_previous_sha and current_sha != expected_previous_sha:
        return error_response(
            "HASH_MISMATCH",
            "expected_previous_sha256 did not match existing file",
            409,
            current_sha256=current_sha,
        )
    computed_sha = sha256_text(content)
    if provided_sha and provided_sha != computed_sha:
        return error_response("CONTENT_HASH_INVALID", "Provided sha256 does not match content", 400)
    return jsonify(
        {
            "ok": True,
            "validated": {
                "project_id": project_id,
                "artifact_class": artifact_class,
                "logical_name": logical_name,
                "operation": operation,
                "target_path": str(target),
                "exists": target.exists(),
                "current_sha256": current_sha,
                "incoming_sha256": computed_sha,
            },
        }
    )


@legacy_bp.post("/commit")
def commit():
    ae = require_api_key()
    if ae:
        return ae
    try:
        d = get_request_json()
    except Exception as e:
        return error_response("BAD_JSON", str(e), 400)
    project_id = d.get("project_id")
    session_id = d.get("session_id")
    commit_id = d.get("commit_id")
    idempotency_key = d.get("idempotency_key")
    artifact_class = d.get("artifact_class")
    logical_name = d.get("logical_name")
    operation = d.get("operation")
    content = d.get("content", "")
    expected_previous_sha = d.get("expected_previous_sha256")
    if not project_id or not session_id or not commit_id or not idempotency_key:
        return error_response("BAD_REQUEST", "Missing project_id, session_id, commit_id, or idempotency_key", 400)
    if operation not in ALLOWED_OPERATIONS:
        return error_response("BAD_OPERATION", f"Unsupported operation: {operation}", 400)

    init_project_layout(project_id)
    idem = get_idempotency(project_id)
    if idempotency_key in idem:
        return jsonify({"ok": True, "replayed": True, **idem[idempotency_key].to_dict()})

    try:
        target = resolve_target(project_id, artifact_class, logical_name)
    except Exception as e:
        return error_response("BAD_TARGET", str(e), 400)
    try:
        validate_operation_semantics(operation, artifact_class, target)
    except Exception as e:
        return error_response("BAD_OPERATION_SEMANTICS", str(e), 400)
    current_sha = get_existing_sha(target)
    if expected_previous_sha and current_sha != expected_previous_sha:
        return error_response(
            "HASH_MISMATCH",
            "expected_previous_sha256 did not match existing file",
            409,
            current_sha256=current_sha,
        )

    ensure_parent(target)
    if operation == "append":
        with target.open("a", encoding="utf-8") as handle:
            handle.write(content)
    else:
        with tempfile.NamedTemporaryFile("w", delete=False, dir=target.parent, encoding="utf-8") as tmp:
            tmp.write(content)
            tmp_path = Path(tmp.name)
        tmp_path.replace(target)

    final_sha = sha256_file(target)
    size_bytes = target.stat().st_size
    update_manifest_entry(project_id, target, artifact_class, final_sha, size_bytes)
    record = CommitLedgerRecord(
        project_id=project_id,
        session_id=session_id,
        commit_id=commit_id,
        idempotency_key=idempotency_key,
        artifact_class=artifact_class,
        logical_name=logical_name,
        operation=operation,
        path=str(target.relative_to(get_project_root(project_id))),
        sha256=final_sha,
        bytes=size_bytes,
        time=utc_now(),
    )
    append_jsonl(commits_ledger_path_for(project_id), record)
    idem[idempotency_key] = record
    save_idempotency(project_id, idem)
    return jsonify({"ok": True, "replayed": False, **record.to_dict()})
