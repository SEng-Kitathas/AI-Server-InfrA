from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import atexit
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from flask import Blueprint, jsonify, request
from runtime_config import EXECUTION_CONFIG
from control_plane_models import (
    CapacitySnapshot,
    CorruptJobFileRecord,
    ExecutionCapabilitiesEnvelope,
    ExecutionFailureDigest,
    ExecutionIdempotencyLedger,
    ExecutionIdempotencyRecord,
    ExecutionJobRecord,
    ExecutionReadinessEnvelope,
    ExecutionRegistrationRecord,
    ExecutionSubmitPayload,
    GlobalExecutionSnapshot,
    SchedulerTelemetry,
    TextWindow,
)
from api_wire_models import (
    ExecutionListRequest,
    ExecutionListResponse,
    ExecutionOutputRequest,
    ExecutionOutputResponse,
    ExecutionRegisterRequest,
    ExecutionRegisterResponse,
    ExecutionReplayRequest,
    ExecutionStatusRequest,
    ExecutionStatusResponse,
    ExecutionTerminateRequest,
)
from shared_core import (
    PROJECTS_ROOT,
    commits_ledger_path_for,
    ensure_parent,
    get_project_root,
    load_json,
    manifest_path_for,
    require_valid_api_key,
    resolve_target,
    save_json_atomic,
    sha256_file,
    utc_now,
    append_jsonl,
)

execution_bp = Blueprint("execution", __name__, url_prefix="/project/execution")
_RUNNING: dict[str, subprocess.Popen[bytes]] = {}
_RUNNING_LOCK = threading.RLock()
_ADMISSION_LOCK = threading.RLock()

DEFAULT_TIMEOUT_SECONDS = EXECUTION_CONFIG.default_timeout_seconds
MAX_TIMEOUT_SECONDS = EXECUTION_CONFIG.max_timeout_seconds
DEFAULT_STDOUT_MAX_BYTES = EXECUTION_CONFIG.default_stdout_max_bytes
DEFAULT_STDERR_MAX_BYTES = EXECUTION_CONFIG.default_stderr_max_bytes
MAX_OUTPUT_BYTES = EXECUTION_CONFIG.max_output_bytes
DEFAULT_LIST_LIMIT = 20

EXECUTION_MODES = ["one_shot", "bench", "replay", "ablation"]


def _env_optional_positive_int(name: str, default: int | None) -> int | None:
    raw = str(os.environ.get(name, "" if default is None else default)).strip().lower()
    if raw in {"", "none"}:
        return default
    if raw in {"0", "-1", "unbounded", "unlimited", "inf", "infinite"}:
        return None
    value = int(raw)
    return None if value <= 0 else value


def _request_optional_positive_int(value: Any, default: int | None, *, minimum: int = 0, maximum: int | None = None) -> int | None:
    if value is None or value == "":
        return default
    raw = str(value).strip().lower()
    if raw in {"0", "-1", "none", "unbounded", "unlimited", "inf", "infinite"}:
        return None
    ivalue = int(value)
    if ivalue < minimum:
        ivalue = minimum
    if maximum is not None and ivalue > maximum:
        ivalue = maximum
    return ivalue


def _limit_for_wire(value: int | None) -> int:
    return 0 if value is None else int(value)


EXECUTION_GLOBAL_CONCURRENCY = EXECUTION_CONFIG.global_concurrency
EXECUTION_PROJECT_CONCURRENCY = EXECUTION_CONFIG.project_concurrency
EXECUTION_GLOBAL_QUEUE_LIMIT = EXECUTION_CONFIG.global_queue_limit
EXECUTION_PROJECT_QUEUE_LIMIT = EXECUTION_CONFIG.project_queue_limit
EXECUTION_DRAIN_BATCH = EXECUTION_CONFIG.drain_batch
EXECUTION_SCHEDULER_INTERVAL_SECONDS = EXECUTION_CONFIG.scheduler_interval_seconds
_SCHEDULER_THREAD: threading.Thread | None = None
_SCHEDULER_STOP = threading.Event()


JOB_STATUS_SUBMITTED = "SUBMITTED"
JOB_STATUS_QUEUED = "QUEUED"
JOB_STATUS_STARTING = "STARTING"
JOB_STATUS_RUNNING = "RUNNING"
JOB_STATUS_COMPLETED = "COMPLETED"
JOB_STATUS_FAILED = "FAILED"
JOB_STATUS_TERMINATED = "TERMINATED"
JOB_STATUS_HOST_PREEMPTED = "HOST_PREEMPTED"

JOB_ACTIVE_STATUSES = {JOB_STATUS_SUBMITTED, JOB_STATUS_QUEUED, JOB_STATUS_STARTING, JOB_STATUS_RUNNING}
JOB_TERMINAL_STATUSES = {JOB_STATUS_COMPLETED, JOB_STATUS_FAILED, JOB_STATUS_TERMINATED, JOB_STATUS_HOST_PREEMPTED}

_SCHEDULER_STATS_LOCK = threading.RLock()
_SCHEDULER_TELEMETRY = SchedulerTelemetry()


def _scheduler_stat_inc(name: str, amount: int = 1) -> None:
    with _SCHEDULER_STATS_LOCK:
        _SCHEDULER_TELEMETRY.inc(name, amount)


def _scheduler_stat_set(name: str, value: Any) -> None:
    with _SCHEDULER_STATS_LOCK:
        _SCHEDULER_TELEMETRY.set(name, value)


def _scheduler_snapshot() -> dict[str, Any]:
    with _SCHEDULER_STATS_LOCK:
        return _SCHEDULER_TELEMETRY.to_dict()


def _set_job_status(job: ExecutionJobRecord, status: str, stage: str) -> ExecutionJobRecord:
    job.status = status
    job.stage = stage
    return job



class ExecutionRequestError(Exception):
    def __init__(self, error_code: str, message: str, status: int = 400, **extra: Any) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.message = message
        self.status = status
        self.extra = extra


class ExecutionOverCapacity(ExecutionRequestError):
    def __init__(self, message: str, **extra: Any) -> None:
        super().__init__("EXECUTION_OVER_CAPACITY", message, 429, **extra)


def execution_capabilities():
    return ExecutionCapabilitiesEnvelope(
        execution_enabled=True,
        execution_modes=EXECUTION_MODES,
        max_timeout_seconds=_limit_for_wire(None),
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
        max_stdout_bytes=_limit_for_wire(None),
        max_stderr_bytes=_limit_for_wire(None),
        artifact_registration_enabled=True,
        termination_enabled=True,
        global_concurrency_limit=_limit_for_wire(EXECUTION_GLOBAL_CONCURRENCY),
        per_project_concurrency_limit=_limit_for_wire(EXECUTION_PROJECT_CONCURRENCY),
        global_queue_limit=_limit_for_wire(EXECUTION_GLOBAL_QUEUE_LIMIT),
        per_project_queue_limit=_limit_for_wire(EXECUTION_PROJECT_QUEUE_LIMIT),
        scheduler_interval_seconds=EXECUTION_SCHEDULER_INTERVAL_SECONDS,
        background_scheduler=True,
        scheduler_alive=bool(_SCHEDULER_THREAD and _SCHEDULER_THREAD.is_alive()),
    ).to_dict()


def _error(error_code, message, status, **extra):
    payload = {"ok": False, "error_code": error_code, "message": message, "time": utc_now()}
    payload.update(extra)
    return jsonify(payload), status


def _job_output_texts(job: dict[str, Any] | ExecutionJobRecord, max_bytes: int | None) -> tuple[str, bool, str, bool]:
    record = _job_record(job)
    stdout_text, stdout_truncated = _tail_text(Path(record.stdout_path), max_bytes)
    stderr_text, stderr_truncated = _tail_text(Path(record.stderr_path), max_bytes)
    return stdout_text, stdout_truncated, stderr_text, stderr_truncated


def _auth():
    try:
        require_valid_api_key(request.headers)
        return None
    except Exception as e:
        return _error("UNAUTHORIZED", str(e), 401)


def _jobs_dir(project_id):
    d = get_project_root(project_id) / "system" / "logs" / "execution"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _job_dir(project_id, job_id):
    d = _jobs_dir(project_id) / job_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _job_path(project_id, job_id):
    return _jobs_dir(project_id) / f"{job_id}.json"


def _read_job(project_id, job_id):
    p = _job_path(project_id, job_id)
    if not p.exists():
        raise FileNotFoundError("job not found")
    return ExecutionJobRecord.from_dict(json.loads(p.read_text(encoding="utf-8")))


def _write_job(project_id, job_id, job):
    payload = job.to_dict() if isinstance(job, ExecutionJobRecord) else job
    save_json_atomic(_job_path(project_id, job_id), payload)


def _resolve_cwd(project_id, cwd_path):
    root = get_project_root(project_id)
    path = cwd_path or "."
    candidate = (root / path).resolve()
    if root.resolve() not in [candidate, *candidate.parents]:
        raise ValueError("cwd_path escapes project root")
    return candidate




def _empty_text_window(*, mode: str, requested_bytes: int | None, offset_bytes: int | None = None) -> tuple[str, bool, TextWindow]:
    return "", False, TextWindow(mode=mode, file_size=0, requested_bytes=requested_bytes, returned_bytes=0, offset_bytes=offset_bytes)


def _read_range_text_window(path: Path, *, file_size: int, offset_bytes: int | None, max_bytes: int | None, length_bytes: int | None) -> tuple[str, bool, TextWindow]:
    start_offset = max(0, int(offset_bytes or 0))
    limit = length_bytes if length_bytes is not None else max_bytes
    if limit is None or limit <= 0:
        limit = max(1, file_size - start_offset)
    with path.open("rb") as handle:
        handle.seek(start_offset)
        data = handle.read(limit + 1)
    truncated = len(data) > limit or (start_offset + limit) < file_size
    if truncated:
        data = data[:limit]
    return data.decode("utf-8", errors="replace"), truncated, TextWindow(
        mode="range",
        file_size=file_size,
        requested_bytes=limit,
        returned_bytes=len(data),
        offset_bytes=start_offset,
    )


def _read_full_text_window(path: Path, *, mode: str, file_size: int) -> tuple[str, bool, TextWindow]:
    with path.open("rb") as handle:
        data = handle.read()
    return data.decode("utf-8", errors="replace"), False, TextWindow(
        mode=mode,
        file_size=file_size,
        requested_bytes=None,
        returned_bytes=len(data),
        offset_bytes=0,
    )


def _read_bounded_text_window(path: Path, *, mode: str, file_size: int, max_bytes: int) -> tuple[str, bool, TextWindow]:
    truncated = file_size > max_bytes
    with path.open("rb") as handle:
        if mode == "tail" and truncated:
            start_offset = max(0, file_size - max_bytes)
            handle.seek(start_offset)
        else:
            start_offset = 0
            handle.seek(0)
        data = handle.read(max_bytes)
    return data.decode("utf-8", errors="replace"), truncated, TextWindow(
        mode=mode,
        file_size=file_size,
        requested_bytes=max_bytes,
        returned_bytes=len(data),
        offset_bytes=start_offset,
    )


def _read_text_window(
    path: Path,
    *,
    max_bytes: int | None = None,
    mode: str = "tail",
    offset_bytes: int | None = None,
    length_bytes: int | None = None,
) -> tuple[str, bool, TextWindow]:
    if not path.exists():
        return _empty_text_window(mode=mode, requested_bytes=max_bytes, offset_bytes=offset_bytes)
    size = path.stat().st_size
    if size <= 0:
        return _empty_text_window(mode=mode, requested_bytes=max_bytes, offset_bytes=offset_bytes)
    mode = (mode or "tail").strip().lower()
    if mode not in {"tail", "head", "range", "all"}:
        mode = "tail"
    if mode == "all":
        max_bytes = None
    if mode == "range":
        return _read_range_text_window(
            path,
            file_size=size,
            offset_bytes=offset_bytes,
            max_bytes=max_bytes,
            length_bytes=length_bytes,
        )
    if max_bytes is None or max_bytes <= 0:
        return _read_full_text_window(path, mode=mode, file_size=size)
    return _read_bounded_text_window(path, mode=mode, file_size=size, max_bytes=max_bytes)


def _tail_text(path: Path, max_bytes: int | None):
    text, truncated, _meta = _read_text_window(path, max_bytes=max_bytes, mode="tail")
    return text, truncated


def _job_record(job: dict[str, Any] | ExecutionJobRecord) -> ExecutionJobRecord:
    return job if isinstance(job, ExecutionJobRecord) else ExecutionJobRecord.from_dict(job)


def _job_identity(job: dict[str, Any] | ExecutionJobRecord) -> tuple[str, str]:
    record = _job_record(job)
    return record.project_id, record.job_id


def _failure_digest(job: dict[str, Any] | ExecutionJobRecord, failure_kind, retryable=False, **extra):
    record = _job_record(job)
    signal = record.extra.get("signal") if isinstance(record.extra, dict) else None
    return ExecutionFailureDigest(
        job_id=record.job_id,
        project_id=record.project_id,
        failure_kind=failure_kind,
        execution_state=record.status,
        stage=record.stage or "runtime",
        host_preempted=failure_kind == "HOST_PREEMPT",
        exit_code=record.return_code,
        signal=str(signal) if signal is not None else None,
        artifact_registration_status=record.artifact_registration_status,
        time_started=record.started_at,
        time_ended=record.finished_at,
        duration_ms=record.duration_ms,
        retryable=retryable,
        extra=extra,
    )


def _compute_duration_ms(job: dict[str, Any] | ExecutionJobRecord):
    try:
        from datetime import datetime

        record = _job_record(job)
        if record.started_at and record.finished_at:
            a = datetime.fromisoformat(record.started_at)
            b = datetime.fromisoformat(record.finished_at)
            return max(0, int((b - a).total_seconds() * 1000))
    except Exception:
        pass
    return None


def _append_job_journal(project_id, title, content, entry_type="session_trace"):
    path = get_project_root(project_id) / "system" / "journal" / "journal.jsonl"
    append_jsonl(path, {"time": utc_now(), "entry_type": entry_type, "title": title, "content": content, "tags": ["execution"]})


def _update_manifest_entry(project_id, target: Path, artifact_class: str):
    manifest_path = manifest_path_for(project_id)
    manifest = load_json(manifest_path, {"updated_at": None, "files": {}})
    rel = str(target.relative_to(get_project_root(project_id)))
    manifest["files"][rel] = {
        "artifact_class": artifact_class,
        "sha256": sha256_file(target),
        "bytes": target.stat().st_size,
        "updated_at": utc_now(),
    }
    manifest["updated_at"] = utc_now()
    save_json_atomic(manifest_path, manifest)


def _record_commit(project_id, record):
    append_jsonl(commits_ledger_path_for(project_id), record)


def _execution_idempotency_path(project_id: str) -> Path:
    return _jobs_dir(project_id) / "idempotency.json"


def _load_execution_idempotency(project_id: str) -> ExecutionIdempotencyLedger:
    return ExecutionIdempotencyLedger.from_dict(load_json(_execution_idempotency_path(project_id), {"keys": {}}))


def _save_execution_idempotency(project_id: str, data: ExecutionIdempotencyLedger) -> None:
    save_json_atomic(_execution_idempotency_path(project_id), data.to_dict())


def _payload_fingerprint(payload: ExecutionSubmitPayload) -> str:
    material = {
        "project_id": payload.project_id,
        "execution_mode": payload.execution_mode,
        "command": payload.command,
        "cwd": payload.cwd,
        "timeout_seconds": payload.timeout_seconds,
        "stdout_max_bytes": payload.stdout_max_bytes,
        "stderr_max_bytes": payload.stderr_max_bytes,
        "env_allowlist": payload.env_allowlist,
        "result_artifact_targets": payload.result_artifact_targets,
        "local_model_id": payload.local_model_id,
        "agent_role": payload.agent_role,
        "replay_of": payload.replay_of,
    }
    raw = json.dumps(material, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _pid_alive(pid: Any) -> bool:
    try:
        pid_int = int(pid)
    except Exception:
        return False
    if pid_int <= 0:
        return False
    try:
        os.kill(pid_int, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _iter_job_files(project_id: str | None = None):
    if project_id:
        yield from _jobs_dir(project_id).glob("*.json")
        return
    if not PROJECTS_ROOT.exists():
        return
    for project_dir in PROJECTS_ROOT.iterdir():
        jobs_dir = project_dir / "system" / "logs" / "execution"
        if not jobs_dir.exists():
            continue
        yield from jobs_dir.glob("*.json")


def _load_job_file(path: Path) -> tuple[ExecutionJobRecord | None, str | None]:
    try:
        return ExecutionJobRecord.from_dict(json.loads(path.read_text(encoding="utf-8"))), None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def _effective_running_count(project_id: str | None = None) -> int:
    seen: set[str] = set()
    count = 0
    with _RUNNING_LOCK:
        for job_id, proc in list(_RUNNING.items()):
            if proc.poll() is None:
                if project_id is None or _job_belongs_to_project(job_id, project_id):
                    count += 1
                    seen.add(job_id)
    for path in _iter_job_files(project_id):
        job, _ = _load_job_file(path)
        if not job:
            continue
        job_id = job.job_id
        if not job_id or job_id in seen:
            continue
        if job.status != "RUNNING":
            continue
        if _pid_alive(job.pid):
            count += 1
    return count


def _effective_queue_count(project_id: str | None = None) -> int:
    count = 0
    for path in _iter_job_files(project_id):
        job, _ = _load_job_file(path)
        if job and job.status == "QUEUED":
            count += 1
    return count


def _job_belongs_to_project(job_id: str, project_id: str) -> bool:
    try:
        job = _read_job(project_id, job_id)
    except Exception:
        return False
    return _job_record(job).project_id == project_id


def _capacity_snapshot(project_id: str) -> CapacitySnapshot:
    return CapacitySnapshot(
        running_global=_effective_running_count(None),
        running_project=_effective_running_count(project_id),
        global_limit=EXECUTION_GLOBAL_CONCURRENCY,
        project_limit=EXECUTION_PROJECT_CONCURRENCY,
        queued_global=_effective_queue_count(None),
        queued_project=_effective_queue_count(project_id),
        global_queue_limit=_limit_for_wire(EXECUTION_GLOBAL_QUEUE_LIMIT),
        project_queue_limit=EXECUTION_PROJECT_QUEUE_LIMIT,
    )



def execution_readiness() -> dict[str, Any]:
    with _ADMISSION_LOCK:
        per_project: dict[str, CapacitySnapshot] = {}
        corrupt_job_files: list[str] = []
        unsupervised_jobs: list[str] = []
        oldest_queued_age_seconds: float | None = None
        now_epoch = time.time()
        for path in _iter_job_files(None):
            job, error = _load_job_file(path)
            if error:
                corrupt_job_files.append(str(path))
                continue
            if not job:
                continue
            project_id = job.project_id.strip()
            if project_id and project_id not in per_project:
                per_project[project_id] = _capacity_snapshot(project_id)
            if job.status == JOB_STATUS_RUNNING and not _pid_alive(job.pid):
                unsupervised_jobs.append(str(job.job_id))
            if job.status == JOB_STATUS_QUEUED:
                try:
                    from datetime import datetime
                    submitted = datetime.fromisoformat(str(job.submitted_at)).timestamp()
                    age = max(0.0, now_epoch - submitted)
                    oldest_queued_age_seconds = age if oldest_queued_age_seconds is None else max(oldest_queued_age_seconds, age)
                except Exception:
                    pass
        global_snapshot = GlobalExecutionSnapshot(
            running=_effective_running_count(None),
            queued=_effective_queue_count(None),
            global_limit=_limit_for_wire(EXECUTION_GLOBAL_CONCURRENCY),
            global_queue_limit=_limit_for_wire(EXECUTION_GLOBAL_QUEUE_LIMIT),
            oldest_queued_age_seconds=oldest_queued_age_seconds,
        )
    telemetry = SchedulerTelemetry(**_scheduler_snapshot())
    return ExecutionReadinessEnvelope(
        status="degraded" if corrupt_job_files or unsupervised_jobs or telemetry.last_error else "online",
        global_snapshot=global_snapshot,
        per_project=per_project,
        corrupt_job_files=corrupt_job_files,
        unsupervised_jobs=unsupervised_jobs,
        drain_batch=_limit_for_wire(EXECUTION_DRAIN_BATCH),
        scheduler_thread_alive=bool(_SCHEDULER_THREAD and _SCHEDULER_THREAD.is_alive()),
        scheduler_telemetry=telemetry,
    ).to_dict()


def _can_start_now(project_id: str) -> bool:
    snap = _capacity_snapshot(project_id)
    return (snap.global_limit is None or snap.running_global < snap.global_limit) and (snap.project_limit is None or snap.running_project < snap.project_limit)


def _queue_allowed(project_id: str) -> bool:
    snap = _capacity_snapshot(project_id)
    return (snap.global_queue_limit is None or snap.queued_global < snap.global_queue_limit) and (snap.project_queue_limit is None or snap.queued_project < snap.project_queue_limit)


def _spawn_job(job: ExecutionJobRecord) -> ExecutionJobRecord:
    stdout_path = Path(job["stdout_path"])
    stderr_path = Path(job["stderr_path"])
    env = os.environ.copy()
    for k, v in job.get("env_allowlist", {}).items():
        if isinstance(k, str) and isinstance(v, str):
            env[k] = v
    out_f = stdout_path.open("wb")
    err_f = stderr_path.open("wb")
    try:
        proc = subprocess.Popen(
            job["command"],
            cwd=job["cwd"],
            stdout=out_f,
            stderr=err_f,
            stdin=subprocess.DEVNULL,
            shell=False,
            env=env,
        )
    finally:
        out_f.close()
        err_f.close()
    with _RUNNING_LOCK:
        _RUNNING[job["job_id"]] = proc
    _set_job_status(job, JOB_STATUS_RUNNING, "runtime")
    job["started_at"] = utc_now()
    job["deadline_epoch"] = (time.time() + int(job["timeout_seconds"])) if job.get("timeout_seconds") else None
    job["pid"] = proc.pid
    job["queue_position"] = None
    return job



def _validated_execution_mode(value: Any, *, override: str | None = None) -> str:
    execution_mode = override or str(value or "one_shot")
    if execution_mode not in EXECUTION_MODES:
        raise ExecutionRequestError("INVALID_EXECUTION_MODE", "invalid execution_mode", 400)
    return execution_mode


def _validated_command_and_args(command: Any, args: Any) -> list[str]:
    if not isinstance(command, list) or not command or not all(isinstance(x, str) and x for x in command):
        raise ExecutionRequestError("BAD_REQUEST", "command must be a non-empty string array", 400)
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        raise ExecutionRequestError("BAD_REQUEST", "args must be a string array", 400)
    return list(command) + list(args)


def _validated_output_limits(data: dict[str, Any]) -> tuple[int | None, int | None, int | None]:
    timeout_seconds = _request_optional_positive_int(
        data.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS),
        DEFAULT_TIMEOUT_SECONDS,
        minimum=1,
        maximum=MAX_TIMEOUT_SECONDS,
    )
    stdout_max_bytes = _request_optional_positive_int(
        data.get("stdout_max_bytes", DEFAULT_STDOUT_MAX_BYTES),
        DEFAULT_STDOUT_MAX_BYTES,
        minimum=1024,
        maximum=MAX_OUTPUT_BYTES,
    )
    stderr_max_bytes = _request_optional_positive_int(
        data.get("stderr_max_bytes", DEFAULT_STDERR_MAX_BYTES),
        DEFAULT_STDERR_MAX_BYTES,
        minimum=1024,
        maximum=MAX_OUTPUT_BYTES,
    )
    return timeout_seconds, stdout_max_bytes, stderr_max_bytes


def _validated_env_allowlist(value: Any) -> dict[str, str]:
    if value in (None, ""):
        return {}
    if not isinstance(value, dict):
        raise ExecutionRequestError("BAD_REQUEST", "env_allowlist must be an object", 400)
    return {str(k): str(v) for k, v in value.items() if isinstance(k, str) and isinstance(v, str)}


def _validated_result_artifact_targets(value: Any) -> list[object]:
    if value in (None, ""):
        return []
    if not isinstance(value, list):
        raise ExecutionRequestError("BAD_REQUEST", "result_artifact_targets must be an array", 400)
    return list(value)


def _validated_journal_flags(data: dict[str, Any]) -> dict[str, bool]:
    return {
        "journal_on_submit": bool(data.get("journal_on_submit", True)),
        "journal_on_complete": bool(data.get("journal_on_complete", False)),
        "journal_on_failure": bool(data.get("journal_on_failure", True)),
        "checkpoint_on_complete": bool(data.get("checkpoint_on_complete", False)),
    }


def _normalize_submit_payload(
    data: dict[str, Any],
    *,
    execution_mode_override: str | None = None,
    replay_of: str | None = None,
    default_idempotency_key: str | None = None,
) -> ExecutionSubmitPayload:
    project_id = str(data.get("project_id", ""))
    execution_mode = _validated_execution_mode(data.get("execution_mode"), override=execution_mode_override)
    command = _validated_command_and_args(data.get("command"), data.get("args") or [])
    timeout_seconds, stdout_max_bytes, stderr_max_bytes = _validated_output_limits(data)
    env_allowlist = _validated_env_allowlist(data.get("env_allowlist"))
    result_artifact_targets = _validated_result_artifact_targets(data.get("result_artifact_targets"))
    journal_flags = _validated_journal_flags(data)
    try:
        cwd = _resolve_cwd(project_id, data.get("cwd"))
    except Exception as e:
        raise ExecutionRequestError("WORKDIR_INVALID", str(e), 400) from e
    cwd_rel = str(data.get("cwd") or ".")
    local_model_id = data.get("local_model_id")
    agent_role = data.get("agent_role")
    idempotency_key = str(data.get("idempotency_key") or default_idempotency_key or "").strip()
    payload = ExecutionSubmitPayload(
        project_id=project_id,
        execution_mode=execution_mode,
        command=command,
        cwd=str(cwd),
        cwd_rel=cwd_rel,
        timeout_seconds=timeout_seconds,
        stdout_max_bytes=stdout_max_bytes,
        stderr_max_bytes=stderr_max_bytes,
        env_allowlist=env_allowlist,
        result_artifact_targets=result_artifact_targets,
        local_model_id=str(local_model_id) if local_model_id is not None else None,
        agent_role=str(agent_role) if agent_role is not None else None,
        journal_on_submit=journal_flags["journal_on_submit"],
        journal_on_complete=journal_flags["journal_on_complete"],
        journal_on_failure=journal_flags["journal_on_failure"],
        checkpoint_on_complete=journal_flags["checkpoint_on_complete"],
        idempotency_key=idempotency_key,
        replay_of=replay_of,
    )
    object.__setattr__(payload, "submission_fingerprint", _payload_fingerprint(payload))
    return payload





def _resolve_existing_idempotent_job(payload: ExecutionSubmitPayload) -> ExecutionJobRecord | None:
    idempotency_key = payload.idempotency_key
    if not idempotency_key:
        return None
    ledger = _load_execution_idempotency(payload.project_id)
    existing = ledger.keys.get(idempotency_key)
    if not existing:
        return None
    if existing.submission_fingerprint != payload.submission_fingerprint:
        raise ExecutionRequestError(
            "IDEMPOTENCY_KEY_CONFLICT",
            "idempotency_key already used for a different execution payload",
            409,
            existing_job_id=existing.job_id,
        )
    existing_job_id = str(existing.job_id)
    if not existing_job_id:
        return None
    job = _read_job(payload.project_id, existing_job_id)
    job = _finalize(payload.project_id, existing_job_id, job)
    job.replayed = True
    return job


def _build_execution_job(
    payload: ExecutionSubmitPayload,
    *,
    replay_of: str | None,
    job_id: str,
    stdout_path: Path,
    stderr_path: Path,
) -> ExecutionJobRecord:
    return ExecutionJobRecord(
        project_id=payload.project_id,
        job_id=job_id,
        status=JOB_STATUS_SUBMITTED,
        stage="submit",
        execution_mode=payload.execution_mode,
        replay_of=replay_of,
        command=payload.command,
        cwd=payload.cwd,
        cwd_rel=payload.cwd_rel,
        submitted_at=utc_now(),
        started_at=None,
        deadline_epoch=None,
        timeout_seconds=payload.timeout_seconds,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        stdout_max_bytes=payload.stdout_max_bytes,
        stderr_max_bytes=payload.stderr_max_bytes,
        result_artifact_targets=payload.result_artifact_targets,
        artifact_registration_status="not_attempted",
        truth_gate="not_evaluated",
        resource_gate="not_evaluated",
        feasibility_gate="not_evaluated",
        journal_on_submit=payload.journal_on_submit,
        journal_on_complete=payload.journal_on_complete,
        journal_on_failure=payload.journal_on_failure,
        checkpoint_on_complete=payload.checkpoint_on_complete,
        local_model_id=payload.local_model_id,
        agent_role=payload.agent_role,
        idempotency_key=payload.idempotency_key,
        submission_fingerprint=payload.submission_fingerprint,
        env_allowlist=payload.env_allowlist,
        queue_position=None,
    )


def _spawn_or_queue_job(job: ExecutionJobRecord) -> ExecutionJobRecord:
    project_id = job.project_id
    if _can_start_now(project_id):
        try:
            return _spawn_job(job)
        except Exception as e:
            _set_job_status(job, JOB_STATUS_FAILED, "spawn_failure")
            job.finished_at = utc_now()
            job.failure_digest = _failure_digest(job, "SPAWN_FAILURE", retryable=False, stderr_excerpt=str(e), stdout_excerpt="")
            _write_job(project_id, job.job_id, job)
            raise ExecutionRequestError("SPAWN_FAILURE", str(e), 500, failure_digest=job.failure_digest) from e
    if not _queue_allowed(project_id):
        raise ExecutionOverCapacity(
            "execution queue is full; refusing new work instead of oversubscribing the host",
            capacity=_capacity_snapshot(project_id),
        )
    job.status = JOB_STATUS_QUEUED
    job.stage = "queued"
    job.queue_position = _effective_queue_count(project_id) + 1
    return job


def _journal_job_submission(job: ExecutionJobRecord) -> None:
    if job.journal_on_submit:
        title = f"execution {job.status.lower()} {job.job_id}"
        content = f"Mode={job.execution_mode} Command={' '.join(job.command)}"
        _append_job_journal(job.project_id, title, content)


def _persist_idempotency_key(payload: ExecutionSubmitPayload, job_id: str) -> None:
    if not payload.idempotency_key:
        return
    ledger = _load_execution_idempotency(payload.project_id)
    ledger.keys[payload.idempotency_key] = ExecutionIdempotencyRecord(
        job_id=job_id,
        submission_fingerprint=payload.submission_fingerprint,
        recorded_at=utc_now(),
    )
    _save_execution_idempotency(payload.project_id, ledger)


def _build_replay_submission_data(
    prior: ExecutionJobRecord,
    replay: ExecutionReplayRequest,
    project_id: str,
) -> dict[str, Any]:
    cwd_rel = "."
    if prior.cwd:
        try:
            cwd_rel = Path(prior.cwd).relative_to(get_project_root(project_id)).as_posix()
        except Exception:
            cwd_rel = prior.cwd_rel or "."
    return {
        "project_id": project_id,
        "command": list(prior.command),
        "args": [],
        "execution_mode": "replay",
        "cwd": cwd_rel,
        "timeout_seconds": replay.timeout_seconds if replay.timeout_seconds is not None else prior.timeout_seconds or DEFAULT_TIMEOUT_SECONDS,
        "stdout_max_bytes": replay.stdout_max_bytes if replay.stdout_max_bytes is not None else prior.stdout_max_bytes or DEFAULT_STDOUT_MAX_BYTES,
        "stderr_max_bytes": replay.stderr_max_bytes if replay.stderr_max_bytes is not None else prior.stderr_max_bytes or DEFAULT_STDERR_MAX_BYTES,
        "env_allowlist": replay.env_allowlist,
        "result_artifact_targets": replay.result_artifact_targets or prior.result_artifact_targets,
        "journal_on_submit": replay.journal_on_submit,
        "journal_on_complete": replay.journal_on_complete,
        "journal_on_failure": replay.journal_on_failure,
        "local_model_id": replay.local_model_id or prior.local_model_id,
        "agent_role": replay.agent_role or prior.agent_role,
        "idempotency_key": replay.idempotency_key,
    }

def submit_execution_job(
    data: dict[str, Any],
    *,
    execution_mode_override: str | None = None,
    replay_of: str | None = None,
    default_idempotency_key: str | None = None,
) -> ExecutionJobRecord:
    payload = _normalize_submit_payload(
        data,
        execution_mode_override=execution_mode_override,
        replay_of=replay_of,
        default_idempotency_key=default_idempotency_key,
    )

    with _ADMISSION_LOCK:
        _ensure_scheduler_started()

        existing = _resolve_existing_idempotent_job(payload)
        if existing is not None:
            return existing

        job_id = f"job-{uuid.uuid4().hex[:12]}"
        job_dir = _job_dir(payload.project_id, job_id)
        stdout_path = job_dir / "stdout.log"
        stderr_path = job_dir / "stderr.log"
        job = _build_execution_job(
            payload,
            replay_of=replay_of,
            job_id=job_id,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
        )
        job = _spawn_or_queue_job(job)

        _journal_job_submission(job)
        _write_job(payload.project_id, job_id, job)

        _ensure_scheduler_started()
        _persist_idempotency_key(payload, job_id)

        started = _drain_queue_locked(payload.project_id)
        if started and job.status == JOB_STATUS_QUEUED:
            job = _read_job(payload.project_id, job_id)
        job.replayed = False
        return job


def _drain_queue_locked(project_id: str | None = None, *, limit: int | None = EXECUTION_DRAIN_BATCH) -> list[str]:
    started: list[str] = []
    queued_jobs: list[tuple[str, str, dict[str, Any]]] = []
    for path in _iter_job_files(project_id):
        job, _ = _load_job_file(path)
        if not job or job.get("status") != "QUEUED":
            continue
        queued_jobs.append((str(job.get("submitted_at") or ""), str(job.get("project_id") or ""), job))
    queued_jobs.sort(key=lambda item: (item[0], item[1], item[2].get("job_id", "")))
    for _, pid, job in queued_jobs:
        if limit is not None and len(started) >= limit:
            break
        if not pid or not _can_start_now(pid):
            continue
        try:
            job = _spawn_job(job)
            _write_job(pid, job["job_id"], job)
            started.append(job["job_id"])
        except Exception as e:
            _set_job_status(job, JOB_STATUS_FAILED, "spawn")
            job["finished_at"] = utc_now()
            job["failure_digest"] = _failure_digest(job, "SPAWN_FAILURE", retryable=False, stderr_excerpt=str(e), stdout_excerpt="")
            _write_job(pid, job["job_id"], job)
    return started


def _drain_queue(project_id: str | None = None, *, limit: int | None = EXECUTION_DRAIN_BATCH) -> list[str]:
    with _ADMISSION_LOCK:
        return _drain_queue_locked(project_id, limit=limit)



def _mark_job_unsupervised(project_id: str, job_id: str, job: ExecutionJobRecord) -> ExecutionJobRecord:
    job.supervision_state = "unsupervised"
    job.stage = "runtime_unsupervised"
    _write_job(project_id, job_id, job)
    return job


def _job_failure_excerpt(job: ExecutionJobRecord) -> tuple[str, str]:
    stderr_excerpt, _ = _tail_text(Path(job.stderr_path), 2048)
    stdout_excerpt, _ = _tail_text(Path(job.stdout_path), 2048)
    return stderr_excerpt, stdout_excerpt


def _mark_supervision_lost(project_id: str, job_id: str, job: ExecutionJobRecord) -> ExecutionJobRecord:
    _set_job_status(job, JOB_STATUS_FAILED, "supervision_lost")
    job.finished_at = job.finished_at or utc_now()
    job.duration_ms = _compute_duration_ms(job)
    stderr_excerpt, stdout_excerpt = _job_failure_excerpt(job)
    job.failure_digest = _failure_digest(
        job,
        "SUPERVISION_LOST",
        retryable=True,
        stderr_excerpt=stderr_excerpt,
        stdout_excerpt=stdout_excerpt,
    )
    _write_job(project_id, job_id, job)
    return job


def _mark_timeout_failure(project_id: str, job_id: str, job: ExecutionJobRecord, proc: subprocess.Popen[bytes]) -> ExecutionJobRecord:
    proc.kill()
    _set_job_status(job, JOB_STATUS_FAILED, "timeout")
    job.return_code = -9
    job.finished_at = utc_now()
    job.duration_ms = _compute_duration_ms(job)
    job.failure_digest = _failure_digest(job, "TIMEOUT", retryable=True)
    _write_job(project_id, job_id, job)
    _scheduler_stat_inc("jobs_timed_out")
    _scheduler_stat_inc("jobs_failed")
    with _RUNNING_LOCK:
        _RUNNING.pop(job_id, None)
    started_after = _drain_queue_locked(project_id)
    if started_after:
        _scheduler_stat_inc("jobs_started", len(started_after))
    return job


def _record_completion_journal(project_id: str, job: ExecutionJobRecord) -> None:
    if job.journal_on_complete and job.return_code == 0:
        _append_job_journal(project_id, f"execution complete {job.job_id}", f"Command: {' '.join(job.command)}")
    if job.journal_on_failure and job.return_code != 0:
        failure_payload = job.failure_digest.to_dict() if isinstance(job.failure_digest, ExecutionFailureDigest) else job.failure_digest or {}
        _append_job_journal(project_id, f"execution failed {job.job_id}", json.dumps(failure_payload))


def _mark_process_completion(project_id: str, job_id: str, job: ExecutionJobRecord, return_code: int) -> ExecutionJobRecord:
    _set_job_status(job, JOB_STATUS_COMPLETED if return_code == 0 else JOB_STATUS_FAILED, "complete")
    job.return_code = int(return_code)
    job.finished_at = utc_now()
    job.duration_ms = _compute_duration_ms(job)
    if return_code != 0:
        stderr_excerpt, stdout_excerpt = _job_failure_excerpt(job)
        job.failure_digest = _failure_digest(
            job,
            "NONZERO_EXIT",
            retryable=False,
            stderr_excerpt=stderr_excerpt,
            stdout_excerpt=stdout_excerpt,
        )
    _record_completion_journal(project_id, job)
    _write_job(project_id, job_id, job)
    _scheduler_stat_inc("jobs_completed" if return_code == 0 else "jobs_failed")
    with _RUNNING_LOCK:
        _RUNNING.pop(job_id, None)
    started_after = _drain_queue_locked(project_id)
    if started_after:
        _scheduler_stat_inc("jobs_started", len(started_after))
    return job



def _finalize_without_process(project_id: str, job_id: str, job: ExecutionJobRecord) -> ExecutionJobRecord:
    if job.status == JOB_STATUS_QUEUED:
        _drain_queue_locked(project_id)
        return _read_job(project_id, job_id)
    if job.status != JOB_STATUS_RUNNING:
        return job
    if _pid_alive(job.pid):
        return _mark_job_unsupervised(project_id, job_id, job)
    return _mark_supervision_lost(project_id, job_id, job)


def _finalize_running_process(project_id: str, job_id: str, job: ExecutionJobRecord, proc: subprocess.Popen[bytes]) -> ExecutionJobRecord:
    ret = proc.poll()
    now = time.time()
    if ret is None:
        if job.deadline_epoch and now > job.deadline_epoch:
            return _mark_timeout_failure(project_id, job_id, job, proc)
        return job
    return _mark_process_completion(project_id, job_id, job, ret)


def _finalize(project_id: str, job_id: str, job: ExecutionJobRecord) -> ExecutionJobRecord:
    with _ADMISSION_LOCK:
        proc = _RUNNING.get(job_id)
        if proc is None:
            return _finalize_without_process(project_id, job_id, job)
        return _finalize_running_process(project_id, job_id, job, proc)


def _reconcile_job_locked(job: ExecutionJobRecord) -> None:
    project_id = str(job.project_id).strip()
    job_id = str(job.job_id).strip()
    if not project_id or not job_id:
        return
    proc = _RUNNING.get(job_id)
    if proc is not None:
        _finalize(project_id, job_id, job)
        return
    if job.status != JOB_STATUS_RUNNING:
        return
    if _pid_alive(job.pid):
        if job.supervision_state != "unsupervised":
            _mark_job_unsupervised(project_id, job_id, job)
        return
    _mark_supervision_lost(project_id, job_id, job)
    _scheduler_stat_inc("jobs_failed")
    _scheduler_stat_inc("jobs_reconciled")


def _scheduler_tick() -> None:
    with _ADMISSION_LOCK:
        for path in _iter_job_files(None):
            job, _error = _load_job_file(path)
            if not job:
                continue
            _reconcile_job_locked(job)
        started = _drain_queue_locked(None)
        if started:
            _scheduler_stat_inc("jobs_started", len(started))



def _scheduler_loop() -> None:
    while not _SCHEDULER_STOP.is_set():
        _scheduler_stat_inc("iterations")
        _scheduler_stat_set("last_tick_at", utc_now())
        try:
            _scheduler_stat_set("last_error", None)
            _scheduler_tick()
        except Exception as exc:
            _scheduler_stat_set("last_error", f"{type(exc).__name__}: {exc}")
        _SCHEDULER_STOP.wait(EXECUTION_SCHEDULER_INTERVAL_SECONDS)


def _shutdown_scheduler() -> None:
    _SCHEDULER_STOP.set()
    thread = _SCHEDULER_THREAD
    if thread and thread.is_alive():
        thread.join(timeout=1.0)


atexit.register(_shutdown_scheduler)


def _ensure_scheduler_started() -> None:
    global _SCHEDULER_THREAD
    if _SCHEDULER_THREAD and _SCHEDULER_THREAD.is_alive():
        return
    _SCHEDULER_STOP.clear()
    _SCHEDULER_THREAD = threading.Thread(
        target=_scheduler_loop,
        name="pcmmad-execution-scheduler",
        daemon=True,
    )
    _SCHEDULER_THREAD.start()
    _scheduler_stat_inc("scheduler_startups")


@execution_bp.post("/submit")
def submit_execution():
    ae = _auth()
    if ae:
        return ae
    try:
        d = request.get_json(silent=False, force=True)
        job = submit_execution_job(d)
        return jsonify(ExecutionStatusResponse(ok=True, job=job).to_dict())
    except ExecutionRequestError as e:
        return _error(e.error_code, e.message, e.status, **e.extra)
    except Exception as e:
        return _error("EXECUTION_SUBMIT_FAILED", str(e), 500)


@execution_bp.post("/status")
def execution_status():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionStatusRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    job_id = d.job_id
    try:
        job = _finalize(project_id, job_id, _read_job(project_id, job_id))
        return jsonify(ExecutionStatusResponse(ok=True, job=job).to_dict())
    except FileNotFoundError:
        return _error("NOT_FOUND", "job not found", 404)
    except Exception as e:
        return _error("EXECUTION_STATUS_FAILED", str(e), 500)



@execution_bp.post("/output")
def execution_output():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionOutputRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    job_id = d.job_id
    max_bytes = _request_optional_positive_int(d.max_bytes, 32768, minimum=1024, maximum=MAX_OUTPUT_BYTES)
    mode = d.mode
    offset_bytes = _request_optional_positive_int(d.offset_bytes, None, minimum=0, maximum=MAX_OUTPUT_BYTES)
    length_bytes = _request_optional_positive_int(d.length_bytes, max_bytes, minimum=1, maximum=MAX_OUTPUT_BYTES)
    try:
        job = _finalize(project_id, job_id, _read_job(project_id, job_id))
        stdout_text, stdout_truncated, stdout_window = _read_text_window(Path(job["stdout_path"]), max_bytes=max_bytes, mode=mode, offset_bytes=offset_bytes, length_bytes=length_bytes)
        stderr_text, stderr_truncated, stderr_window = _read_text_window(Path(job["stderr_path"]), max_bytes=max_bytes, mode=mode, offset_bytes=offset_bytes, length_bytes=length_bytes)
        return jsonify(ExecutionOutputResponse(
            ok=True,
            project_id=project_id,
            job_id=job_id,
            status=str(job.get("status")),
            stdout=stdout_text,
            stderr=stderr_text,
            stdout_truncated=stdout_truncated,
            stderr_truncated=stderr_truncated,
            bytes_returned=len(stdout_text.encode("utf-8")) + len(stderr_text.encode("utf-8")),
            max_bytes=_limit_for_wire(max_bytes),
            stdout_window=stdout_window,
            stderr_window=stderr_window,
            stdout_path=str(job.get("stdout_path")),
            stderr_path=str(job.get("stderr_path")),
            last_update_time=utc_now(),
        ).to_dict())
    except FileNotFoundError:
        return _error("NOT_FOUND", "job not found", 404)
    except Exception as e:
        return _error("EXECUTION_OUTPUT_FAILED", str(e), 500)


@execution_bp.post("/list")

def execution_list():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionListRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    limit = _request_optional_positive_int(d.limit, DEFAULT_LIST_LIMIT, minimum=1)
    try:
        _drain_queue(project_id)
        jobs: list[ExecutionJobRecord] = []
        corrupt_job_files: list[CorruptJobFileRecord] = []
        job_files = sorted(_jobs_dir(project_id).glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        if limit is not None:
            job_files = job_files[:limit]
        for p in job_files:
            job, error = _load_job_file(p)
            if error:
                corrupt_job_files.append(CorruptJobFileRecord(path=str(p), error=error))
                continue
            if not job:
                continue
            jid = job.get("job_id")
            if jid:
                job = _finalize(project_id, jid, job)
            jobs.append(job)
        return jsonify(ExecutionListResponse(
            ok=True,
            project_id=project_id,
            count=len(jobs),
            jobs=jobs,
            capacity=_capacity_snapshot(project_id),
            corrupt_job_files=corrupt_job_files,
        ).to_dict())
    except Exception as e:
        return _error("EXECUTION_LIST_FAILED", str(e), 500)


@execution_bp.post("/terminate")
def execution_terminate():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionTerminateRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    job_id = d.job_id
    try:
        job = _read_job(project_id, job_id)
        proc = _RUNNING.get(job_id)
        if proc and proc.poll() is None:
            proc.kill()
            job["status"] = "TERMINATED"
            job["return_code"] = -9
            job["stage"] = "terminated"
            job["finished_at"] = utc_now()
            job["duration_ms"] = _compute_duration_ms(job)
            job["failure_digest"] = _failure_digest(job, "HOST_PREEMPT", retryable=True)
            _write_job(project_id, job_id, job)
            with _RUNNING_LOCK:
                _RUNNING.pop(job_id, None)
            _drain_queue(project_id)
        elif job.get("status") == "QUEUED":
            job["status"] = "TERMINATED"
            job["stage"] = "terminated_while_queued"
            job["finished_at"] = utc_now()
            job["failure_digest"] = _failure_digest(job, "HOST_PREEMPT", retryable=True)
            _write_job(project_id, job_id, job)
            _drain_queue(project_id)
        return jsonify(ExecutionStatusResponse(ok=True, job=job).to_dict())
    except FileNotFoundError:
        return _error("NOT_FOUND", "job not found", 404)
    except Exception as e:
        return _error("TERMINATION_FAILED", str(e), 500)


@execution_bp.post("/register")
def execution_register():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionRegisterRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    source_path = d.source_path
    artifact_class = d.artifact_class
    logical_name = d.logical_name
    operation = d.operation
    job_id = d.job_id
    expected_previous_sha256 = d.expected_previous_sha256
    try:
        root = get_project_root(project_id)
        src = (root / source_path).resolve() if not Path(source_path).is_absolute() else Path(source_path).resolve()
        if root.resolve() not in [src, *src.parents]:
            return _error("BAD_PATH", "source_path escapes project root", 400)
        if not src.exists() or not src.is_file():
            return _error("NOT_FOUND", "source artifact not found", 404)
        target = resolve_target(project_id, artifact_class, logical_name)
        if target.exists() and operation == "create":
            return _error("BAD_OPERATION", "target already exists", 409)
        if (not target.exists()) and operation == "update":
            return _error("BAD_OPERATION", "target does not exist", 409)
        if target.exists() and expected_previous_sha256:
            cur = sha256_file(target)
            if cur != expected_previous_sha256:
                return _error("HASH_MISMATCH", "expected_previous_sha256 did not match existing file", 409, current_sha256=cur)
        ensure_parent(target)
        shutil.copy2(src, target)
        sha = sha256_file(target)
        _update_manifest_entry(project_id, target, artifact_class)
        commit_id = d.commit_id or f"execution-register-{uuid.uuid4().hex[:8]}"
        record = ExecutionRegistrationRecord(
            project_id=project_id,
            session_id=d.session_id,
            commit_id=commit_id,
            idempotency_key=d.idempotency_key,
            artifact_class=artifact_class,
            logical_name=logical_name,
            operation=operation,
            path=str(target.relative_to(root)),
            sha256=sha,
            bytes=target.stat().st_size,
            time=utc_now(),
        )
        _record_commit(project_id, record.to_dict())
        if job_id:
            job = _read_job(project_id, job_id)
            job.setdefault("registered_artifacts", []).append(record.to_dict())
            job["artifact_registration_status"] = "registered"
            _write_job(project_id, job_id, job)
        return jsonify(ExecutionRegisterResponse(ok=True, registration_commit_id=commit_id, **record.to_dict()).to_dict())
    except Exception as e:
        return _error("RESULT_REGISTRATION_FAILED", str(e), 500)


@execution_bp.post("/replay")
def execution_replay():
    ae = _auth()
    if ae:
        return ae
    d = ExecutionReplayRequest.from_json(request.get_json(silent=False, force=True))
    project_id = d.project_id
    prior_job_id = d.job_id
    try:
        prior = _read_job(project_id, prior_job_id)
    except FileNotFoundError:
        return _error("NOT_FOUND", "job not found", 404)
    payload = _build_replay_submission_data(prior, d, project_id)
    try:
        default_key_material = json.dumps({
            "project_id": project_id,
            "prior_job_id": prior_job_id,
            "timeout_seconds": payload["timeout_seconds"],
            "stdout_max_bytes": payload["stdout_max_bytes"],
            "stderr_max_bytes": payload["stderr_max_bytes"],
            "env_allowlist": payload["env_allowlist"],
            "result_artifact_targets": payload["result_artifact_targets"],
        }, sort_keys=True, separators=(",", ":"))
        default_key = hashlib.sha256(default_key_material.encode("utf-8")).hexdigest()
        job = submit_execution_job(payload, execution_mode_override="replay", replay_of=prior_job_id, default_idempotency_key=default_key)
        return jsonify(ExecutionStatusResponse(ok=True, job=job).to_dict())
    except ExecutionRequestError as e:
        return _error(e.error_code, e.message, e.status, **e.extra)
    except Exception as e:
        return _error("SPAWN_FAILURE", str(e), 500)
