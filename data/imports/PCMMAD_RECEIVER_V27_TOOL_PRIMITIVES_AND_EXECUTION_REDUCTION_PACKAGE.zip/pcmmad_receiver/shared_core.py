from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_DEFAULT_ROOT = Path.home() / "Desktop" / "AI_Pushes_Sandbox"
ROOT = Path(os.environ.get("PCMMAD_ROOT", str(_DEFAULT_ROOT))).resolve()
PROJECTS_ROOT = Path(os.environ.get("PCMMAD_PROJECTS_ROOT", str(ROOT / "projects"))).resolve()
SYSTEM_ROOT = Path(os.environ.get("PCMMAD_SYSTEM_ROOT", str(ROOT / "system"))).resolve()
SANDBOX_ROOT = Path(os.environ.get("PCMMAD_SANDBOX_ROOT", str(ROOT / "sandbox"))).resolve()
TEMP_ROOT = Path(os.environ.get("PCMMAD_TEMP_ROOT", str(Path(tempfile.gettempdir()) / "pcmmad_lab"))).resolve()

SAFE_NAME_RE = re.compile(r"^[A-Za-z0-9._ -]+$")
SAFE_PROJECT_RE = re.compile(r"^[A-Za-z0-9._-]{1,128}$")
MOUNT_SPEC_RE = re.compile(r"^(?P<mount>[A-Za-z0-9._-]+)://(?P<subpath>.*)$")

ALLOWED_OPERATIONS = {"create", "update", "append"}
APPEND_ALLOWED_CLASSES = {"continuity.design_thread_stream", "notes.maintenance"}

TEXT_EXTENSIONS = {".md", ".txt", ".json", ".py", ".yaml", ".yml", ".toml", ".log", ".ini", ".cfg", ".csv", ".tsv", ".xml", ".html", ".css", ".js", ".sql"}
MODEL_EXTENSIONS = {".safetensors", ".gguf", ".onnx", ".bin", ".pt", ".pth"}
ARCHIVE_EXTENSIONS = {".zip", ".tar", ".tgz", ".gz", ".7z"}

BASE_DIRS = [
    "continuity/live_shadow",
    "continuity/design_thread_stream",
    "state/current",
    "state/next_steps",
    "state/doctrine_snapshot",
    "state/revisit_ledger",
    "state/trace_matrix",
    "notes/maintenance",
    "code",
    "checkpoints",
    "system/manifest",
    "system/ledger",
    "system/logs",
    "system/logs/execution",
    "system/journal",
    "system/lab",
    "system/lab/sessions",
    "system/lab/reflexion",
    "system/lab/andon",
    "system/lab/procedures",
    "system/lab/results",
    "system/lab/corpora",
    "data",
    "research",
    "lab_plugins",
]

ARTIFACT_RELATIVE_MAP = {
    "continuity.live_shadow": Path("continuity/live_shadow"),
    "continuity.design_thread_stream": Path("continuity/design_thread_stream"),
    "continuity.checkpoint": Path("checkpoints"),
    "state.current": Path("state/current"),
    "state.next_steps": Path("state/next_steps"),
    "state.doctrine_snapshot": Path("state/doctrine_snapshot"),
    "state.revisit_ledger": Path("state/revisit_ledger"),
    "state.trace_matrix": Path("state/trace_matrix"),
    "notes.maintenance": Path("notes/maintenance"),
    "code": Path("code"),
}


def _parse_mount_overrides() -> dict[str, Path]:
    mounts = {
        "root": ROOT,
        "projects": PROJECTS_ROOT,
        "system": SYSTEM_ROOT,
        "sandbox": SANDBOX_ROOT,
        "temp": TEMP_ROOT,
        "cwd": Path.cwd().resolve(),
    }
    raw = os.environ.get("PCMMAD_MOUNTS_JSON", "").strip()
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                for name, path in parsed.items():
                    if isinstance(name, str) and isinstance(path, str) and path.strip():
                        mounts[name] = Path(path).expanduser().resolve()
        except Exception:
            pass
    return mounts


MOUNT_TABLE = _parse_mount_overrides()
for _path in {ROOT, PROJECTS_ROOT, SYSTEM_ROOT, SANDBOX_ROOT, TEMP_ROOT, *MOUNT_TABLE.values()}:
    try:
        _path.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json_atomic(path: Path, data: Any) -> None:
    ensure_parent(path)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=path.parent, encoding="utf-8") as tmp:
        json.dump(data, tmp, indent=2)
        tmp_path = Path(tmp.name)
    tmp_path.replace(path)


def _json_ready(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(getattr(value, "to_dict")):
        return value.to_dict()
    return value


def append_jsonl(path: Path, record: Any) -> None:
    ensure_parent(path)
    payload = _json_ready(record)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")


def validate_project_id(project_id: str) -> str:
    if not project_id:
        raise ValueError("project_id is required")
    if not SAFE_PROJECT_RE.fullmatch(project_id):
        raise ValueError("project_id contains invalid characters")
    return project_id


def get_mount_table() -> dict[str, Path]:
    return dict(MOUNT_TABLE)


def get_mount_roots() -> list[Path]:
    return list(dict.fromkeys(path.resolve() for path in MOUNT_TABLE.values()))


def mount_summary() -> list[dict[str, str]]:
    return [{"name": name, "path": str(path)} for name, path in sorted(MOUNT_TABLE.items())]


def resolve_mount_spec(path_spec: str | None, *, default_root: Path | None = None, allow_absolute: bool = True) -> Path:
    raw = (path_spec or ".").strip()
    match = MOUNT_SPEC_RE.match(raw)
    if match:
        mount = match.group("mount")
        subpath = match.group("subpath")
        base = MOUNT_TABLE.get(mount)
        if base is None:
            raise ValueError(f"unknown mount: {mount}")
        return (base / subpath).resolve()
    candidate = Path(raw).expanduser()
    if candidate.is_absolute():
        if not allow_absolute:
            raise ValueError("absolute paths are not allowed here")
        return candidate.resolve()
    if default_root is None:
        default_root = ROOT
    return (default_root / candidate).resolve()


def get_project_root(project_id: str) -> Path:
    pid = validate_project_id(project_id)
    root = (PROJECTS_ROOT / pid).resolve()
    if PROJECTS_ROOT.resolve() not in [root, *root.parents]:
        raise ValueError("project root escaped projects root")
    return root


def init_project_layout(project_id: str) -> Path:
    root = get_project_root(project_id)
    root.mkdir(parents=True, exist_ok=True)
    for rel in BASE_DIRS:
        (root / rel).mkdir(parents=True, exist_ok=True)
    return root


def manifest_path_for(project_id: str) -> Path:
    return get_project_root(project_id) / "system" / "manifest" / "manifest.json"


def commits_ledger_path_for(project_id: str) -> Path:
    return get_project_root(project_id) / "system" / "ledger" / "commits.jsonl"


def idempotency_path_for(project_id: str) -> Path:
    return get_project_root(project_id) / "system" / "ledger" / "idempotency.json"


def journal_path_for(project_id: str) -> Path:
    return get_project_root(project_id) / "system" / "journal" / "journal.jsonl"


def validate_logical_name(name: str) -> str:
    if not name:
        raise ValueError("logical_name is required")
    if "/" in name or "\\" in name:
        raise ValueError("logical_name must not include path separators")
    if not SAFE_NAME_RE.fullmatch(name):
        raise ValueError("logical_name contains invalid characters")
    return name


def resolve_target(project_id: str, artifact_class: str, logical_name: str) -> Path:
    root = get_project_root(project_id)
    if artifact_class not in ARTIFACT_RELATIVE_MAP:
        raise ValueError(f"Unknown artifact_class: {artifact_class}")
    target = (root / ARTIFACT_RELATIVE_MAP[artifact_class] / validate_logical_name(logical_name)).resolve()
    if root.resolve() not in [target, *target.parents]:
        raise ValueError("resolved path escaped project root")
    return target


def require_valid_api_key(headers) -> None:
    expected = os.environ.get("GITHOME_API_KEY", "")
    provided = headers.get("X-GitHome-Key", "")
    if not expected or provided != expected:
        raise PermissionError("Invalid or missing API key")


def capabilities() -> dict[str, bool]:
    return {
        "project_routes": True,
        "legacy_routes": True,
        "research": True,
        "context": True,
        "model_inventory": True,
        "archive_inventory": True,
        "archive_extract": True,
        "journal": True,
        "checkpoints": True,
        "partial_traversal_reporting": True,
        "rehydrate_debug": True,
        "execution": True,
        "execution_register": True,
        "execution_replay": True,
        "sync_exec": True,
        "python_exec": True,
        "file_tree": True,
        "zip_read": True,
        "lab_router": True,
        "lab_batch": True,
        "lab_sessions": True,
        "approval_gates": True,
        "plugin_autoload": True,
        "git_ops": True,
        "web_fetch": True,
        "verify_gates": True,
        "mount_table": True,
        "filesystem_tools": True,
        "browser_bridge_proxy": True,
        "result_handles": True,
        "mcp_manifest": True,
    }
