from __future__ import annotations

from typing import Any

from research_config import PARSER_VERSION
from research_models import paper_summary, claim, method, isomorphic_abstraction


def _pick_mechanism_name(title: str, abstract: str) -> str:
    text = f"{title} {abstract}".lower()
    candidates = [
        ("compression", "compression strategy"),
        ("cache", "cache management mechanism"),
        ("retrieval", "retrieval-augmented retention"),
        ("memory", "memory retention mechanism"),
        ("quantization", "quantization mechanism"),
        ("sparse", "sparse selection mechanism"),
        ("attention", "attention-centric architecture"),
        ("transformer", "transformer sequence architecture"),
    ]
    for needle, label in candidates:
        if needle in text:
            return label
    return "latent state management mechanism"


def _derive_problem_topology(title: str, abstract: str) -> str:
    text = f"{title} {abstract}".lower()
    if "memory" in text or "cache" in text:
        return "bounded retention of useful state under sequential pressure"
    if "compression" in text:
        return "information preservation under bounded representation budget"
    if "sequence" in text:
        return "performance preservation under long-range sequential dependency pressure"
    return "performance preservation under constrained representational resources"


def _derive_mechanism_topology(title: str, abstract: str) -> str:
    text = f"{title} {abstract}".lower()
    if "sparse" in text:
        return "selective sparse retention of high-value state"
    if "quantization" in text:
        return "lossy low-precision retention of compressed state"
    if "cache" in text or "memory" in text:
        return "managed buffering and reuse of salient intermediate state"
    if "compression" in text:
        return "lossy compression with selective reconstruction pressure"
    if "attention" in text:
        return "attention-driven contextual state routing"
    return "compressed retention with task-biased state prioritization"


def _derive_math_core(title: str, abstract: str) -> str:
    text = f"{title} {abstract}".lower()
    if "quantization" in text:
        return "precision-bounded approximation under information loss"
    if "sparse" in text:
        return "sparse selection and representation"
    if "compression" in text:
        return "information bottleneck under bounded capacity"
    if "attention" in text:
        return "weighted contextual aggregation"
    return "bounded-state approximation"


def distill_paper(canonical_paper: dict[str, Any], ingestion_run_id: str) -> dict[str, Any]:
    """
    Bounded first-pass distillation from canonical arXiv payload.

    This is intentionally abstract-heavy / shallow:
    - grounded primarily in title + abstract
    - suitable for early hunt/result shaping
    - NOT sufficient for deep architectural claims without full-paper follow-up
    """
    paper_id = canonical_paper["paper_id"]
    title = canonical_paper.get("title", "")
    abstract = canonical_paper.get("abstract", "")

    thesis = (abstract if abstract else title)[:500]

    summary = paper_summary(
        paper_id=paper_id,
        parser_version=PARSER_VERSION,
        ingestion_run_id=ingestion_run_id,
        core_thesis=thesis,
        synthesis_role="foundational",
        must_read_justification="Direct paper ingestion for canonical-to-derived object test.",
        rigor_score=0.5,
        novelty_score=0.5,
        reproducibility_index=0.4,
    )

    claim_obj = claim(
        paper_id=paper_id,
        parser_version=PARSER_VERSION,
        ingestion_run_id=ingestion_run_id,
        ordinal=1,
        claim_statement=thesis,
        claim_type="methodological_advantage",
        evidence_strength=0.4,
        falsifiability_surface="Requires full paper review and empirical comparison against cited baseline.",
    )

    method_name = _pick_mechanism_name(title, abstract)
    method_obj = method(
        paper_id=paper_id,
        parser_version=PARSER_VERSION,
        ingestion_run_id=ingestion_run_id,
        ordinal=1,
        mechanism_name=method_name,
        execution_logic=(
            "First-pass abstract distillation inferred a primary mechanism from title/abstract tokens. "
            "This is a bounded heuristic, not a full methodological parse."
        ),
        hardware_substrate_assumptions=[],
    )

    iso_obj = isomorphic_abstraction(
        paper_id=paper_id,
        parser_version=PARSER_VERSION,
        ingestion_run_id=ingestion_run_id,
        ordinal=1,
        problem_topology=_derive_problem_topology(title, abstract),
        mechanism_topology=_derive_mechanism_topology(title, abstract),
        mathematical_core=_derive_math_core(title, abstract),
        failure_topology="unknown_from_abstract_only",
        target_transfer_domains=["signal processing", "systems caching", "video compression"],
    )

    summary["derived_object_counts"] = {
        "claims": 1,
        "methods": 1,
        "limitations": 0,
        "isomorphisms": 1,
    }

    return {
        "paper_summary": summary,
        "claims": [claim_obj],
        "methods": [method_obj],
        "limitations": [],
        "isomorphic_abstractions": [iso_obj],
    }
