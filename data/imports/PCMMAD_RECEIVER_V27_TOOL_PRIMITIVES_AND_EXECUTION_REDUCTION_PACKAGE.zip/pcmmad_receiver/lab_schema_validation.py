from __future__ import annotations

from typing import Any, Callable


def validate_schema_value(
    schema: dict[str, Any],
    value: Any,
    path: str,
    *,
    raise_error: Callable[[str, str, int], None],
) -> None:
    if schema.get("nullable") and value is None:
        return
    expected_type = schema.get("type")
    if expected_type is None and ("properties" in schema or "required" in schema):
        expected_type = "object"

    if expected_type == "object":
        if not isinstance(value, dict):
            raise_error("BAD_REQUEST", f"{path} must be an object", 400)
        properties = schema.get("properties") or {}
        required = schema.get("required") or []
        for key in required:
            if key not in value:
                raise_error("BAD_REQUEST", f"{path}.{key} is required", 400)
        additional = schema.get("additionalProperties", True)
        if additional is False:
            unknown = sorted(k for k in value if k not in properties)
            if unknown:
                raise_error("BAD_REQUEST", f"{path} contains unknown fields: {', '.join(unknown)}", 400)
        for key, child_schema in properties.items():
            if key in value:
                validate_schema_value(child_schema, value[key], f"{path}.{key}", raise_error=raise_error)
        return

    if expected_type == "array":
        if not isinstance(value, list):
            raise_error("BAD_REQUEST", f"{path} must be an array", 400)
        min_items = schema.get("minItems")
        max_items = schema.get("maxItems")
        if min_items is not None and len(value) < int(min_items):
            raise_error("BAD_REQUEST", f"{path} must contain at least {min_items} items", 400)
        if max_items is not None and len(value) > int(max_items):
            raise_error("BAD_REQUEST", f"{path} must contain at most {max_items} items", 400)
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                validate_schema_value(item_schema, item, f"{path}[{index}]", raise_error=raise_error)
        return

    if expected_type == "string":
        if not isinstance(value, str):
            raise_error("BAD_REQUEST", f"{path} must be a string", 400)
        if "enum" in schema and value not in schema["enum"]:
            raise_error("BAD_REQUEST", f"{path} must be one of: {', '.join(map(str, schema['enum']))}", 400)
        min_length = schema.get("minLength")
        max_length = schema.get("maxLength")
        if min_length is not None and len(value) < int(min_length):
            raise_error("BAD_REQUEST", f"{path} must be at least {min_length} characters", 400)
        if max_length is not None and len(value) > int(max_length):
            raise_error("BAD_REQUEST", f"{path} must be at most {max_length} characters", 400)
        return

    if expected_type == "integer":
        if isinstance(value, bool) or not isinstance(value, int):
            raise_error("BAD_REQUEST", f"{path} must be an integer", 400)
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and value < minimum:
            raise_error("BAD_REQUEST", f"{path} must be >= {minimum}", 400)
        if maximum is not None and value > maximum:
            raise_error("BAD_REQUEST", f"{path} must be <= {maximum}", 400)
        return

    if expected_type == "number":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise_error("BAD_REQUEST", f"{path} must be numeric", 400)
        minimum = schema.get("minimum")
        maximum = schema.get("maximum")
        if minimum is not None and value < minimum:
            raise_error("BAD_REQUEST", f"{path} must be >= {minimum}", 400)
        if maximum is not None and value > maximum:
            raise_error("BAD_REQUEST", f"{path} must be <= {maximum}", 400)
        return

    if expected_type == "boolean":
        if not isinstance(value, bool):
            raise_error("BAD_REQUEST", f"{path} must be a boolean", 400)
        return

    if "enum" in schema and value not in schema["enum"]:
        raise_error("BAD_REQUEST", f"{path} must be one of: {', '.join(map(str, schema['enum']))}", 400)


def validate_payload_schema(
    tool_name: str,
    schema: dict[str, Any] | None,
    payload: dict[str, Any],
    *,
    raise_error: Callable[[str, str, int], None],
) -> None:
    if not schema:
        return

    def prefixed(code: str, message: str, status: int) -> None:
        raise_error(code, f"{tool_name}: {message}", status)

    validate_schema_value(schema, payload, "payload", raise_error=prefixed)
