
from __future__ import annotations

import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, TypeAlias


ToolPayload: TypeAlias = dict[str, Any]
ToolResult: TypeAlias = dict[str, Any]


def _get_str(payload: ToolPayload, key: str, default: str = "") -> str:
    value = payload.get(key, default)
    return default if value is None else str(value)

def _get_bool(payload: ToolPayload, key: str, default: bool = False) -> bool:
    value = payload.get(key, default)
    return value if isinstance(value, bool) else bool(value)

def _get_int(payload: ToolPayload, key: str, default: int) -> int:
    try:
        return int(payload.get(key, default))
    except Exception:
        return default

def _get_list(payload: ToolPayload, key: str) -> list[Any]:
    value = payload.get(key)
    return value if isinstance(value, list) else []

def _project_id(payload: ToolPayload) -> str:
    return _get_str(payload, "project_id").strip()


def _payload_project_path(project_id: str, path: str | None = None) -> ToolPayload:
    payload: ToolPayload = {"project_id": project_id}
    if path is not None:
        payload["path"] = path
    return payload


def _optional_positive_int(payload: ToolPayload, key: str) -> int | None:
    raw = payload.get(key)
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except Exception:
        return None
    return value if value > 0 else None


def _string_list(payload: ToolPayload, key: str) -> list[str]:
    return [str(item) for item in _get_list(payload, key)]


def _object_list(payload: ToolPayload, key: str) -> list[ToolPayload]:
    return [item for item in _get_list(payload, key) if isinstance(item, dict)]


@dataclass(frozen=True)
class ProjectPathRequest:
    project_id: str
    path: str

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "ProjectPathRequest":
        return cls(project_id=_project_id(payload), path=_get_str(payload, "path"))


@dataclass(frozen=True)
class ProjectFilesListRequest:
    project_id: str
    path: str
    recursive: bool
    contains: str | None
    limit: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectFilesListRequest":
        return cls(
            project_id=_project_id(payload),
            path=normalize_project_path(payload),
            recursive=_get_bool(payload, "recursive", False),
            contains=_get_str(payload, "contains") or None,
            limit=_optional_positive_int(payload, "limit"),
        )


@dataclass(frozen=True)
class ProjectFilesReadRequest:
    project_id: str
    path: str
    start_line: int | None
    end_line: int | None
    max_bytes: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectFilesReadRequest":
        return cls(
            project_id=_project_id(payload),
            path=normalize_project_path(payload),
            start_line=_optional_positive_int(payload, "start_line"),
            end_line=_optional_positive_int(payload, "end_line"),
            max_bytes=_optional_positive_int(payload, "max_bytes"),
        )


@dataclass(frozen=True)
class ProjectFilesSearchRequest:
    project_id: str
    query: str
    path: str
    artifact_classes: list[str] | None
    recursive: bool
    limit: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectFilesSearchRequest":
        return cls(
            project_id=_project_id(payload),
            query=_get_str(payload, "query"),
            path=normalize_project_path(payload),
            artifact_classes=_string_list(payload, "artifact_classes") or None,
            recursive=_get_bool(payload, "recursive", True),
            limit=_optional_positive_int(payload, "limit"),
        )


@dataclass(frozen=True)
class ProjectContextRehydrateRequest:
    project_id: str
    topic: str
    path: str
    budget_bytes: int | None
    debug: bool

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectContextRehydrateRequest":
        return cls(
            project_id=_project_id(payload),
            topic=_get_str(payload, "topic"),
            path=normalize_project_path(payload),
            budget_bytes=_optional_positive_int(payload, "budget_bytes"),
            debug=_get_bool(payload, "debug", False),
        )


@dataclass(frozen=True)
class ProjectModelsListRequest:
    project_id: str
    path: str
    recursive: bool
    model_type: str
    limit: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectModelsListRequest":
        return cls(
            project_id=_project_id(payload),
            path=normalize_project_path(payload),
            recursive=_get_bool(payload, "recursive", True),
            model_type=_get_str(payload, "model_type", "auto"),
            limit=_optional_positive_int(payload, "limit"),
        )


@dataclass(frozen=True)
class ProjectModelInspectRequest:
    project_id: str
    path: str
    model_type: str

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "ProjectModelInspectRequest":
        return cls(
            project_id=_project_id(payload),
            path=_get_str(payload, "path"),
            model_type=_get_str(payload, "model_type", "auto"),
        )


@dataclass(frozen=True)
class ProjectArchivesListRequest:
    project_id: str
    path: str
    recursive: bool
    archive_type: str
    limit: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload, normalize_project_path: Callable[[ToolPayload], str]) -> "ProjectArchivesListRequest":
        return cls(
            project_id=_project_id(payload),
            path=normalize_project_path(payload),
            recursive=_get_bool(payload, "recursive", True),
            archive_type=_get_str(payload, "archive_type", "auto"),
            limit=_optional_positive_int(payload, "limit"),
        )


@dataclass(frozen=True)
class ProjectArchiveInspectRequest:
    project_id: str
    path: str
    archive_type: str
    max_entries: int | None

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "ProjectArchiveInspectRequest":
        return cls(
            project_id=_project_id(payload),
            path=_get_str(payload, "path"),
            archive_type=_get_str(payload, "archive_type", "auto"),
            max_entries=_optional_positive_int(payload, "max_entries"),
        )


@dataclass(frozen=True)
class ProjectArchiveExtractRequest:
    project_id: str
    path: str
    destination_path: str
    archive_type: str
    selected_entries: list[str]
    overwrite: bool

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "ProjectArchiveExtractRequest":
        return cls(
            project_id=_project_id(payload),
            path=_get_str(payload, "path"),
            destination_path=_get_str(payload, "destination_path"),
            archive_type=_get_str(payload, "archive_type", "auto"),
            selected_entries=_string_list(payload, "selected_entries"),
            overwrite=_get_bool(payload, "overwrite", False),
        )



@dataclass(frozen=True)
class ReadManyFileEntry:
    content: str = ""
    size_bytes: int = 0
    truncated: bool = False
    error: str | None = None

    @classmethod
    def from_read_result(cls, result: object) -> "ReadManyFileEntry":
        as_dict = result.to_dict() if hasattr(result, "to_dict") else result
        data = as_dict if isinstance(as_dict, dict) else {}
        return cls(
            content=_get_str(data, "content"),
            size_bytes=_get_int(data, "size_bytes", 0),
            truncated=_get_bool(data, "truncated", False),
        )

    @classmethod
    def from_error(cls, exc: Exception) -> "ReadManyFileEntry":
        return cls(error=str(exc))

    def to_dict(self) -> ToolResult:
        data: ToolResult = {
            "truncated": self.truncated,
            "size_bytes": self.size_bytes,
        }
        if self.error is not None:
            data["error"] = self.error
        else:
            data["content"] = self.content
        return data


@dataclass(frozen=True)
class ZipEntryReadResult:
    ok: bool
    entry_name: str
    content: str | None = None
    size_bytes: int | None = None
    truncated: bool | None = None
    error: str | None = None

    @classmethod
    def from_bridge_result(cls, entry_name: str, payload: ToolPayload) -> "ZipEntryReadResult":
        return cls(
            ok=_get_bool(payload, "ok", True),
            entry_name=entry_name,
            content=_get_str(payload, "content") if "content" in payload else None,
            size_bytes=_optional_positive_int(payload, "size_bytes"),
            truncated=_get_bool(payload, "truncated", False) if "truncated" in payload else None,
            error=_get_str(payload, "error") or None,
        )

    @classmethod
    def from_error(cls, entry_name: str, exc: Exception) -> "ZipEntryReadResult":
        return cls(ok=False, entry_name=entry_name, error=str(exc))

    def to_dict(self) -> ToolResult:
        data: ToolResult = {"ok": self.ok, "entry_name": self.entry_name}
        if self.content is not None:
            data["content"] = self.content
        if self.size_bytes is not None:
            data["size_bytes"] = self.size_bytes
        if self.truncated is not None:
            data["truncated"] = self.truncated
        if self.error is not None:
            data["error"] = self.error
        return data


@dataclass(frozen=True)
class ProjectRef:
    project_id: str

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "ProjectRef":
        project_id = _project_id(payload)
        return cls(project_id=project_id)


@dataclass(frozen=True)
class ProjectFilesReadManyRequest:
    project_id: str
    paths: list[str]
    max_bytes_each: int

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "ProjectFilesReadManyRequest":
        project_id = _project_id(payload)
        paths = [str(item) for item in _get_list(payload, "paths")]
        if not paths:
            raise error_cls("BAD_REQUEST", "paths must be a non-empty array", 400)
        if len(paths) > 50:
            raise error_cls("BAD_REQUEST", "paths limit is 50", 400)
        max_bytes_each = max(1, min(_get_int(payload, "max_bytes_each", _get_int(payload, "max_bytes", 50000)), 200000))
        return cls(project_id=project_id, paths=paths, max_bytes_each=max_bytes_each)


@dataclass(frozen=True)
class ProjectWriteRequest:
    project_id: str
    path: str
    content: str
    mode: str
    encoding: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], ensure_project_layout: Callable[[ToolPayload], str], payload: ToolPayload) -> "ProjectWriteRequest":
        project_id = ensure_project_layout(payload)
        rel_path = _get_str(payload, "path").strip()
        if not rel_path:
            raise error_cls("BAD_REQUEST", "path is required", 400)
        mode = _get_str(payload, "mode", "overwrite")
        if mode not in {"overwrite", "append", "create_only"}:
            raise error_cls("BAD_REQUEST", "mode must be overwrite, append, or create_only", 400)
        return cls(
            project_id=project_id,
            path=rel_path,
            content=_get_str(payload, "content"),
            mode=mode,
            encoding=_get_str(payload, "encoding", "utf-8"),
        )


@dataclass(frozen=True)
class FsTreeRequest:
    root: Path
    depth: int
    include_hidden: bool
    exclude_dirs: set[str]
    extensions: set[str] | None
    min_size_bytes: int
    limit: int

    @classmethod
    def from_payload(
        cls,
        payload: ToolPayload,
        *,
        error_cls: type[Exception],
        ensure_within_allowed: Callable[[Path], Path],
        resolve_general_path: Callable[..., Path],
        request_optional_positive_int: Callable[..., int | None],
    ) -> "FsTreeRequest":
        root = ensure_within_allowed(resolve_general_path(payload))
        if not root.exists():
            raise error_cls("NOT_FOUND", "root path not found", 404)
        ext_raw = _get_list(payload, "extensions") or None
        return cls(
            root=root,
            depth=max(1, min(_get_int(payload, "depth", 3), 10)),
            include_hidden=_get_bool(payload, "include_hidden", False),
            exclude_dirs=set(_get_list(payload, "exclude_dirs") or ["__pycache__", ".git", "node_modules", ".venv", ".venv_cuda", "vendor"]),
            extensions={str(x).lower() for x in ext_raw} if ext_raw else None,
            min_size_bytes=max(0, _get_int(payload, "min_size_bytes", 0)),
            limit=request_optional_positive_int(_get_int(payload, "limit", 500), 500, minimum=1),
        )


@dataclass(frozen=True)
class ZipReadRequest:
    zip_path: Path
    entries: list[str]
    max_entry_bytes: int

    @classmethod
    def from_payload(
        cls,
        payload: dict[str, Any],
        *,
        error_cls: type[Exception],
        ensure_within_allowed: Callable[[Path], Path],
        resolve_general_path: Callable[..., Path],
    ) -> "ZipReadRequest":
        zip_path = ensure_within_allowed(resolve_general_path(payload, "zip_path"))
        if not zip_path.exists():
            raise error_cls("NOT_FOUND", "zip archive not found", 404)
        return cls(
            zip_path=zip_path,
            entries=[str(item) for item in _get_list(payload, "entries")],
            max_entry_bytes=max(1024, min(_get_int(payload, "max_entry_bytes", 65536), 1048576)),
        )

def register_project_tools(
    register_tool: Callable[..., Callable[[Callable[[ToolPayload], ToolResult]], Callable[[ToolPayload], ToolResult]]],
    *,
    error_cls: type[Exception],
    context_wrap: Callable[[Callable[[], Any]], ToolResult],
    normalize_project_path: Callable[[ToolPayload, str | None], str | None],
    project_root_path: Callable[[str], str],
    list_files: Callable[..., Any],
    read_file: Callable[..., Any],
    search_files: Callable[..., Any],
    rehydrate_context: Callable[..., Any],
    list_models: Callable[..., Any],
    inspect_model: Callable[..., Any],
    list_archives: Callable[..., Any],
    inspect_archive: Callable[..., Any],
    extract_archive: Callable[..., Any],
    ensure_project_layout: Callable[[ToolPayload], str],
    get_project_root: Callable[[str], Path],
    ensure_parent: Callable[[Path], None],
    sha256_file: Callable[[Path], str],
    utc_now: Callable[[], str],
    request_optional_positive_int: Callable[..., int | None],
    ensure_within_allowed: Callable[[Path], Path],
    resolve_general_path: Callable[..., Path],
    bounded_zip_entry_text: Callable[[zipfile.ZipFile, str, int], dict[str, Any]],
    iter_tree: Callable[..., tuple[list[dict[str, Any]], bool]],
) -> None:
    @register_tool("project.files.list", "List files under a project path.", "low", category="project")
    def tool_project_files_list(payload: ToolPayload) -> ToolResult:
        request = ProjectFilesListRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: list_files(
            path=request.path,
            base_root=project_root_path(request.project_id),
            recursive=request.recursive,
            contains=request.contains,
            limit=request.limit,
        ))

    @register_tool("project.files.read", "Read one project file or a line range.", "low", category="project")
    def tool_project_files_read(payload: ToolPayload) -> ToolResult:
        request = ProjectFilesReadRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: read_file(
            path=request.path,
            base_root=project_root_path(request.project_id),
            start_line=request.start_line,
            end_line=request.end_line,
            max_bytes=request.max_bytes,
        ))

    @register_tool("project.files.search", "Search within project files.", "low", category="project")
    def tool_project_files_search(payload: ToolPayload) -> ToolResult:
        request = ProjectFilesSearchRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: search_files(
            query=request.query,
            base_root=project_root_path(request.project_id),
            path=request.path,
            artifact_classes=request.artifact_classes,
            recursive=request.recursive,
            limit=request.limit,
        ))

    @register_tool("project.context.rehydrate", "Rehydrate bounded project context on a topic.", "low", category="project")
    def tool_project_context_rehydrate(payload: ToolPayload) -> ToolResult:
        request = ProjectContextRehydrateRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: rehydrate_context(
            topic=request.topic,
            base_root=project_root_path(request.project_id),
            path=request.path,
            budget_bytes=request.budget_bytes,
            debug=request.debug,
        ))

    @register_tool("project.models.list", "List model artifacts in a project.", "low", category="project")
    def tool_project_models_list(payload: ToolPayload) -> ToolResult:
        request = ProjectModelsListRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: list_models(
            project_id=request.project_id,
            path=request.path,
            recursive=request.recursive,
            model_type=request.model_type,
            limit=request.limit,
        ))

    @register_tool("project.models.inspect", "Inspect a model artifact in a project.", "low", category="project")
    def tool_project_models_inspect(payload: ToolPayload) -> ToolResult:
        request = ProjectModelInspectRequest.from_payload(payload)
        return context_wrap(lambda: inspect_model(
            project_id=request.project_id,
            path=request.path,
            model_type=request.model_type,
        ))

    @register_tool("project.archives.list", "List archive artifacts in a project.", "low", category="project")
    def tool_project_archives_list(payload: ToolPayload) -> ToolResult:
        request = ProjectArchivesListRequest.from_payload(payload, normalize_project_path)
        return context_wrap(lambda: list_archives(
            project_id=request.project_id,
            path=request.path,
            recursive=request.recursive,
            archive_type=request.archive_type,
            limit=request.limit,
        ))

    @register_tool("project.archives.inspect", "Inspect an archive in a project.", "low", category="project")
    def tool_project_archives_inspect(payload: ToolPayload) -> ToolResult:
        request = ProjectArchiveInspectRequest.from_payload(payload)
        return context_wrap(lambda: inspect_archive(
            project_id=request.project_id,
            path=request.path,
            archive_type=request.archive_type,
            max_entries=request.max_entries,
        ))

    @register_tool("project.archives.extract", "Extract an archive within a project.", "high", category="project", approval_required=True, mutating=True)
    def tool_project_archives_extract(payload: ToolPayload) -> ToolResult:
        request = ProjectArchiveExtractRequest.from_payload(payload)
        return context_wrap(lambda: extract_archive(
            project_id=request.project_id,
            path=request.path,
            destination_path=request.destination_path,
            archive_type=request.archive_type,
            selected_entries=request.selected_entries,
            overwrite=request.overwrite,
        ))

    @register_tool("project.files.read_many", "Read many project files in a single dispatch.", "medium", category="project")
    def tool_project_files_read_many(payload: ToolPayload) -> ToolResult:
        request = ProjectFilesReadManyRequest.from_payload(error_cls, payload)
        root = get_project_root(request.project_id)
        files: dict[str, ToolResult] = {}
        error_count = 0
        for path in request.paths:
            try:
                result = read_file(path=path, base_root=str(root), max_bytes=request.max_bytes_each)
                files[path] = ReadManyFileEntry.from_read_result(result).to_dict()
            except Exception as exc:
                files[path] = ReadManyFileEntry.from_error(exc).to_dict()
                error_count += 1
        return {"project_id": request.project_id, "files": files, "read_count": len(request.paths) - error_count, "error_count": error_count}

    @register_tool("project.files.write", "Write or append a project file directly.", "high", category="project", approval_required=True, mutating=True)
    def tool_project_files_write(payload: ToolPayload) -> ToolResult:
        request = ProjectWriteRequest.from_payload(error_cls, ensure_project_layout, payload)
        root = get_project_root(request.project_id)
        target = (root / request.path).resolve()
        if root.resolve() not in [target, *target.parents]:
            raise error_cls("BAD_PATH", "path escapes project root", 400)
        if request.mode == "create_only" and target.exists():
            raise error_cls("ALREADY_EXISTS", "file exists and mode=create_only", 409)
        ensure_parent(target)
        if request.mode == "append":
            with target.open("a", encoding=request.encoding) as handle:
                handle.write(request.content)
        else:
            target.write_text(request.content, encoding=request.encoding)
        return {
            "project_id": request.project_id,
            "path": str(target.relative_to(root)),
            "absolute_path": str(target),
            "bytes_written": target.stat().st_size,
            "sha256": sha256_file(target),
            "time": utc_now(),
        }

    @register_tool("fs.tree", "Traverse a filesystem tree from a mounted or absolute path.", "high", category="filesystem", approval_required=True)
    def tool_fs_tree(payload: ToolPayload) -> ToolResult:
        request = FsTreeRequest.from_payload(
            payload,
            error_cls=error_cls,
            ensure_within_allowed=ensure_within_allowed,
            resolve_general_path=resolve_general_path,
            request_optional_positive_int=request_optional_positive_int,
        )
        items, partial = iter_tree(
            request.root,
            request.depth,
            request.include_hidden,
            request.exclude_dirs,
            request.extensions,
            request.min_size_bytes,
            request.limit,
        )
        return {"root": str(request.root), "count": len(items), "partial": partial, "items": items}

    @register_tool("zip.read", "List or read entries from a mounted or absolute zip archive.", "medium", category="filesystem")
    def tool_zip_read(payload: ToolPayload) -> ToolResult:
        request = ZipReadRequest.from_payload(
            payload,
            error_cls=error_cls,
            ensure_within_allowed=ensure_within_allowed,
            resolve_general_path=resolve_general_path,
        )
        with zipfile.ZipFile(request.zip_path, "r") as zf:
            listing = [{"name": info.filename, "file_size": info.file_size, "compress_size": info.compress_size, "is_dir": info.is_dir()} for info in zf.infolist()]
            contents: dict[str, ToolResult] = {}
            for name in request.entries:
                key = str(name)
                try:
                    contents[key] = ZipEntryReadResult.from_bridge_result(key, bounded_zip_entry_text(zf, key, request.max_entry_bytes)).to_dict()
                except Exception as exc:
                    contents[key] = ZipEntryReadResult.from_error(key, exc).to_dict()
        return {"zip_path": str(request.zip_path), "listing": listing, "contents": contents}
