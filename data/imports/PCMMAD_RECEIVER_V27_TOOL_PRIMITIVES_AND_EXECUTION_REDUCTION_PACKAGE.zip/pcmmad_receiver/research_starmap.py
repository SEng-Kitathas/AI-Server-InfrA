from __future__ import annotations

from typing import Any

from research_models import EvidenceTopology, TopHit, TopologyCluster, TopologySummary


def build_evidence_topology(ranked_results: list[Any]) -> EvidenceTopology:
    """
    Build a simple Gen-1.5 evidence geometry surface from ranked results.
    This is intentionally lightweight:
    - top hits
    - category clusters
    - lineage hints
    - integrity summary
    """
    if not ranked_results:
        return EvidenceTopology(
            layer="gen1_5",
            candidate_count=0,
            clusters=[],
            topology_summary=TopologySummary(dominant_categories=[], lineage_hints=[], integrity="empty"),
            top_hits=[],
        )

    cat_counts: dict[str, int] = {}
    lineage_hints: list[str] = []

    for entry in ranked_results:
        paper = entry.paper if hasattr(entry, "paper") else entry.get("paper", {})
        for cat in paper.get("categories", []):
            cat_counts[cat] = cat_counts.get(cat, 0) + 1

        title = (paper.get("title") or "").lower()
        if "transformer-xl" in title:
            lineage_hints.append("transformer_xl")
        if "compressive transformer" in title or "compressive transformers" in title:
            lineage_hints.append("compressive_transformer")
        if "memorizing transformer" in title or "memorizing transformers" in title:
            lineage_hints.append("memorizing_transformer")
        if "mamba" in title:
            lineage_hints.append("mamba")
        if "rwkv" in title:
            lineage_hints.append("rwkv")
        if "retnet" in title:
            lineage_hints.append("retnet")

    dominant_categories = [
        {"category": k, "count": v}
        for k, v in sorted(cat_counts.items(), key=lambda kv: kv[1], reverse=True)[:5]
    ]

    uniq_lineage: list[str] = []
    for x in lineage_hints:
        if x not in uniq_lineage:
            uniq_lineage.append(x)

    top_hits: list[TopHit] = []
    for entry in ranked_results[:5]:
        paper = entry.paper if hasattr(entry, "paper") else entry.get("paper", {})
        rank = entry.rank if hasattr(entry, "rank") else entry.get("rank")
        signal_score = entry.signal_score if hasattr(entry, "signal_score") else entry.get("signal_score")
        top_hits.append(
            TopHit(
                rank=rank,
                signal_score=signal_score,
                paper_id=paper.get("paper_id"),
                title=paper.get("title"),
                updated=paper.get("updated"),
            )
        )

    first_score = ranked_results[0].signal_score if hasattr(ranked_results[0], "signal_score") else ranked_results[0].get("signal_score", 0)
    integrity = "coherent" if first_score >= 2.0 else "weak"

    return EvidenceTopology(
        layer="gen1_5",
        candidate_count=len(ranked_results),
        top_hits=top_hits,
        clusters=[
            TopologyCluster(label="dominant_categories", items=dominant_categories),
            TopologyCluster(label="lineage_hints", items=uniq_lineage),
        ],
        topology_summary=TopologySummary(
            dominant_categories=dominant_categories,
            lineage_hints=uniq_lineage,
            integrity=integrity,
        ),
    )
