from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable


class DictSerializable:
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _as_str(value: Any, default: str = "") -> str:
    return default if value is None else str(value)


def _as_optional_str(value: Any) -> str | None:
    return None if value is None else str(value)


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value if value is not None else default)
    except Exception:
        return default


def _as_list_of_str(value: Any) -> list[str]:
    return [str(item) for item in value] if isinstance(value, list) else []


def _as_mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_str_dict(value: Any) -> dict[str, Any]:
    return {str(k): v for k, v in _as_mapping(value).items()}


def _record_list(value: Any, record_cls: type[Any]) -> list[Any]:
    return [record_cls.from_dict(item) for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def _record_or_none(value: Any, record_cls: type[Any]) -> Any | None:
    return record_cls.from_dict(value) if isinstance(value, dict) else None


def _extra_fields(mapped: dict[str, Any], core_keys: set[str]) -> dict[str, Any]:
    return {str(k): v for k, v in mapped.items() if k not in core_keys}


def _failure_digest_or_none(value: Any) -> "ExecutionFailureDigest | None":
    return ExecutionFailureDigest.from_dict(value) if isinstance(value, dict) else None


def _as_float(value: Any, default: float | None = None) -> float | None:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except Exception:
        return default


def _as_optional_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except Exception:
        return None


def _as_optional_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except Exception:
        return None


def _as_optional_bool(value: Any) -> bool | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
    return bool(value)


@dataclass
class SchedulerTelemetry(DictSerializable):
    iterations: int = 0
    last_tick_at: str | None = None
    last_error: str | None = None
    jobs_started: int = 0
    jobs_completed: int = 0
    jobs_failed: int = 0
    jobs_timed_out: int = 0
    jobs_reconciled: int = 0
    scheduler_startups: int = 0

    def inc(self, name: str, amount: int = 1) -> None:
        setattr(self, name, int(getattr(self, name, 0)) + amount)

    def set(self, name: str, value: Any) -> None:
        setattr(self, name, value)


@dataclass
class BatchExecutorTelemetry(DictSerializable):
    foreground_parallel_dispatches: int = 0
    background_batches_completed: int = 0
    background_batches_failed: int = 0
    background_batches_active: int = 0
    last_background_error: str | None = None

    def inc(self, name: str, amount: int = 1) -> None:
        setattr(self, name, int(getattr(self, name, 0)) + amount)

    def set(self, name: str, value: Any) -> None:
        setattr(self, name, value)




@dataclass(frozen=True)
class ExecutionFailureDigest:
    job_id: str
    project_id: str
    failure_kind: str
    execution_state: str
    stage: str
    host_preempted: bool
    exit_code: int | None = None
    signal: str | None = None
    artifact_registration_status: str = "not_attempted"
    time_started: str | None = None
    time_ended: str | None = None
    duration_ms: int | None = None
    retryable: bool = False
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionFailureDigest":
        core_keys = {
            "job_id", "project_id", "failure_kind", "execution_state", "stage",
            "host_preempted", "exit_code", "signal", "artifact_registration_status",
            "time_started", "time_ended", "duration_ms", "retryable",
        }
        mapped = _as_mapping(data)
        return cls(
            job_id=_as_str(mapped.get("job_id")),
            project_id=_as_str(mapped.get("project_id")),
            failure_kind=_as_str(mapped.get("failure_kind")),
            execution_state=_as_str(mapped.get("execution_state")),
            stage=_as_str(mapped.get("stage")),
            host_preempted=bool(mapped.get("host_preempted", False)),
            exit_code=_as_optional_int(mapped.get("exit_code")),
            signal=_as_optional_str(mapped.get("signal")),
            artifact_registration_status=_as_str(mapped.get("artifact_registration_status"), "not_attempted"),
            time_started=_as_optional_str(mapped.get("time_started")),
            time_ended=_as_optional_str(mapped.get("time_ended")),
            duration_ms=_as_optional_int(mapped.get("duration_ms")),
            retryable=bool(mapped.get("retryable", False)),
            extra=_extra_fields(mapped, core_keys),
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        extra = data.pop("extra", {})
        data.update(extra)
        return data


@dataclass(frozen=True)
class CapacitySnapshot:
    running_global: int
    running_project: int
    global_limit: int | None
    project_limit: int | None
    queued_global: int
    queued_project: int
    global_queue_limit: int | None
    project_queue_limit: int | None


@dataclass(frozen=True)
class GlobalExecutionSnapshot:
    running: int
    queued: int
    global_limit: int
    global_queue_limit: int
    oldest_queued_age_seconds: float | None


@dataclass(frozen=True)
class CorruptJobFileRecord:
    path: str
    error: str


@dataclass(frozen=True)
class ExecutionReadinessEnvelope:
    status: str
    global_snapshot: GlobalExecutionSnapshot
    per_project: dict[str, CapacitySnapshot]
    corrupt_job_files: list[str]
    unsupervised_jobs: list[str]
    drain_batch: int
    scheduler_thread_alive: bool
    scheduler_telemetry: SchedulerTelemetry

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "global": self.global_snapshot.to_dict(),
            "per_project": {k: v.to_dict() for k, v in self.per_project.items()},
            "corrupt_job_files": self.corrupt_job_files,
            "unsupervised_jobs": self.unsupervised_jobs,
            "drain_batch": self.drain_batch,
            "scheduler_thread_alive": self.scheduler_thread_alive,
            "scheduler_telemetry": self.scheduler_telemetry.to_dict(),
        }


@dataclass(frozen=True)
class ExecutionCapabilitiesEnvelope:
    execution_enabled: bool
    execution_modes: list[str]
    max_timeout_seconds: int
    default_timeout_seconds: int
    max_stdout_bytes: int
    max_stderr_bytes: int
    artifact_registration_enabled: bool
    termination_enabled: bool
    global_concurrency_limit: int
    per_project_concurrency_limit: int
    global_queue_limit: int
    per_project_queue_limit: int
    scheduler_interval_seconds: float
    background_scheduler: bool
    scheduler_alive: bool


@dataclass
class TextWindow:
    mode: str
    file_size: int
    requested_bytes: int | None
    returned_bytes: int
    offset_bytes: int | None = None


@dataclass
class BackgroundResultEnvelope:
    project_id: str
    handle: str
    label: str
    tool_name: str
    created_at: str
    payload: object


@dataclass
class ExecutionJobRecord:
    project_id: str
    job_id: str
    status: str
    stage: str
    execution_mode: str
    replay_of: str | None
    command: list[str]
    cwd: str
    cwd_rel: str
    submitted_at: str
    started_at: str | None = None
    deadline_epoch: float | None = None
    timeout_seconds: int | None = None
    stdout_path: str = ""
    stderr_path: str = ""
    stdout_max_bytes: int | None = None
    stderr_max_bytes: int | None = None
    result_artifact_targets: list[object] = field(default_factory=list)
    artifact_registration_status: str = "not_attempted"
    truth_gate: str = "not_evaluated"
    resource_gate: str = "not_evaluated"
    feasibility_gate: str = "not_evaluated"
    journal_on_submit: bool = True
    journal_on_complete: bool = False
    journal_on_failure: bool = True
    checkpoint_on_complete: bool = False
    local_model_id: str | None = None
    agent_role: str | None = None
    idempotency_key: str = ""
    submission_fingerprint: str = ""
    env_allowlist: dict[str, str] = field(default_factory=dict)
    queue_position: int | None = None
    pid: int | None = None
    finished_at: str | None = None
    duration_ms: int | None = None
    return_code: int | None = None
    failure_digest: dict[str, Any] | ExecutionFailureDigest | None = None
    supervision_state: str | None = None
    replayed: bool | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionJobRecord":
        known = {f.name for f in cls.__dataclass_fields__.values() if f.name != "extra"}
        extra = {k: v for k, v in data.items() if k not in known}
        mapped = _as_mapping(data)
        failure_digest = _failure_digest_or_none(mapped.get("failure_digest"))
        rec = cls(
            project_id=_as_str(mapped.get("project_id")),
            job_id=_as_str(mapped.get("job_id")),
            status=_as_str(mapped.get("status")),
            stage=_as_str(mapped.get("stage")),
            execution_mode=_as_str(mapped.get("execution_mode")),
            replay_of=_as_optional_str(mapped.get("replay_of")),
            command=_as_list_of_str(mapped.get("command")),
            cwd=_as_str(mapped.get("cwd")),
            cwd_rel=_as_str(mapped.get("cwd_rel"), "."),
            submitted_at=_as_str(mapped.get("submitted_at")),
            started_at=_as_optional_str(mapped.get("started_at")),
            deadline_epoch=_as_optional_float(mapped.get("deadline_epoch")),
            timeout_seconds=_as_optional_int(mapped.get("timeout_seconds")),
            stdout_path=_as_str(mapped.get("stdout_path")),
            stderr_path=_as_str(mapped.get("stderr_path")),
            stdout_max_bytes=_as_optional_int(mapped.get("stdout_max_bytes")),
            stderr_max_bytes=_as_optional_int(mapped.get("stderr_max_bytes")),
            result_artifact_targets=mapped.get("result_artifact_targets") if isinstance(mapped.get("result_artifact_targets"), list) else [],
            artifact_registration_status=_as_str(mapped.get("artifact_registration_status"), "not_attempted"),
            truth_gate=_as_str(mapped.get("truth_gate"), "not_evaluated"),
            resource_gate=_as_str(mapped.get("resource_gate"), "not_evaluated"),
            feasibility_gate=_as_str(mapped.get("feasibility_gate"), "not_evaluated"),
            journal_on_submit=bool(mapped.get("journal_on_submit", True)),
            journal_on_complete=bool(mapped.get("journal_on_complete", False)),
            journal_on_failure=bool(mapped.get("journal_on_failure", True)),
            checkpoint_on_complete=bool(mapped.get("checkpoint_on_complete", False)),
            local_model_id=_as_optional_str(mapped.get("local_model_id")),
            agent_role=_as_optional_str(mapped.get("agent_role")),
            idempotency_key=_as_str(mapped.get("idempotency_key")),
            submission_fingerprint=_as_str(mapped.get("submission_fingerprint")),
            env_allowlist={str(k): str(v) for k, v in mapped.get("env_allowlist", {}).items()} if isinstance(mapped.get("env_allowlist"), dict) else {},
            queue_position=_as_optional_int(mapped.get("queue_position")),
            pid=_as_optional_int(mapped.get("pid")),
            finished_at=_as_optional_str(mapped.get("finished_at")),
            duration_ms=_as_optional_int(mapped.get("duration_ms")),
            return_code=_as_optional_int(mapped.get("return_code")),
            failure_digest=failure_digest if isinstance(failure_digest, (dict, ExecutionFailureDigest)) or failure_digest is None else None,
            supervision_state=_as_optional_str(mapped.get("supervision_state")),
            replayed=_as_optional_bool(mapped.get("replayed")),
        )
        rec.extra = extra
        return rec

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        if isinstance(self.failure_digest, ExecutionFailureDigest):
            d["failure_digest"] = self.failure_digest.to_dict()
        extra = d.pop("extra", {})
        d.update(extra)
        return d

    # compatibility helpers so the rest of the file can be migrated incrementally
    def get(self, key: str, default: Any = None) -> Any:
        if hasattr(self, key):
            return getattr(self, key)
        return self.extra.get(key, default)

    def __getitem__(self, key: str) -> Any:
        if hasattr(self, key):
            return getattr(self, key)
        return self.extra[key]

    def __setitem__(self, key: str, value: Any) -> None:
        if hasattr(self, key):
            setattr(self, key, value)
        else:
            self.extra[key] = value

    def setdefault(self, key: str, default: Any) -> Any:
        current = self.get(key, None)
        if current is None:
            self[key] = default
            return default
        return current



@dataclass(frozen=True)
class ExecutionSubmitPayload(DictSerializable):
    project_id: str
    execution_mode: str
    command: list[str]
    cwd: str
    cwd_rel: str
    timeout_seconds: int | None
    stdout_max_bytes: int | None
    stderr_max_bytes: int | None
    env_allowlist: dict[str, str] = field(default_factory=dict)
    result_artifact_targets: list[object] = field(default_factory=list)
    local_model_id: str | None = None
    agent_role: str | None = None
    journal_on_submit: bool = True
    journal_on_complete: bool = False
    journal_on_failure: bool = True
    checkpoint_on_complete: bool = False
    idempotency_key: str = ""
    replay_of: str | None = None
    submission_fingerprint: str = ""


@dataclass(frozen=True)
class ExecutionIdempotencyRecord(DictSerializable):
    job_id: str
    submission_fingerprint: str
    recorded_at: str


@dataclass
class ExecutionIdempotencyLedger:
    keys: dict[str, ExecutionIdempotencyRecord] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionIdempotencyLedger":
        raw = _as_mapping(data).get("keys", {})
        keys: dict[str, ExecutionIdempotencyRecord] = {}
        if isinstance(raw, dict):
            for key, value in raw.items():
                if isinstance(key, str):
                    record = _record_or_none(value, ExecutionIdempotencyRecord)
                    if record is not None:
                        keys[key] = record
        return cls(keys=keys)

    def to_dict(self) -> dict[str, Any]:
        return {"keys": {k: v.to_dict() for k, v in self.keys.items()}}


@dataclass(frozen=True)
class ExecutionRegistrationRecord(DictSerializable):
    project_id: str
    session_id: str | None
    commit_id: str
    idempotency_key: str
    artifact_class: str
    logical_name: str
    operation: str
    path: str
    sha256: str
    bytes: int
    time: str



@dataclass(frozen=True)
class PluginLoadRecord(DictSerializable):
    module: str
    path: str


@dataclass(frozen=True)
class BlueprintLoadResult(DictSerializable):
    module: str
    blueprint: str
    error: str | None = None


@dataclass
class BootReport:
    loaded: list[BlueprintLoadResult] = field(default_factory=list)
    required_failed: list[BlueprintLoadResult] = field(default_factory=list)
    optional_failed: list[BlueprintLoadResult] = field(default_factory=list)

    def record_loaded(self, *, module: str, blueprint: str) -> None:
        self.loaded.append(BlueprintLoadResult(module=module, blueprint=blueprint))

    def record_failure(self, *, module: str, blueprint: str, error: str, required: bool) -> None:
        item = BlueprintLoadResult(module=module, blueprint=blueprint, error=error)
        if required:
            self.required_failed.append(item)
        else:
            self.optional_failed.append(item)

    def degraded(self) -> bool:
        return bool(self.optional_failed or self.required_failed)

    def to_dict(self) -> dict[str, Any]:
        return {
            "loaded": [item.to_dict() for item in self.loaded],
            "required_failed": [item.to_dict() for item in self.required_failed],
            "optional_failed": [item.to_dict() for item in self.optional_failed],
        }


@dataclass
class BootRuntimeStatus(DictSerializable):
    execution_started: bool = False
    lab_executor_started: bool = False
    execution_error: str | None = None
    lab_executor_error: str | None = None

    def degraded(self) -> bool:
        return bool(self.execution_error or self.lab_executor_error)


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    danger_tier: str = "medium"
    category: str = "general"
    tags: list[str] = field(default_factory=list)
    approval_required: bool = False
    mutating: bool = False
    input_schema: dict[str, Any] = field(default_factory=lambda: {"type": "object"})
    handler: Callable[[dict[str, Any]], dict[str, Any]] | None = None

    def to_card(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "danger_tier": self.danger_tier,
            "category": self.category,
            "tags": list(self.tags),
            "approval_required": self.approval_required,
            "mutating": self.mutating,
            "input_schema": self.input_schema,
        }


@dataclass(frozen=True)
class CapabilityFamilyCard(DictSerializable):
    name: str
    tool_count: int
    mutating_tools: int
    approval_required_tools: int
    danger_tiers: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CompactControlSurfaceDescriptor(DictSerializable):
    operation_budget: int
    action_count: int
    purpose: str
    note: str


@dataclass(frozen=True)
class ServerCapabilityRouterDescriptor:
    dispatch_entrypoint: str
    batch_entrypoint: str
    result_handle_entrypoint: str
    larger_server_native_capability_set: bool
    families: list[CapabilityFamilyCard] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["families"] = [f.to_dict() for f in self.families]
        return data




@dataclass(frozen=True)
class ToolRouterValidationState:
    api_valid: bool
    connected: bool
    validation_mode: str
    checked_at: str
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        if self.reason is None:
            data.pop("reason", None)
        return data

@dataclass(frozen=True)
class ToolCatalogResponse:
    ok: bool
    count: int
    tools: list[dict[str, Any]]
    compact_control_surface: CompactControlSurfaceDescriptor
    server_native_router: ServerCapabilityRouterDescriptor
    validation: ToolRouterValidationState

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "count": self.count,
            "tools": list(self.tools),
            "compact_control_surface": self.compact_control_surface.to_dict(),
            "server_native_router": self.server_native_router.to_dict(),
            "validation": self.validation.to_dict(),
        }


@dataclass(frozen=True)
class CompactCapabilitiesEnvelope:
    ok: bool
    time: str
    capabilities: dict[str, Any]
    limits: dict[str, Any]
    compact_control_surface: CompactControlSurfaceDescriptor
    server_native_router: ServerCapabilityRouterDescriptor

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "time": self.time,
            "capabilities": dict(self.capabilities),
            "limits": dict(self.limits),
            "compact_control_surface": self.compact_control_surface.to_dict(),
            "server_native_router": self.server_native_router.to_dict(),
        }


@dataclass(frozen=True)
class ToolResultEnvelope:
    ok: bool
    tool: str
    danger_tier: str
    policy_mode: str
    approved: bool
    time: str
    result: dict[str, Any]
    warning: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        if self.warning is None:
            data.pop("warning", None)
        return data


@dataclass(frozen=True)
class ManifestEntryRecord(DictSerializable):
    artifact_class: str
    sha256: str
    bytes: int
    updated_at: str

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ManifestEntryRecord":
        data = _as_mapping(raw)
        return cls(
            artifact_class=_as_str(data.get("artifact_class")),
            sha256=_as_str(data.get("sha256")),
            bytes=_as_int(data.get("bytes")),
            updated_at=_as_str(data.get("updated_at")),
        )


@dataclass
class ManifestDocument:
    updated_at: str | None = None
    files: dict[str, ManifestEntryRecord] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: dict[str, Any] | None) -> "ManifestDocument":
        data = _as_mapping(raw)
        files_raw = data.get("files", {})
        files: dict[str, ManifestEntryRecord] = {}
        if isinstance(files_raw, dict):
            for rel, entry in files_raw.items():
                if isinstance(rel, str):
                    record = _record_or_none(entry, ManifestEntryRecord)
                    if record is not None:
                        files[rel] = record
        updated = data.get("updated_at")
        return cls(updated_at=_as_optional_str(updated), files=files)

    def to_dict(self) -> dict[str, Any]:
        return {
            "updated_at": self.updated_at,
            "files": {rel: entry.to_dict() for rel, entry in self.files.items()},
        }


@dataclass(frozen=True)
class CommitLedgerRecord(DictSerializable):
    project_id: str
    session_id: str
    commit_id: str
    idempotency_key: str
    artifact_class: str
    logical_name: str
    operation: str
    path: str
    sha256: str
    bytes: int
    time: str

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "CommitLedgerRecord":
        data = _as_mapping(raw)
        return cls(
            project_id=_as_str(data.get("project_id")),
            session_id=_as_str(data.get("session_id")),
            commit_id=_as_str(data.get("commit_id")),
            idempotency_key=_as_str(data.get("idempotency_key")),
            artifact_class=_as_str(data.get("artifact_class")),
            logical_name=_as_str(data.get("logical_name")),
            operation=_as_str(data.get("operation")),
            path=_as_str(data.get("path")),
            sha256=_as_str(data.get("sha256")),
            bytes=_as_int(data.get("bytes")),
            time=_as_str(data.get("time")),
        )


@dataclass(frozen=True)
class SessionNoteRecord(DictSerializable):
    time: str
    type: str
    note: str

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "SessionNoteRecord":
        data = _as_mapping(raw)
        return cls(
            time=_as_str(data.get("time")),
            type=_as_str(data.get("type"), "note"),
            note=_as_str(data.get("note")),
        )


@dataclass(frozen=True)
class ReflexionRecord(DictSerializable):
    time: str
    session_id: str | None = None
    title: str = ""
    content: str = ""
    tags: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "ReflexionRecord":
        data = _as_mapping(raw)
        return cls(
            time=_as_str(data.get("time")),
            session_id=_as_optional_str(data.get("session_id")),
            title=_as_str(data.get("title")),
            content=_as_str(data.get("content")),
            tags=_as_list_of_str(data.get("tags")),
        )


@dataclass(frozen=True)
class AndonEventRecord(DictSerializable):
    time: str
    session_id: str | None = None
    reason: str = ""
    details: str = ""

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "AndonEventRecord":
        data = _as_mapping(raw)
        return cls(
            time=_as_str(data.get("time")),
            session_id=_as_optional_str(data.get("session_id")),
            reason=_as_str(data.get("reason")),
            details=_as_str(data.get("details")),
        )


@dataclass
class LabSessionRecord:
    project_id: str
    session_id: str
    title: str = ""
    status: str = "active"
    created_at: str = ""
    updated_at: str = ""
    meta: dict[str, Any] = field(default_factory=dict)
    notes: list[SessionNoteRecord] = field(default_factory=list)
    andon_events: list[AndonEventRecord] = field(default_factory=list)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "LabSessionRecord":
        data = _as_mapping(raw)
        return cls(
            project_id=_as_str(data.get("project_id")),
            session_id=_as_str(data.get("session_id")),
            title=_as_str(data.get("title")),
            status=_as_str(data.get("status"), "active"),
            created_at=_as_str(data.get("created_at")),
            updated_at=_as_str(data.get("updated_at")),
            meta=_as_str_dict(data.get("meta", {})),
            notes=_record_list(data.get("notes"), SessionNoteRecord),
            andon_events=_record_list(data.get("andon_events"), AndonEventRecord),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "project_id": self.project_id,
            "session_id": self.session_id,
            "title": self.title,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "meta": dict(self.meta),
            "notes": [note.to_dict() for note in self.notes],
            "andon_events": [event.to_dict() for event in self.andon_events],
        }