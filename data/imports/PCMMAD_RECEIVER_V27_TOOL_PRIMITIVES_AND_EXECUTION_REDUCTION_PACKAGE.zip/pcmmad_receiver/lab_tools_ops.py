from __future__ import annotations

import subprocess
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Callable


def register_ops_tools(
    register_tool: Callable[..., Callable[[Callable[[dict[str, Any]], dict[str, Any]]], Callable[[dict[str, Any]], dict[str, Any]]]],
    *,
    error_cls: type[Exception],
    get_project_root: Callable[[str], Path],
    resolve_cwd: Callable[[str, str | None], Path],
    exec_env: Callable[[dict[str, Any]], dict[str, str]],
    append_reflexion: Callable[[str, dict[str, Any]], Any],
    beautiful_soup: Any,
) -> None:
    @register_tool("git.status", "Read git status, branch, and dirty state for a project repo.", "medium", category="git")
    def tool_git_status(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        root = get_project_root(project_id)
        proc = subprocess.run(["git", "status", "--short", "--branch"], cwd=str(root), capture_output=True, text=True, timeout=30)
        return {"project_id": project_id, "return_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}

    @register_tool("git.diff", "Read a git diff for a project repo.", "medium", category="git")
    def tool_git_diff(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        root = get_project_root(project_id)
        args = ["git", "diff"]
        if payload.get("cached"):
            args.append("--cached")
        proc = subprocess.run(args, cwd=str(root), capture_output=True, text=True, timeout=30)
        return {"project_id": project_id, "return_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}

    @register_tool("git.commit", "Commit current repo changes with an explicit message.", "critical", category="git", approval_required=True, mutating=True)
    def tool_git_commit(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        message = str(payload.get("message", "")).strip()
        if not message:
            raise error_cls("BAD_REQUEST", "message is required", 400)
        root = get_project_root(project_id)
        add_proc = subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True, text=True, timeout=30)
        commit_cmd = ["git", "commit", "-m", message]
        if payload.get("sign"):
            commit_cmd.insert(2, "-S")
        commit_proc = subprocess.run(commit_cmd, cwd=str(root), capture_output=True, text=True, timeout=60)
        return {"project_id": project_id, "add_return_code": add_proc.returncode, "return_code": commit_proc.returncode, "stdout": commit_proc.stdout, "stderr": commit_proc.stderr}

    @register_tool("git.reset_hard", "Hard reset repo to a target ref.", "critical", category="git", approval_required=True, mutating=True)
    def tool_git_reset_hard(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        target = str(payload.get("target", "HEAD"))
        root = get_project_root(project_id)
        proc = subprocess.run(["git", "reset", "--hard", target], cwd=str(root), capture_output=True, text=True, timeout=60)
        return {"project_id": project_id, "target": target, "return_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}

    @register_tool("git.clean", "Remove untracked files and directories.", "critical", category="git", approval_required=True, mutating=True)
    def tool_git_clean(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        root = get_project_root(project_id)
        args = ["git", "clean", "-fd"]
        if payload.get("x"):
            args.append("-x")
        proc = subprocess.run(args, cwd=str(root), capture_output=True, text=True, timeout=60)
        return {"project_id": project_id, "return_code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}

    @register_tool("verify.gates", "Run ordered verification gates like lint, test, and custom commands.", "high", category="verify", approval_required=True)
    def tool_verify_gates(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = str(payload.get("project_id", "")).strip()
        cwd = resolve_cwd(project_id, payload.get("cwd"))
        gates = payload.get("gates") or []
        if not isinstance(gates, list) or not gates:
            raise error_cls("BAD_REQUEST", "gates must be a non-empty array", 400)
        stop_on_fail = bool(payload.get("stop_on_fail", True))
        timeout_each = max(1, min(int(payload.get("timeout_each", 120)), 600))
        env = exec_env(payload)
        results = []
        overall = "passed"
        for gate in gates:
            if not isinstance(gate, dict):
                raise error_cls("BAD_REQUEST", "each gate must be an object", 400)
            name = str(gate.get("name", "gate"))
            command = gate.get("command")
            if not isinstance(command, list) or not command or not all(isinstance(x, str) and x for x in command):
                raise error_cls("BAD_REQUEST", f"gate {name} has invalid command", 400)
            proc = subprocess.run(command, cwd=str(cwd), env=env, capture_output=True, text=True, timeout=timeout_each, shell=False)
            row = {"name": name, "command": command, "return_code": proc.returncode, "passed": proc.returncode == 0, "stdout": proc.stdout[-50000:], "stderr": proc.stderr[-50000:]}
            results.append(row)
            if proc.returncode != 0:
                overall = "failed"
                append_reflexion(project_id, {"title": f"gate_failed:{name}", "content": proc.stderr[-4000:] or proc.stdout[-4000:], "tags": ["verify", "gate_failure", name]})
                if stop_on_fail:
                    break
        return {"project_id": project_id, "cwd": str(cwd), "overall": overall, "results": results}

    @register_tool("web.fetch", "Fetch a URL and distill rendered text/link metadata.", "medium", category="web")
    def tool_web_fetch(payload: dict[str, Any]) -> dict[str, Any]:
        url = str(payload.get("url", "")).strip()
        if not url:
            raise error_cls("BAD_REQUEST", "url is required", 400)
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise error_cls("BAD_REQUEST", "url must be http or https", 400)
        req = urllib.request.Request(url, headers={"User-Agent": str(payload.get("user_agent", "Mozilla/5.0 PCMMAD-Lab/1.0"))})
        timeout_seconds = max(1, min(int(payload.get("timeout_seconds", 30)), 60))
        max_bytes = max(1024, min(int(payload.get("max_bytes", 500000)), 1000000))
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read(max_bytes)
            content_type = resp.headers.get("Content-Type", "")
        text = raw.decode("utf-8", errors="replace")
        title = None
        links: list[str] = []
        if "html" in content_type.lower():
            if beautiful_soup is not None:
                soup = beautiful_soup(text, "html.parser")
                for tag in soup(["script", "style", "nav"]):
                    tag.decompose()
                title = soup.title.string.strip() if soup.title and soup.title.string else None
                links = [a.get("href") for a in soup.find_all("a", href=True)[:100]]
                body_text = "\n".join(line.strip() for line in soup.get_text("\n").splitlines() if line.strip())
                text = body_text[:200000]
            else:
                lower = text.lower()
                t0 = lower.find("<title>")
                t1 = lower.find("</title>")
                if t0 != -1 and t1 != -1 and t1 > t0:
                    title = text[t0 + 7 : t1].strip()
        return {"url": url, "content_type": content_type, "bytes": len(raw), "title": title, "text": text[:200000], "links": links[:100]}
