from __future__ import annotations

from typing import Any, Callable

from research_arxiv import (
    ArxivBadResponseError,
    ArxivRateLimitedError,
    ArxivUnavailableError,
    fetch_arxiv_paper,
    get_cache_stats,
    search_arxiv,
)
from research_config import PER_QUERY_MAX_RESULTS
from research_distill import distill_paper
from research_predator import dedupe_and_rank, generate_query_family
from research_starmap import build_evidence_topology


def _as_dict(value: Any) -> Any:
    return value.to_dict() if hasattr(value, "to_dict") else value


def _as_dict_list(values: list[Any]) -> list[Any]:
    return [_as_dict(item) for item in values]


def register_research_tools(
    register_tool: Callable[..., Callable[[Callable[[dict[str, Any]], dict[str, Any]]], Callable[[dict[str, Any]], dict[str, Any]]]],
    *,
    error_cls: type[Exception],
) -> None:
    @register_tool("research.arxiv.search", "Search arXiv using server-side research code.", "low", category="research")
    def tool_research_arxiv_search(payload: dict[str, Any]) -> dict[str, Any]:
        query = str(payload.get("query", "")).strip()
        if not query:
            raise error_cls("BAD_REQUEST", "query is required", 400)
        max_results = int(payload.get("max_results", 8))
        sort_by = str(payload.get("sort_by", "relevance"))
        try:
            result = search_arxiv(query=query, max_results=max_results, sort_by=sort_by)
            return _as_dict(result)
        except ArxivRateLimitedError as e:
            raise error_cls(e.error_code, str(e), 429, retryable=True)
        except ArxivUnavailableError as e:
            raise error_cls(e.error_code, str(e), 503, retryable=True)
        except ArxivBadResponseError as e:
            raise error_cls(e.error_code, str(e), 502, retryable=False)

    @register_tool("research.arxiv.paper", "Fetch a specific arXiv paper and distill derived objects.", "low", category="research")
    def tool_research_arxiv_paper(payload: dict[str, Any]) -> dict[str, Any]:
        paper_id = str(payload.get("paper_id", "")).strip()
        if not paper_id:
            raise error_cls("BAD_REQUEST", "paper_id is required", 400)
        run_id = str(payload.get("ingestion_run_id", "research_v5_run"))
        try:
            canonical = fetch_arxiv_paper(paper_id)
            derived = distill_paper(canonical_paper=canonical, ingestion_run_id=run_id)
            return {"canonical_paper": _as_dict(canonical), "derived_objects": derived}
        except ArxivRateLimitedError as e:
            raise error_cls(e.error_code, str(e), 429, retryable=True)
        except ArxivUnavailableError as e:
            raise error_cls(e.error_code, str(e), 503, retryable=True)
        except ArxivBadResponseError as e:
            raise error_cls(e.error_code, str(e), 502, retryable=False)
        except ValueError as e:
            raise error_cls("NOT_FOUND", str(e), 404, retryable=False)

    @register_tool("research.hunt", "Run bounded multi-query research hunt server-side.", "medium", category="research")
    def tool_research_hunt(payload: dict[str, Any]) -> dict[str, Any]:
        topic = str(payload.get("topic", "")).strip()
        if not topic:
            raise error_cls("BAD_REQUEST", "topic is required", 400)
        mode = str(payload.get("mode", "direct_hunt"))
        if mode != "direct_hunt":
            raise error_cls("MODE_NOT_ENABLED", "v5 supports direct_hunt only", 400)
        max_results = min(int(payload.get("max_results", 5)), PER_QUERY_MAX_RESULTS)
        try:
            family = generate_query_family(topic)
            family_hits: list[dict[str, Any]] = []
            for entry in family:
                query_used = getattr(entry, "query", None) or entry["query"]
                query_label = getattr(entry, "label", None) or entry["label"]
                result = search_arxiv(query=query_used, max_results=max_results, sort_by="relevance")
                papers = getattr(result, "results", None) or result["results"]
                for paper in papers:
                    family_hits.append({"query_used": query_used, "query_label": query_label, "paper": _as_dict(paper)})
            ranked = dedupe_and_rank(topic, family_hits)
            starmap = build_evidence_topology(ranked)
            return {
                "topic": topic,
                "mode": mode,
                "query_families": _as_dict_list(family),
                "candidate_count_before_dedupe": len(family_hits),
                "ranked_results": _as_dict_list(ranked),
                "starmap": _as_dict(starmap),
                "cache": get_cache_stats(),
                "note": "bounded direct_hunt via lab router",
            }
        except ArxivRateLimitedError as e:
            raise error_cls(e.error_code, str(e), 429, retryable=True)
        except ArxivUnavailableError as e:
            raise error_cls(e.error_code, str(e), 503, retryable=True)
        except ArxivBadResponseError as e:
            raise error_cls(e.error_code, str(e), 502, retryable=False)
