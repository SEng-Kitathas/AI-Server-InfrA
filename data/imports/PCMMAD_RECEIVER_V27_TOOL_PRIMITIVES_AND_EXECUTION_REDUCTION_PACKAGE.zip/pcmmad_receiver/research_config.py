from __future__ import annotations
PARSER_VERSION = "research_v5_exec"
ENABLED_SOURCES = ["arxiv"]
ENABLED_HUNT_MODES = ["direct_hunt"]
DEFAULT_MAX_RESULTS = 8
REQUEST_TIMEOUT_SECONDS = 20
PER_QUERY_MAX_RESULTS = 5
