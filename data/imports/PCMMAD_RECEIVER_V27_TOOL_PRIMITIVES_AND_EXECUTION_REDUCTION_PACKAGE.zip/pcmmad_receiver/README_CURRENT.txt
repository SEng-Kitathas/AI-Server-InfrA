PCMMAD Receiver V25
Generated: 2026-04-13T03:15:38Z

Focus:
- tighten extracted state/project tool modules
- harden typed-record compatibility hydration
- fix runtime bug in SessionRef.from_payload
- keep package compile-clean and bytecode-free

Verification:
- package-wide py_compile: PASS
