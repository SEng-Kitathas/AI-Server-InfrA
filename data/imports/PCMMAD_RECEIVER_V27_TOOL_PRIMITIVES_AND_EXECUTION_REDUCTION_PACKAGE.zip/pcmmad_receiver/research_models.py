from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any


from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class QueryFamilyEntry:
    label: str
    query: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RankedResearchHit:
    rank: int
    signal_score: float
    query_hits: int
    matched_queries: list[str]
    matched_labels: list[str]
    paper: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TopHit:
    rank: int | None
    signal_score: float | None
    paper_id: str | None
    title: str | None
    updated: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TopologyCluster:
    label: str
    items: list[Any]

    def to_dict(self) -> dict[str, Any]:
        return {'label': self.label, 'items': self.items}


@dataclass(frozen=True)
class TopologySummary:
    dominant_categories: list[dict[str, Any]]
    lineage_hints: list[str]
    integrity: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EvidenceTopology:
    layer: str
    candidate_count: int
    clusters: list[TopologyCluster]
    topology_summary: TopologySummary
    top_hits: list[TopHit] | None = None

    def to_dict(self) -> dict[str, Any]:
        data = {
            'layer': self.layer,
            'candidate_count': self.candidate_count,
            'clusters': [c.to_dict() for c in self.clusters],
            'topology_summary': self.topology_summary.to_dict(),
        }
        if self.top_hits is not None:
            data['top_hits'] = [h.to_dict() for h in self.top_hits]
        return data


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def stable_id(*parts: str) -> str:
    joined = "::".join(parts)
    digest = hashlib.sha256(joined.encode("utf-8")).hexdigest()[:12]
    return f"{parts[-1]}_{digest}"


def make_metadata(
    object_id: str,
    paper_id: str,
    parser_version: str,
    ingestion_run_id: str,
    source_span: dict[str, Any] | None = None,
    parser_confidence: float = 0.75,
    human_validated: bool = False,
) -> dict[str, Any]:
    return {
        "object_id": object_id,
        "paper_id": paper_id,
        "ingestion_run_id": ingestion_run_id,
        "parser_version": parser_version,
        "created_at": utc_now(),
        "parser_confidence": parser_confidence,
        "human_validated": human_validated,
        "source_span": source_span
        or {
            "start_char": 0,
            "end_char": 0,
            "section_label": "abstract",
        },
    }


def paper_summary(
    *,
    paper_id: str,
    parser_version: str,
    ingestion_run_id: str,
    core_thesis: str,
    synthesis_role: str,
    must_read_justification: str,
    rigor_score: float = 0.5,
    novelty_score: float = 0.5,
    reproducibility_index: float = 0.4,
) -> dict[str, Any]:
    object_id = stable_id(paper_id, "paper_summary")
    return {
        "object_type": "paper_summary",
        "metadata": make_metadata(
            object_id=object_id,
            paper_id=paper_id,
            parser_version=parser_version,
            ingestion_run_id=ingestion_run_id,
        ),
        "paper_id": paper_id,
        "synthesis_role": synthesis_role,
        "core_thesis": core_thesis,
        "rigor_score": rigor_score,
        "novelty_score": novelty_score,
        "reproducibility_index": reproducibility_index,
        "derived_object_counts": {
            "claims": 0,
            "methods": 0,
            "limitations": 0,
            "isomorphisms": 0,
        },
        "must_read_justification": must_read_justification,
        "distillation_status": "embedded",
    }


def claim(
    *,
    paper_id: str,
    parser_version: str,
    ingestion_run_id: str,
    ordinal: int,
    claim_statement: str,
    claim_type: str = "methodological_advantage",
    evidence_strength: float = 0.45,
    falsifiability_surface: str = "",
) -> dict[str, Any]:
    claim_id = f"c{ordinal}"
    object_id = stable_id(paper_id, claim_id)
    return {
        "object_type": "claim",
        "metadata": make_metadata(
            object_id=object_id,
            paper_id=paper_id,
            parser_version=parser_version,
            ingestion_run_id=ingestion_run_id,
        ),
        "paper_id": paper_id,
        "claim_id": claim_id,
        "claim_statement": claim_statement,
        "claim_type": claim_type,
        "evidence_strength": evidence_strength,
        "falsifiability_surface": falsifiability_surface,
        "source_section": "abstract",
        "contradiction_links": [],
        "tags": [],
    }


def method(
    *,
    paper_id: str,
    parser_version: str,
    ingestion_run_id: str,
    ordinal: int,
    mechanism_name: str,
    execution_logic: str,
    hardware_substrate_assumptions: list[str] | None = None,
) -> dict[str, Any]:
    method_id = f"m{ordinal}"
    object_id = stable_id(paper_id, method_id)
    return {
        "object_type": "method",
        "metadata": make_metadata(
            object_id=object_id,
            paper_id=paper_id,
            parser_version=parser_version,
            ingestion_run_id=ingestion_run_id,
        ),
        "paper_id": paper_id,
        "method_id": method_id,
        "mechanism_name": mechanism_name,
        "execution_logic": execution_logic,
        "hardware_substrate_assumptions": hardware_substrate_assumptions or [],
        "complexity_metrics": {
            "time_complexity": "unknown",
            "space_complexity": "unknown",
        },
        "dependencies": [],
    }


def isomorphic_abstraction(
    *,
    paper_id: str,
    parser_version: str,
    ingestion_run_id: str,
    ordinal: int,
    problem_topology: str,
    mechanism_topology: str,
    mathematical_core: str,
    failure_topology: str = "",
    target_transfer_domains: list[str] | None = None,
) -> dict[str, Any]:
    abstraction_id = f"iso{ordinal}"
    object_id = stable_id(paper_id, abstraction_id)
    return {
        "object_type": "isomorphic_abstraction",
        "metadata": make_metadata(
            object_id=object_id,
            paper_id=paper_id,
            parser_version=parser_version,
            ingestion_run_id=ingestion_run_id,
        ),
        "paper_id": paper_id,
        "abstraction_id": abstraction_id,
        "problem_topology": problem_topology,
        "mechanism_topology": mechanism_topology,
        "failure_topology": failure_topology,
        "mathematical_core": mathematical_core,
        "target_transfer_domains": target_transfer_domains or [],
    }
