from __future__ import annotations

import os

from app_factory import create_app

app = create_app()


def _bind_host() -> str:
    return os.environ.get("PCMMAD_BIND_HOST", "127.0.0.1").strip() or "127.0.0.1"


def _bind_port() -> int:
    raw = os.environ.get("PCMMAD_BIND_PORT", "5000").strip() or "5000"
    return int(raw)


if __name__ == "__main__":
    app.run(host=_bind_host(), port=_bind_port(), debug=False, threaded=True, use_reloader=False)
