from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from control_plane_models import (
    CapacitySnapshot,
    CompactControlSurfaceDescriptor,
    CorruptJobFileRecord,
    ExecutionJobRecord,
    ServerCapabilityRouterDescriptor,
    TextWindow,
)


def _require_object(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("JSON request body must be an object")
    return data


def _as_str(value: Any, default: str = "") -> str:
    return str(value if value is not None else default)


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        v = value.strip().lower()
        if v in {"1", "true", "yes", "on"}:
            return True
        if v in {"0", "false", "no", "off"}:
            return False
    return bool(value)


def _as_int(value: Any, default: int | None = None) -> int | None:
    if value is None or value == "":
        return default
    return int(value)


@dataclass
class ErrorEnvelope:
    ok: bool
    error_code: str
    message: str
    time: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = {"ok": self.ok, "error_code": self.error_code, "message": self.message}
        if self.time is not None:
            data["time"] = self.time
        data.update(self.extra)
        return data


@dataclass
class WarningItem:
    kind: str
    message: str
    path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = {"kind": self.kind, "message": self.message}
        if self.path is not None:
            data["path"] = self.path
        return data


@dataclass
class IndexCacheStats:
    entries: int
    bytes: int
    max_bytes: int
    ttl_seconds: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
