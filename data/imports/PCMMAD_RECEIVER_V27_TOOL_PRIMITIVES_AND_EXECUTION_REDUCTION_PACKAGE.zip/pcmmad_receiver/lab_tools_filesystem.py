from __future__ import annotations

import glob
import shutil
import zipfile
from dataclasses import dataclass
from lab_tool_primitives import ToolPayload, ToolResult, payload_bool, payload_list_of_str, payload_str
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class FsGlobRequest:
    pattern: str
    project_id: str
    recursive: bool
    limit: int


@dataclass(frozen=True)
class FsGrepRequest:
    query: str
    limit: int | None
    max_file_bytes: int | None


@dataclass(frozen=True)
class FsTreeRequest:
    depth: int
    include_hidden: bool
    exclude_dirs: set[str]
    extensions: set[str] | None
    min_size_bytes: int
    limit: int | None


@dataclass(frozen=True)
class ZipReadRequest:
    entries: list[str]
    max_entry_bytes: int


def register_filesystem_tools(
    register_tool: Callable[..., Callable[[Callable[[ToolPayload], ToolResult]], Callable[[ToolPayload], ToolResult]]],
    *,
    error_cls: type[Exception],
    resolve_general_path: Callable[[ToolPayload, str | None], Path],
    ensure_within_allowed: Callable[[Path], Path],
    get_project_root: Callable[[str], Path],
    resolve_mount_spec: Callable[..., Path],
    ensure_parent: Callable[[Path], None],
    request_optional_positive_int: Callable[..., int | None],
    stream_grep: Callable[[Path, str, int, int], tuple[list[ToolResult], bool, bool]],
    text_extensions: set[str],
    default_grep_max_file_bytes: int,
) -> None:

    def _glob_request(payload: ToolPayload) -> FsGlobRequest:
        pattern = payload_str(payload, "pattern").strip()
        if not pattern:
            raise error_cls("BAD_REQUEST", "pattern is required", 400)
        limit = max(1, min(int(payload.get("limit", 500)), 5000))
        return FsGlobRequest(
            pattern=pattern,
            project_id=payload_str(payload, "project_id").strip(),
            recursive=payload_bool(payload, "recursive", True),
            limit=limit,
        )

    def _grep_request(payload: ToolPayload) -> FsGrepRequest:
        query = payload_str(payload, "query").strip()
        if not query:
            raise error_cls("BAD_REQUEST", "query is required", 400)
        return FsGrepRequest(
            query=query,
            limit=request_optional_positive_int(payload.get("limit", 100), 100, minimum=1),
            max_file_bytes=request_optional_positive_int(payload.get("max_file_bytes", default_grep_max_file_bytes), default_grep_max_file_bytes, minimum=1024),
        )

    def _tree_request(payload: ToolPayload) -> FsTreeRequest:
        extensions_raw = payload_list_of_str(payload, "extensions")
        return FsTreeRequest(
            depth=max(1, min(int(payload.get("depth", 3)), 10)),
            include_hidden=payload_bool(payload, "include_hidden", False),
            exclude_dirs=set(payload_list_of_str(payload, "exclude_dirs") or ["__pycache__", ".git", "node_modules", ".venv", ".venv_cuda", "vendor"]),
            extensions={item.lower() for item in extensions_raw} if extensions_raw else None,
            min_size_bytes=max(0, int(payload.get("min_size_bytes", 0))),
            limit=request_optional_positive_int(payload.get("limit", 500), 500, minimum=1),
        )

    def _zip_request(payload: ToolPayload) -> ZipReadRequest:
        return ZipReadRequest(
            entries=payload_list_of_str(payload, "entries"),
            max_entry_bytes=max(1024, min(int(payload.get("max_entry_bytes", 65536)), 1048576)),
        )

    @register_tool("fs.read", "Read a file from a mounted or absolute path.", "medium", category="filesystem")
    def tool_fs_read(payload: ToolPayload) -> ToolResult:
        path = ensure_within_allowed(resolve_general_path(payload))
        if not path.exists() or not path.is_file():
            raise error_cls("NOT_FOUND", "file not found", 404)
        max_bytes = request_optional_positive_int(payload.get("max_bytes", 65536), 65536, minimum=1)
        data = path.read_bytes()
        clipped = data[:max_bytes] if max_bytes else data
        return {"path": str(path), "size": len(data), "truncated": bool(max_bytes and len(data) > max_bytes), "content": clipped.decode("utf-8", errors="replace")}

    @register_tool("fs.write", "Write a file to a mounted or absolute path.", "high", category="filesystem", approval_required=True, mutating=True)
    def tool_fs_write(payload: ToolPayload) -> ToolResult:
        path = ensure_within_allowed(resolve_general_path(payload))
        content = _payload_str(payload, "content")
        ensure_parent(path)
        path.write_text(content, encoding="utf-8")
        return {"path": str(path), "bytes_written": len(content.encode("utf-8")), "ok": True}

    @register_tool("fs.move", "Move a file within allowed roots.", "high", category="filesystem", approval_required=True, mutating=True)
    def tool_fs_move(payload: ToolPayload) -> ToolResult:
        src = ensure_within_allowed(resolve_general_path(payload, "src"))
        dst = ensure_within_allowed(resolve_general_path(payload, "dst"))
        if not src.exists():
            raise error_cls("NOT_FOUND", "src not found", 404)
        ensure_parent(dst)
        shutil.move(str(src), str(dst))
        return {"src": str(src), "dst": str(dst), "moved": True}

    @register_tool("fs.glob", "Glob files under a mounted or absolute path.", "medium", category="filesystem")
    def tool_fs_glob(payload: ToolPayload) -> ToolResult:
        request = _glob_request(payload)
        default_root = get_project_root(request.project_id) if request.project_id else None
        try:
            resolved_pattern = str(resolve_mount_spec(request.pattern, default_root=default_root, allow_absolute=True))
        except Exception as e:
            raise error_cls("BAD_PATH", str(e), 400)
        matches = []
        for hit in glob.glob(resolved_pattern, recursive=request.recursive):
            path = Path(hit).resolve()
            try:
                ensure_within_allowed(path)
            except Exception:
                continue
            matches.append(str(path))
            if len(matches) >= request.limit:
                break
        return {"pattern": request.pattern, "count": len(matches), "partial": len(matches) >= request.limit, "matches": matches}

    @register_tool("fs.grep", "Search text across mounted or absolute filesystem paths.", "medium", category="filesystem")
    def tool_fs_grep(payload: ToolPayload) -> ToolResult:
        request = _grep_request(payload)
        path = ensure_within_allowed(resolve_general_path(payload))
        hits: list[ToolResult] = []
        files_scanned = 0
        skipped_oversized = 0
        partial = False
        walker = [path] if path.is_file() else path.rglob("*")
        for entry in walker:
            if not isinstance(entry, Path) or not entry.is_file() or entry.suffix.lower() not in text_extensions:
                continue
            files_scanned += 1
            remaining = (request.limit - len(hits)) if request.limit is not None else 10**9
            file_hits, file_partial, file_skipped = stream_grep(entry, request.query, remaining, request.max_file_bytes or (10**12))
            hits.extend(file_hits)
            if file_skipped:
                skipped_oversized += 1
            if file_partial or (request.limit is not None and len(hits) >= request.limit):
                partial = True
                break
        return {
            "query": request.query,
            "count": len(hits),
            "partial": partial,
            "hits": hits,
            "files_scanned": files_scanned,
            "skipped_oversized": skipped_oversized,
            "max_file_bytes": request.max_file_bytes,
        }

    @register_tool("fs.tree", "Traverse a filesystem tree from a mounted or absolute path.", "high", category="filesystem", approval_required=True)
    def tool_fs_tree(payload: ToolPayload) -> ToolResult:
        from power_routes import _iter_tree
        root = ensure_within_allowed(resolve_general_path(payload))
        if not root.exists():
            raise error_cls("NOT_FOUND", "root path not found", 404)
        request = _tree_request(payload)
        items, partial = _iter_tree(root, request.depth, request.include_hidden, request.exclude_dirs, request.extensions, request.min_size_bytes, request.limit)
        return {"root": str(root), "count": len(items), "partial": partial, "items": items}

    @register_tool("zip.read", "List or read entries from a mounted or absolute zip archive.", "medium", category="filesystem")
    def tool_zip_read(payload: ToolPayload) -> ToolResult:
        from lab_tools import _bounded_zip_entry_text  # local import to avoid cycle at module import
        zip_path = ensure_within_allowed(resolve_general_path(payload, "zip_path"))
        if not zip_path.exists():
            raise error_cls("NOT_FOUND", "zip archive not found", 404)
        request = _zip_request(payload)
        with zipfile.ZipFile(zip_path, "r") as zf:
            listing = [{"name": i.filename, "file_size": i.file_size, "compress_size": i.compress_size, "is_dir": i.is_dir()} for i in zf.infolist()]
            contents: ToolResult = {}
            for name in request.entries:
                try:
                    contents[name] = _bounded_zip_entry_text(zf, name, request.max_entry_bytes)
                except Exception as e:
                    contents[name] = {"ok": False, "entry_name": name, "error": str(e)}
        return {"zip_path": str(zip_path), "listing": listing, "contents": contents}
