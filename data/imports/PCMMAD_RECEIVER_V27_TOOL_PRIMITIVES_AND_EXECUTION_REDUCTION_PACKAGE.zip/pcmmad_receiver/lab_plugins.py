from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Callable

from control_plane_models import PluginLoadRecord


class PluginLoadError(Exception):
    pass


def discover_plugin_modules(base_dir: Path) -> list[Path]:
    plugins_dir = base_dir / "lab_plugins"
    if not plugins_dir.exists():
        return []
    return sorted([p for p in plugins_dir.glob("*.py") if p.name != "__init__.py"])


def load_plugins(base_dir: Path, register_func: Callable) -> list[PluginLoadRecord]:
    loaded: list[PluginLoadRecord] = []
    for path in discover_plugin_modules(base_dir):
        module_name = f"pcmmad_lab_plugin_{path.stem}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        if not spec or not spec.loader:
            raise PluginLoadError(f"unable to load plugin spec: {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        if hasattr(module, "register"):
            module.register(register_func)
        loaded.append(PluginLoadRecord(module=module_name, path=str(path)))
    return loaded
