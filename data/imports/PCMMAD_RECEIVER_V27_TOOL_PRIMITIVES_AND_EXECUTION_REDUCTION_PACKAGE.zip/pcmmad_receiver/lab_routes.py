from __future__ import annotations

from pathlib import Path
import json
import os
import atexit
import tempfile
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from flask import Blueprint, current_app, jsonify, request

from execution_routes import execution_readiness
from runtime_config import LAB_BATCH_CONFIG
from lab_results import get_result, result_path, summarize_payload
from lab_tools import (LabToolError, dispatch_tool, list_tools,
                       server_native_router_descriptor, tool_catalog_response,
                       tool_lab_health)
from shared_core import ensure_parent, mount_summary, require_valid_api_key, utc_now
from control_plane_models import BatchExecutorTelemetry, BackgroundResultEnvelope

lab_bp = Blueprint('lab', __name__, url_prefix='/lab')



_BATCH_EXECUTOR_LOCK = threading.RLock()
_BATCH_EXECUTOR: ThreadPoolExecutor | None = None
_BACKGROUND_BATCHES_SUBMITTED = 0


_BATCH_EXECUTOR_STATS_LOCK = threading.RLock()
_BATCH_EXECUTOR_TELEMETRY = BatchExecutorTelemetry()


def _batch_stat_inc(name: str, amount: int = 1) -> None:
    with _BATCH_EXECUTOR_STATS_LOCK:
        _BATCH_EXECUTOR_TELEMETRY.inc(name, amount)


def _batch_stat_set(name: str, value) -> None:
    with _BATCH_EXECUTOR_STATS_LOCK:
        _BATCH_EXECUTOR_TELEMETRY.set(name, value)


def _batch_stat_snapshot() -> dict[str, object]:
    with _BATCH_EXECUTOR_STATS_LOCK:
        return _BATCH_EXECUTOR_TELEMETRY.to_dict()



def _background_worker_target() -> int:
    workers = LAB_BATCH_CONFIG.background_workers
    if workers is None:
        return min(128, max(16, (os.cpu_count() or 8) * 8))
    return max(1, workers)


def _ensure_batch_executor() -> ThreadPoolExecutor:
    global _BATCH_EXECUTOR
    with _BATCH_EXECUTOR_LOCK:
        if _BATCH_EXECUTOR is None:
            _BATCH_EXECUTOR = ThreadPoolExecutor(max_workers=_background_worker_target(), thread_name_prefix='pcmmad-lab-bg')
        return _BATCH_EXECUTOR


def _shutdown_batch_executor() -> None:
    global _BATCH_EXECUTOR
    with _BATCH_EXECUTOR_LOCK:
        executor = _BATCH_EXECUTOR
        _BATCH_EXECUTOR = None
    if executor is not None:
        executor.shutdown(wait=False, cancel_futures=False)


atexit.register(_shutdown_batch_executor)

def _probe_mounts() -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    for mount in mount_summary():
        path = Path(mount["path"]).resolve()
        readable = path.exists()
        writable = False
        error = None
        try:
            path.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile("w", delete=False, dir=path, encoding="utf-8") as tmp:
                tmp.write("probe")
                probe_path = Path(tmp.name)
            probe_path.unlink(missing_ok=True)
            writable = True
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        results.append({"name": mount["name"], "path": str(path), "exists": readable, "writable": writable, "error": error})
    return results


def _merge_lab_status(boot_degraded: bool, lab_status: dict[str, object], execution_status: dict[str, object], mounts: list[dict[str, object]]) -> str:
    if boot_degraded:
        return "degraded"
    if lab_status.get("status") != "online":
        return "degraded"
    if execution_status.get("status") != "online":
        return "degraded"
    if any((not bool(m.get("exists"))) or (not bool(m.get("writable"))) for m in mounts):
        return "degraded"
    return "online"

def _write_background_result(project_id: str, handle: str, payload: object, *, label: str = 'lab_batch', tool_name: str = 'lab.batch') -> dict[str, object]:
    body = BackgroundResultEnvelope(project_id=project_id, handle=handle, label=label, tool_name=tool_name, created_at=utc_now(), payload=payload)
    path = result_path(project_id, handle)
    ensure_parent(path)
    path.write_text(json.dumps(body.to_dict(), ensure_ascii=False, indent=2), encoding='utf-8')
    return body.to_dict()




def _parallel_map_ordered(steps: list[dict], worker, parallelism: int) -> list[dict]:
    executor = _ensure_batch_executor()
    effective_parallelism = max(1, min(parallelism, _background_worker_target()))
    _batch_stat_inc('foreground_parallel_dispatches')
    semaphore = threading.Semaphore(effective_parallelism)
    ordered: dict[int, dict] = {}
    futures = []

    def _guarded(idx: int, step: dict):
        with semaphore:
            return worker(idx, step)

    for idx, step in enumerate(steps):
        futures.append((idx, executor.submit(_guarded, idx, step)))
    for idx, future in futures:
        ordered[idx] = future.result()
    return [ordered[i] for i in sorted(ordered)]


def _execute_batch_steps(steps: list[dict], stop_on_error: bool, parallelism: int) -> list[dict]:
    results: list[dict] = []

    def _run_one(idx: int, step: dict) -> dict:
        tool_name = str(step.get('tool_name', '')).strip()
        payload = step.get('payload') or {}
        try:
            return {'index': idx, **dispatch_tool(tool_name, payload)}
        except LabToolError as e:
            return {'index': idx, 'ok': False, 'tool': tool_name, 'error_code': e.error_code, 'message': e.message, 'status': e.status, **e.extra}

    if parallelism > 1 and not stop_on_error:
        return _parallel_map_ordered(steps, _run_one, parallelism)
    for idx, step in enumerate(steps):
        if not isinstance(step, dict):
            raise LabToolError('BAD_REQUEST', f'step {idx} must be an object', 400)
        tool_name = str(step.get('tool_name', '')).strip()
        if not tool_name:
            raise LabToolError('BAD_REQUEST', f'step {idx} missing tool_name', 400)
        result = _run_one(idx, step)
        results.append(result)
        if stop_on_error and not result.get('ok', False):
            break
    return results


def _error(error_code: str, message: str, status: int, **extra):
    payload = {'ok': False, 'error_code': error_code, 'message': message, 'time': utc_now()}
    payload.update(extra)
    return jsonify(payload), status


def _auth():
    try:
        require_valid_api_key(request.headers)
        return None
    except Exception as e:
        return _error('UNAUTHORIZED', str(e), 401)


@lab_bp.get('/health')
def lab_health():
    ae = _auth()
    if ae:
        return ae
    boot_report = current_app.config.get('PCMMAD_BOOT_REPORT', {})
    boot_degraded = bool(current_app.config.get('PCMMAD_BOOT_DEGRADED', False))
    lab_status = tool_lab_health({})
    execution_status = execution_readiness()
    mounts = _probe_mounts()
    return jsonify(
        {
            'ok': True,
            'status': _merge_lab_status(boot_degraded, lab_status, execution_status, mounts),
            'router': True,
            'tool_count': len(list_tools()),
            'boot_report': boot_report,
            'lab_status': lab_status,
            'execution_readiness': execution_status,
            'mount_readiness': mounts,
            'background_batch_executor': {
                'configured_workers': _background_worker_target(),
                'alive': bool(_BATCH_EXECUTOR is not None),
                'submitted_batches': _BACKGROUND_BATCHES_SUBMITTED,
                'telemetry': _batch_stat_snapshot(),
            },
            'time': utc_now(),
            'server_native_router': server_native_router_descriptor().to_dict(),
        }
    )


@lab_bp.get('/tools')
def lab_tools_index():
    ae = _auth()
    if ae:
        return ae
    return jsonify(tool_catalog_response(operation_budget=30, action_count=30).to_dict())


@lab_bp.get('/mounts')
def lab_mounts():
    ae = _auth()
    if ae:
        return ae
    return jsonify({'ok': True, 'mounts': mount_summary(), 'time': utc_now()})


@lab_bp.get('/mcp/manifest')
def lab_mcp_manifest():
    ae = _auth()
    if ae:
        return ae
    tools = list_tools()
    return jsonify(
        {
            'ok': True,
            'server_name': 'pcmmad_lab',
            'protocol': 'mcp-ready-shared-registry',
            'tool_count': len(tools),
            'tools': [
                {
                    'name': t.get('name'),
                    'description': t.get('description'),
                    'input_schema': t.get('input_schema', {'type': 'object'}),
                }
                for t in tools
            ],
            'time': utc_now(),
        }
    )


@lab_bp.post('/results/get')
def lab_results_get():
    ae = _auth()
    if ae:
        return ae
    try:
        d = request.get_json(silent=False, force=True)
        if not isinstance(d, dict):
            return _error('BAD_JSON', 'JSON body must be an object', 400)
        project_id = str(d.get('project_id', '')).strip()
        handle = str(d.get('handle', '')).strip()
        if not project_id or not handle:
            return _error('BAD_REQUEST', 'project_id and handle are required', 400)
        row = get_result(project_id, handle)
        if bool(d.get('summary_only', False)):
            return jsonify({'ok': True, 'project_id': project_id, 'handle': handle, 'summary': summarize_payload(row.get('payload')), 'time': utc_now()})
        return jsonify({'ok': True, 'time': utc_now(), **row})
    except FileNotFoundError:
        return _error('NOT_FOUND', 'result handle not found', 404)
    except Exception as e:
        return _error('RESULT_GET_FAILED', str(e), 500)


@lab_bp.post('/dispatch')
def lab_dispatch():
    ae = _auth()
    if ae:
        return ae
    try:
        d = request.get_json(silent=False, force=True)
        if not isinstance(d, dict):
            return _error('BAD_JSON', 'JSON body must be an object', 400)
        tool_name = str(d.get('tool_name', '')).strip()
        payload = d.get('payload') or {}
        if not tool_name:
            return _error('BAD_REQUEST', 'tool_name is required', 400)
        if not isinstance(payload, dict):
            return _error('BAD_REQUEST', 'payload must be an object', 400)
        result = dispatch_tool(tool_name, payload)
        return jsonify(result)
    except LabToolError as e:
        return _error(e.error_code, e.message, e.status, **e.extra)
    except Exception as e:
        return _error('LAB_DISPATCH_FAILED', str(e), 500)


@lab_bp.post('/batch')
def lab_batch():
    ae = _auth()
    if ae:
        return ae
    try:
        d = request.get_json(silent=False, force=True)
        if not isinstance(d, dict):
            return _error('BAD_JSON', 'JSON body must be an object', 400)
        steps = d.get('steps') or []
        stop_on_error = bool(d.get('stop_on_error', True))
        background = bool(d.get('background', False))
        parallelism = max(1, int(d.get('parallelism', 1)))
        if not isinstance(steps, list) or not steps:
            return _error('BAD_REQUEST', 'steps must be a non-empty array', 400)

        if background:
            project_id = str(d.get('project_id', '')).strip()
            if not project_id:
                return _error('BAD_REQUEST', 'project_id is required when background=true', 400)
            handle = f'res-{uuid.uuid4().hex[:12]}'
            submitted_at = utc_now()
            _write_background_result(project_id, handle, {
                'status': 'RUNNING',
                'submitted_at': submitted_at,
                'count': len(steps),
                'stop_on_error': stop_on_error,
                'parallelism': parallelism,
            })
            def _runner():
                _batch_stat_inc('background_batches_active')
                try:
                    results = _execute_batch_steps(steps, stop_on_error, parallelism)
                    _write_background_result(project_id, handle, {
                        'status': 'COMPLETED',
                        'submitted_at': submitted_at,
                        'finished_at': utc_now(),
                        'count': len(results),
                        'results': results,
                    })
                    _batch_stat_inc('background_batches_completed')
                    _batch_stat_set('last_background_error', None)
                except Exception as exc:
                    _write_background_result(project_id, handle, {
                        'status': 'FAILED',
                        'submitted_at': submitted_at,
                        'finished_at': utc_now(),
                        'error': f'{type(exc).__name__}: {exc}',
                    })
                    _batch_stat_inc('background_batches_failed')
                    _batch_stat_set('last_background_error', f'{type(exc).__name__}: {exc}')
                finally:
                    with _BATCH_EXECUTOR_STATS_LOCK:
                        _BATCH_EXECUTOR_STATS['background_batches_active'] = max(0, int(_BATCH_EXECUTOR_STATS.get('background_batches_active', 0) or 0) - 1)
            global _BACKGROUND_BATCHES_SUBMITTED
            _BACKGROUND_BATCHES_SUBMITTED += 1
            _ensure_batch_executor().submit(_runner)
            return jsonify({'ok': True, 'background': True, 'project_id': project_id, 'handle': handle, 'status': 'RUNNING', 'submitted_at': submitted_at})

        results = _execute_batch_steps(steps, stop_on_error, parallelism)
        return jsonify({'ok': True, 'count': len(results), 'results': results, 'parallelism': parallelism, 'background': False})
    except LabToolError as e:
        return _error(e.error_code, e.message, e.status, **e.extra)
    except Exception as e:
        return _error('LAB_BATCH_FAILED', str(e), 500)
