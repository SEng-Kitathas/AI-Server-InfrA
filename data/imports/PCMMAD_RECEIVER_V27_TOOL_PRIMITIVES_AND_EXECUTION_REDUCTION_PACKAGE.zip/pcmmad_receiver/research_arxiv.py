from __future__ import annotations
import time, xml.etree.ElementTree as ET
from typing import Any
from api_wire_models import ArxivPaperRecord, ArxivSearchResponse
import requests
from research_config import REQUEST_TIMEOUT_SECONDS

ARXIV_API_URL = "https://export.arxiv.org/api/query"
_CACHE: dict[str, dict[str, Any]] = {}
CACHE_TTL_SECONDS = 300
CACHE_MAX_BYTES = 512 * 1024 * 1024
_CACHE_BYTES = 0

class ArxivError(Exception): error_code = "ARXIV_ERROR"
class ArxivRateLimitedError(ArxivError): error_code = "ARXIV_SEARCH_FAILED"
class ArxivUnavailableError(ArxivError): error_code = "ARXIV_UNAVAILABLE"
class ArxivBadResponseError(ArxivError): error_code = "ARXIV_BAD_RESPONSE"

def _estimate_size(obj: Any) -> int: return len(str(obj).encode("utf-8"))
def _prune_cache() -> None:
    global _CACHE_BYTES
    now = time.time()
    expired = [k for k,v in _CACHE.items() if now-v["time"] > CACHE_TTL_SECONDS]
    for k in expired:
        old = _CACHE.pop(k, None)
        if old: _CACHE_BYTES -= old["size"]
    if _CACHE_BYTES > CACHE_MAX_BYTES:
        for k,v in sorted(_CACHE.items(), key=lambda kv: kv[1]["time"]):
            _CACHE.pop(k, None); _CACHE_BYTES -= v["size"]
            if _CACHE_BYTES <= CACHE_MAX_BYTES: break

def get_cache_stats() -> dict[str, Any]:
    _prune_cache(); return {"entries":len(_CACHE),"bytes":max(_CACHE_BYTES,0),"max_bytes":CACHE_MAX_BYTES,"ttl_seconds":CACHE_TTL_SECONDS}
def _cache_get(key: str):
    _prune_cache(); entry = _CACHE.get(key)
    if not entry: return None
    if time.time()-entry["time"] > CACHE_TTL_SECONDS: return None
    return entry["value"]
def _cache_put(key: str, value: Any):
    global _CACHE_BYTES
    size = _estimate_size(value)
    old = _CACHE.pop(key, None)
    if old: _CACHE_BYTES -= old["size"]
    _CACHE[key] = {"time":time.time(),"value":value,"size":size}
    _CACHE_BYTES += size
    _prune_cache()

def _strip_arxiv_prefix(paper_id: str) -> str:
    pid = paper_id.strip()
    if pid.lower().startswith("arxiv:"): pid = pid.split(":",1)[1]
    return pid

def _request(params: dict[str, Any]) -> str:
    try:
        resp = requests.get(ARXIV_API_URL, params=params, timeout=REQUEST_TIMEOUT_SECONDS, headers={"User-Agent":"PCMMAD-Receiver/5.0"})
    except requests.RequestException as e:
        raise ArxivUnavailableError(str(e))
    if resp.status_code == 429: raise ArxivRateLimitedError(f"{resp.status_code} Client Error: rate limit for url: {resp.url}")
    if 500 <= resp.status_code < 600: raise ArxivUnavailableError(f"{resp.status_code} Server Error for url: {resp.url}")
    if resp.status_code != 200: raise ArxivBadResponseError(f"{resp.status_code} Client Error for url: {resp.url}")
    return resp.text

def _parse_feed(xml_text: str) -> list[ArxivPaperRecord]:
    ns={"atom":"http://www.w3.org/2005/Atom","arxiv":"http://arxiv.org/schemas/atom"}
    try: root=ET.fromstring(xml_text)
    except ET.ParseError as e: raise ArxivBadResponseError(f"Could not parse arXiv response XML: {e}")
    results: list[ArxivPaperRecord] = []
    for entry in root.findall("atom:entry", ns):
        entry_id=entry.findtext("atom:id", default="", namespaces=ns).strip()
        title=" ".join(entry.findtext("atom:title", default="", namespaces=ns).split())
        abstract=" ".join(entry.findtext("atom:summary", default="", namespaces=ns).split())
        published=entry.findtext("atom:published", default="", namespaces=ns).strip()
        updated=entry.findtext("atom:updated", default="", namespaces=ns).strip()
        authors=[a.findtext("atom:name", default="", namespaces=ns).strip() for a in entry.findall("atom:author", ns)]
        categories=[c.attrib.get("term","").strip() for c in entry.findall("atom:category", ns) if c.attrib.get("term","").strip()]
        pdf_url=""
        for link in entry.findall("atom:link", ns):
            href=link.attrib.get("href",""); title_attr=link.attrib.get("title",""); rel=link.attrib.get("rel","")
            if title_attr=="pdf" or (rel=="related" and "pdf" in href): pdf_url=href; break
        paper_id=entry_id.rsplit("/",1)[-1]
        results.append(
            ArxivPaperRecord(
                paper_id=f"arXiv:{paper_id}",
                source_id=entry_id,
                title=title,
                abstract=abstract,
                authors=authors,
                published=published,
                updated=updated,
                categories=categories,
                pdf_url=pdf_url,
                source_url=entry_id,
                source_quality="abstract_only",
            )
        )
    return results

def search_arxiv(query: str, max_results: int = 8, sort_by: str = "relevance") -> ArxivSearchResponse:
    key=f"search::{query}::{max_results}::{sort_by}"; cached=_cache_get(key)
    if cached is not None: return cached
    xml=_request({"search_query":f"all:{query}","start":0,"max_results":max_results,"sortBy":sort_by,"sortOrder":"descending"})
    results=_parse_feed(xml)
    payload=ArxivSearchResponse(ok=True, query=query, max_results=max_results, sort_by=sort_by, results=results)
    _cache_put(key,payload); return payload

def fetch_arxiv_paper(paper_id: str) -> ArxivPaperRecord:
    stripped=_strip_arxiv_prefix(paper_id); key=f"paper::{stripped}"; cached=_cache_get(key)
    if cached is not None: return cached
    xml=_request({"id_list":stripped,"start":0,"max_results":1}); results=_parse_feed(xml)
    if not results: raise ValueError(f"Paper not found: {paper_id}")
    payload=results[0]; _cache_put(key,payload); return payload
