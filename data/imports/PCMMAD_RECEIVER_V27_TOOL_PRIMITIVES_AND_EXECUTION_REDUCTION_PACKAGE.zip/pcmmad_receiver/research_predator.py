from __future__ import annotations

import re
from collections import OrderedDict
from typing import Any

from research_models import QueryFamilyEntry, RankedResearchHit

TOKEN_RE = re.compile(r"[A-Za-z0-9_./:-]{3,}")

STOPWORDS = {
    "the", "and", "for", "that", "with", "from", "this", "have", "their", "into",
    "using", "used", "are", "was", "were", "has", "had", "but", "not", "you",
    "your", "can", "will", "they", "its", "than", "then", "such", "over", "also",
    "these", "those", "our", "out", "all", "one", "two", "may", "via", "use",
    "file", "files", "data", "notes", "note", "read", "search", "project", "state",
    "context", "latest", "current", "work", "line",
}

HIGH_SIGNAL_PHRASES = [
    ("compressive transformer", ["compressive transformers long range sequence modeling", "transformer-xl compressive memory"]),
    ("memory compression", ["transformer memory compression", "long context transformer memory"]),
    ("kv cache", ["kv cache compression transformer", "paged attention kv cache"]),
    ("long context", ["long context transformer memory", "efficient transformer long range sequence"]),
    ("transformer", ["transformer sequence modeling", "attention memory architecture"]),
    ("mamba", ["mamba state space sequence modeling", "state space model long context"]),
    ("rwkv", ["rwkv recurrent transformer memory", "rwkv long context"]),
    ("retnet", ["retnet retention mechanism long context", "retention network sequence modeling"]),
    ("quantization", ["transformer quantization memory", "low precision transformer state"]),
    ("sparse", ["sparse transformer memory routing", "sparse attention long context"]),
]

CANONICAL_BOOSTS = [
    "compressive transformers long range sequence modeling",
    "transformer-xl",
    "memorizing transformers",
    "mamba state space",
    "rwkv",
    "retnet",
]


def _tokens(text: str) -> list[str]:
    return [t.lower() for t in TOKEN_RE.findall(text) if t.lower() not in STOPWORDS]


def generate_query_family(topic: str) -> list[QueryFamilyEntry]:
    """
    Build a bounded multi-query family from the topic.
    This is deliberately conservative:
    - one direct query
    - a few canonical expansions
    - a few token-driven expansions
    """
    topic_norm = " ".join(topic.strip().split())
    topic_l = topic_norm.lower()

    queries: "OrderedDict[str, QueryFamilyEntry]" = OrderedDict()
    queries[topic_norm] = QueryFamilyEntry(label="direct", query=topic_norm)

    for needle, expansions in HIGH_SIGNAL_PHRASES:
        if needle in topic_l:
            for q in expansions:
                if q not in queries:
                    queries[q] = QueryFamilyEntry(label=f"expansion:{needle}", query=q)

    toks = _tokens(topic_norm)
    short = " ".join(toks[:5]) if toks else topic_norm
    if short and short not in queries:
        queries[short] = QueryFamilyEntry(label="compressed", query=short)

    if "transformer" in topic_l and "memory" in topic_l:
        for q in [
            "transformer-xl memory",
            "compressive transformers long range sequence modeling",
            "memorizing transformers retrieval memory",
        ]:
            if q not in queries:
                queries[q] = QueryFamilyEntry(label="canonical_memory_lineage", query=q)

    if "kv" in topic_l or "cache" in topic_l:
        for q in [
            "kv cache compression transformer",
            "paged attention kv cache",
            "long context kv memory transformer",
        ]:
            if q not in queries:
                queries[q] = QueryFamilyEntry(label="kv_family", query=q)

    # hard bound: keep first 5
    return list(queries.values())[:5]


def _paper_key(paper: dict[str, Any]) -> str:
    return paper.get("paper_id") or paper.get("source_id") or paper.get("title", "")


def _score_hit(topic: str, hit: dict[str, Any]) -> float:
    paper = hit.get("paper", {})
    title = (paper.get("title") or "").lower()
    abstract = (paper.get("abstract") or "").lower()
    query_used = (hit.get("query_used") or "").lower()
    topic_l = topic.lower()

    score = 0.0

    # exact phrase / canonical boosts
    for phrase in CANONICAL_BOOSTS:
        if phrase in title:
            score += 4.0
        elif phrase in abstract:
            score += 2.0

    topic_tokens = _tokens(topic_l)
    for tok in topic_tokens:
        if tok in title:
            score += 1.2
        if tok in abstract:
            score += 0.35
        if tok in query_used:
            score += 0.15

    # preferred terms
    preferred = ["memory", "compress", "context", "transformer", "sequence", "retention", "cache"]
    for tok in preferred:
        if tok in title:
            score += 0.5
        if tok in abstract:
            score += 0.15

    # mild authoritativeness / arxiv recency proxy
    updated = paper.get("updated") or ""
    if updated >= "2024-01-01":
        score += 0.2

    return round(score, 4)


def dedupe_and_rank(topic: str, family_hits: list[dict[str, Any]]) -> list[RankedResearchHit]:
    """
    Deduplicate by paper identity, aggregate query provenance, and rank.
    """
    merged: dict[str, dict[str, Any]] = {}

    for hit in family_hits:
        paper = hit.get("paper", {})
        key = _paper_key(paper)
        if not key:
            continue

        hit_score = _score_hit(topic, hit)
        if key not in merged:
            merged[key] = {
                "paper": paper,
                "score": hit_score,
                "matched_queries": [hit.get("query_used")],
                "matched_labels": [hit.get("query_label")],
                "query_hits": 1,
            }
        else:
            merged[key]["score"] = max(merged[key]["score"], hit_score) + 0.15
            if hit.get("query_used") not in merged[key]["matched_queries"]:
                merged[key]["matched_queries"].append(hit.get("query_used"))
            if hit.get("query_label") not in merged[key]["matched_labels"]:
                merged[key]["matched_labels"].append(hit.get("query_label"))
            merged[key]["query_hits"] += 1

    ranked = sorted(
        merged.values(),
        key=lambda x: (x["score"], x["query_hits"], x["paper"].get("updated", "")),
        reverse=True,
    )

    results = []
    for i, entry in enumerate(ranked[:10], start=1):
        results.append(RankedResearchHit(
            rank=i,
            signal_score=round(entry["score"], 4),
            query_hits=entry["query_hits"],
            matched_queries=entry["matched_queries"],
            matched_labels=entry["matched_labels"],
            paper=entry["paper"],
        ))
    return results
