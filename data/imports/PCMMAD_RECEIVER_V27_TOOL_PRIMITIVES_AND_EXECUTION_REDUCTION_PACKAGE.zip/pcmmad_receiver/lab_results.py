from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from shared_core import ensure_parent, get_project_root, sha256_bytes, utc_now, validate_project_id


def _results_root(project_id: str) -> Path:
    validate_project_id(project_id)
    return get_project_root(project_id) / 'system' / 'lab' / 'results'


def result_path(project_id: str, handle: str) -> Path:
    validate_project_id(project_id)
    clean_handle = (handle or '').strip()
    if not clean_handle:
        raise ValueError('handle is required')
    if '/' in clean_handle or '\\' in clean_handle:
        raise ValueError('handle must not include path separators')
    return _results_root(project_id) / f'{clean_handle}.json'


def store_result(project_id: str, payload: Any, *, label: str = 'result', tool_name: str = '') -> dict[str, Any]:
    handle = f'res-{uuid.uuid4().hex[:12]}'
    body = {
        'project_id': project_id,
        'handle': handle,
        'label': label,
        'tool_name': tool_name,
        'created_at': utc_now(),
        'payload': payload,
    }
    raw = json.dumps(body, ensure_ascii=False, indent=2).encode('utf-8')
    path = result_path(project_id, handle)
    ensure_parent(path)
    path.write_bytes(raw)
    return {
        'project_id': project_id,
        'handle': handle,
        'path': str(path),
        'bytes': len(raw),
        'sha256': sha256_bytes(raw),
        'label': label,
        'tool_name': tool_name,
        'created_at': body['created_at'],
    }


def get_result(project_id: str, handle: str) -> dict[str, Any]:
    path = result_path(project_id, handle)
    if not path.exists():
        raise FileNotFoundError('result handle not found')
    return json.loads(path.read_text(encoding='utf-8'))


def summarize_payload(payload: Any, *, preview_chars: int = 1200) -> dict[str, Any]:
    raw = json.dumps(payload, ensure_ascii=False)
    return {
        'type': type(payload).__name__,
        'chars': len(raw),
        'preview': raw[:preview_chars],
        'truncated': len(raw) > preview_chars,
    }
