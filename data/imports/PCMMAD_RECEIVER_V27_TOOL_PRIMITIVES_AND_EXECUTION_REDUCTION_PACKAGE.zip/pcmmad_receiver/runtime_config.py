from __future__ import annotations

import os
from dataclasses import dataclass


def parse_optional_unbounded_int(raw: str | int | None, default: int | None, *, minimum: int = 1) -> int | None:
    if raw is None or raw == "":
        return default
    text = str(raw).strip().lower()
    if text in {"0", "-1", "none", "unbounded", "unlimited", "inf", "infinite"}:
        return None
    value = int(text)
    if value < minimum:
        return minimum
    return value


def parse_float(raw: str | float | None, default: float, *, minimum: float | None = None) -> float:
    if raw is None or raw == "":
        value = default
    else:
        value = float(raw)
    if minimum is not None and value < minimum:
        value = minimum
    return value


@dataclass(frozen=True)
class ExecutionRuntimeConfig:
    default_timeout_seconds: int = 60
    max_timeout_seconds: int | None = None
    default_stdout_max_bytes: int = 65536
    default_stderr_max_bytes: int = 65536
    max_output_bytes: int | None = None
    global_concurrency: int | None = 8
    project_concurrency: int | None = None
    global_queue_limit: int | None = None
    project_queue_limit: int | None = None
    drain_batch: int | None = None
    scheduler_interval_seconds: float = 0.25

    @classmethod
    def from_env(cls) -> "ExecutionRuntimeConfig":
        return cls(
            default_timeout_seconds=int(os.environ.get("PCMMAD_EXECUTION_DEFAULT_TIMEOUT_SECONDS", "60")),
            max_timeout_seconds=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_MAX_TIMEOUT_SECONDS"), None),
            default_stdout_max_bytes=int(os.environ.get("PCMMAD_EXECUTION_DEFAULT_STDOUT_MAX_BYTES", "65536")),
            default_stderr_max_bytes=int(os.environ.get("PCMMAD_EXECUTION_DEFAULT_STDERR_MAX_BYTES", "65536")),
            max_output_bytes=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_MAX_OUTPUT_BYTES"), None),
            global_concurrency=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_GLOBAL_CONCURRENCY"), 8),
            project_concurrency=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_PROJECT_CONCURRENCY"), None),
            global_queue_limit=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_GLOBAL_QUEUE_LIMIT"), None),
            project_queue_limit=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_PROJECT_QUEUE_LIMIT"), None),
            drain_batch=parse_optional_unbounded_int(os.environ.get("PCMMAD_EXECUTION_DRAIN_BATCH"), None),
            scheduler_interval_seconds=parse_float(os.environ.get("PCMMAD_EXECUTION_SCHEDULER_INTERVAL_SECONDS"), 0.25, minimum=0.05),
        )


@dataclass(frozen=True)
class LabBatchRuntimeConfig:
    background_workers: int | None = 64

    @classmethod
    def from_env(cls) -> "LabBatchRuntimeConfig":
        return cls(
            background_workers=parse_optional_unbounded_int(os.environ.get("PCMMAD_LAB_BATCH_BACKGROUND_WORKERS"), 64),
        )


EXECUTION_CONFIG = ExecutionRuntimeConfig.from_env()
LAB_BATCH_CONFIG = LabBatchRuntimeConfig.from_env()
