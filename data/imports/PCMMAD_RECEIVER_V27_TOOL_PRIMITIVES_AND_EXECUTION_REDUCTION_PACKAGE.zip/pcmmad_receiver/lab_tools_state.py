
from __future__ import annotations

import subprocess
from dataclasses import dataclass
from typing import Any, Callable, TypeAlias


ToolPayload: TypeAlias = dict[str, Any]
ToolResult: TypeAlias = dict[str, Any]

def _required_project(error_cls: type[Exception], payload: ToolPayload) -> str:
    project_id = str(payload.get("project_id", "")).strip()
    if not project_id:
        raise error_cls("BAD_REQUEST", "project_id is required", 400)
    return project_id



def _get_str(payload: ToolPayload, key: str, default: str = "") -> str:
    value = payload.get(key, default)
    return default if value is None else str(value)

def _get_bool(payload: ToolPayload, key: str, default: bool = False) -> bool:
    value = payload.get(key, default)
    return value if isinstance(value, bool) else bool(value)

def _get_list(payload: ToolPayload, key: str) -> list[Any]:
    value = payload.get(key)
    return value if isinstance(value, list) else []

def _get_dict(payload: ToolPayload, key: str) -> dict[str, Any]:
    value = payload.get(key)
    return value if isinstance(value, dict) else {}

def _get_int(payload: ToolPayload, key: str, default: int) -> int:
    try:
        return int(payload.get(key, default))
    except Exception:
        return default


def _is_ok(payload: ToolPayload) -> bool:
    return _get_bool(payload, "ok", False)


@dataclass(frozen=True)
class LabHealthRequest:
    browser_timeout_seconds: int

    @classmethod
    def from_payload(cls, payload: ToolPayload) -> "LabHealthRequest":
        return cls(browser_timeout_seconds=max(1, min(_get_int(payload, "browser_timeout_seconds", 3), 15)))


@dataclass(frozen=True)
class SessionStartRequest:
    project_id: str
    title: str
    meta: dict[str, Any]

    @classmethod
    def from_payload(cls, ensure_project_layout: Callable[[ToolPayload], str], payload: ToolPayload) -> "SessionStartRequest":
        return cls(
            project_id=ensure_project_layout(payload),
            title=_get_str(payload, "title"),
            meta=_get_dict(payload, "meta"),
        )


@dataclass(frozen=True)
class SessionEndRequest:
    ref: SessionRef
    status: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "SessionEndRequest":
        return cls(
            ref=SessionRef.from_payload(error_cls, payload),
            status=_get_str(payload, "status", "closed").strip() or "closed",
        )


@dataclass(frozen=True)
class ApoptosisTriggerRequest:
    project_id: str
    session_id: str
    terminate_running_jobs: bool
    git_reset_hard: bool
    git_clean_fd: bool
    reason: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "ApoptosisTriggerRequest":
        return cls(
            project_id=_required_project(error_cls, payload),
            session_id=_get_str(payload, "session_id").strip(),
            terminate_running_jobs=_get_bool(payload, "terminate_running_jobs", True),
            git_reset_hard=_get_bool(payload, "git_reset_hard", False),
            git_clean_fd=_get_bool(payload, "git_clean_fd", False),
            reason=_get_str(payload, "reason", "manual trigger"),
        )


@dataclass(frozen=True)
class SessionRef:
    project_id: str
    session_id: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "SessionRef":
        project_id = _required_project(error_cls, payload)
        session_id = _get_str(payload, "session_id").strip()
        if not session_id:
            raise error_cls("BAD_REQUEST", "session_id is required", 400)
        return cls(project_id=project_id, session_id=session_id)


@dataclass(frozen=True)
class SessionNoteRequest:
    ref: SessionRef
    note: str
    note_type: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "SessionNoteRequest":
        ref = SessionRef.from_payload(error_cls, payload)
        note = _get_str(payload, "note").strip()
        if not note:
            raise error_cls("BAD_REQUEST", "note is required", 400)
        note_type = _get_str(payload, "note_type", "note").strip() or "note"
        return cls(ref=ref, note=note, note_type=note_type)


@dataclass(frozen=True)
class ReflexionAppendRequest:
    project_id: str
    session_id: str
    title: str
    content: str
    tags: list[str]

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "ReflexionAppendRequest":
        project_id = _required_project(error_cls, payload)
        title = _get_str(payload, "title").strip()
        content = _get_str(payload, "content").strip()
        if not title or not content:
            raise error_cls("BAD_REQUEST", "title and content are required", 400)
        return cls(
            project_id=project_id,
            session_id=_get_str(payload, "session_id").strip(),
            title=title,
            content=content,
            tags=[str(item) for item in _get_list(payload, "tags")],
        )



@dataclass(frozen=True)
class ReflexionReadRequest:
    project_id: str
    limit: int

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "ReflexionReadRequest":
        project_id = _required_project(error_cls, payload)
        return cls(project_id=project_id, limit=max(1, min(_get_int(payload, "limit", 50), 500)))


@dataclass(frozen=True)
class BridgeStatus:
    ok: bool
    error_code: str | None = None
    message: str | None = None
    status: int | None = None

    @classmethod
    def from_result(cls, payload: ToolPayload) -> "BridgeStatus":
        return cls(
            ok=_get_bool(payload, "ok", False),
            error_code=_get_str(payload, "error_code") or None,
            message=_get_str(payload, "message") or None,
            status=_get_int(payload, "status", 0) or None,
        )

    @classmethod
    def from_exception(cls, exc: Exception) -> "BridgeStatus":
        return cls(
            ok=False,
            error_code=getattr(exc, "error_code", exc.__class__.__name__),
            message=getattr(exc, "message", str(exc)),
            status=getattr(exc, "status", 500),
        )

    def to_dict(self) -> ToolResult:
        data: ToolResult = {"ok": self.ok}
        if self.error_code is not None:
            data["error_code"] = self.error_code
        if self.message is not None:
            data["message"] = self.message
        if self.status is not None:
            data["status"] = self.status
        return data


@dataclass(frozen=True)
class AndonPullRequest:
    project_id: str
    session_id: str
    reason: str
    details: str

    @classmethod
    def from_payload(cls, error_cls: type[Exception], payload: ToolPayload) -> "AndonPullRequest":
        project_id = _required_project(error_cls, payload)
        reason = _get_str(payload, "reason").strip()
        if not reason:
            raise error_cls("BAD_REQUEST", "reason is required", 400)
        return cls(
            project_id=project_id,
            session_id=_get_str(payload, "session_id").strip(),
            reason=reason,
            details=_get_str(payload, "details").strip(),
        )

def register_state_tools(
    register_tool: Callable[..., Callable[[Callable[[ToolPayload], ToolResult]], Callable[[ToolPayload], ToolResult]]],
    *,
    error_cls: type[Exception],
    tool_router_validation_state: Callable[[], Any],
    policy_mode: Callable[[], str],
    plugin_loads: list[Any],
    plugin_errors: list[str],
    beautiful_soup: Any,
    bridge_call: Callable[[str, str, dict[str, Any] | None, int], dict[str, Any]],
    enabled_sources: list[str],
    enabled_hunt_modes: list[str],
    parser_version: str,
    get_cache_stats: Callable[[], Any],
    get_index_cache_stats: Callable[[], Any],
    execution_modes: set[str],
    tool_registry: dict[str, object],
    load_plugins: Callable[[], None],
    ensure_project_layout: Callable[[ToolPayload], str],
    running_jobs: dict[str, subprocess.Popen[bytes]],
    get_project_root: Callable[[str], Any],
    append_reflexion: Callable[[str, ToolPayload], Any],
    append_session_note: Callable[[str, str, str], Any],
    end_session: Callable[[str, str], Any],
    get_session: Callable[[str, str], Any],
    pull_andon: Callable[[str, ToolPayload], Any],
    read_reflexion: Callable[[str, int], list[Any]],
    start_session: Callable[[str], Any],
    utc_now: Callable[[], str],
) -> None:
    @register_tool("lab.health", "Return internal lab subsystem status and registry metadata.", "low", category="lab")
    def tool_lab_health(payload: ToolPayload) -> ToolResult:
        request = LabHealthRequest.from_payload(payload)
        browser_status: BridgeStatus
        try:
            browser_status = BridgeStatus.from_result(bridge_call("GET", "/health", None, request.browser_timeout_seconds))
        except Exception as exc:
            browser_status = BridgeStatus.from_exception(exc)
        status = "online"
        if plugin_errors or not browser_status.ok or beautiful_soup is None:
            status = "degraded"
        return {
            "status": status,
            "policy_mode": policy_mode(),
            "validation": tool_router_validation_state().to_dict(),
            "tools": len(tool_registry),
            "plugin_loads": [item.to_dict() if hasattr(item, "to_dict") else item for item in plugin_loads],
            "plugin_errors": plugin_errors,
            "dependencies": {"beautifulsoup4": beautiful_soup is not None},
            "browser_bridge": browser_status.to_dict(),
            "research": {
                "sources": enabled_sources,
                "modes": enabled_hunt_modes,
                "parser_version": parser_version,
                "cache": get_cache_stats(),
            },
            "context_index_cache": get_index_cache_stats(),
            "execution_modes": sorted(execution_modes),
        }

    @register_tool("lab.tools.reload", "Reload tool plugins from the lab_plugins directory.", "medium", category="lab", approval_required=True, mutating=False)
    def tool_lab_tools_reload(payload: ToolPayload) -> ToolResult:
        before = len(tool_registry)
        load_plugins()
        return {
            "tool_count": len(tool_registry),
            "tool_count_before": before,
            "plugin_loads": [item.to_dict() if hasattr(item, "to_dict") else item for item in plugin_loads],
            "plugin_errors": plugin_errors,
        }

    @register_tool("lab.session.start", "Start a lab session record for a project.", "low", category="lab", mutating=True)
    def tool_lab_session_start(payload: ToolPayload) -> ToolResult:
        request = SessionStartRequest.from_payload(ensure_project_layout, payload)
        return start_session(request.project_id, title=request.title, meta=request.meta).to_dict()

    @register_tool("lab.session.get", "Read a lab session record.", "low", category="lab")
    def tool_lab_session_get(payload: ToolPayload) -> ToolResult:
        ref = SessionRef.from_payload(error_cls, payload)
        try:
            return get_session(ref.project_id, ref.session_id).to_dict()
        except FileNotFoundError:
            raise error_cls("NOT_FOUND", "session not found", 404)

    @register_tool("lab.session.note", "Append a note to a lab session.", "medium", category="lab", mutating=True)
    def tool_lab_session_note(payload: ToolPayload) -> ToolResult:
        request = SessionNoteRequest.from_payload(error_cls, payload)
        return append_session_note(
            request.ref.project_id,
            request.ref.session_id,
            request.note,
            note_type=request.note_type,
        ).to_dict()

    @register_tool("lab.session.end", "Close or otherwise mark the state of a lab session.", "medium", category="lab", mutating=True)
    def tool_lab_session_end(payload: ToolPayload) -> ToolResult:
        request = SessionEndRequest.from_payload(error_cls, payload)
        return end_session(request.ref.project_id, request.ref.session_id, status=request.status).to_dict()

    @register_tool("lab.andon.pull", "Record an andon event and pause the session.", "medium", category="lab", mutating=True)
    def tool_lab_andon_pull(payload: ToolPayload) -> ToolResult:
        request = AndonPullRequest.from_payload(error_cls, payload)
        return pull_andon(
            request.project_id,
            {
                "session_id": request.session_id,
                "reason": request.reason,
                "details": request.details,
            },
        ).to_dict()

    @register_tool("lab.reflexion.append", "Append a lessons-learned/reflexion record.", "medium", category="lab", mutating=True)
    def tool_lab_reflexion_append(payload: ToolPayload) -> ToolResult:
        request = ReflexionAppendRequest.from_payload(error_cls, payload)
        return append_reflexion(
            request.project_id,
            {
                "session_id": request.session_id,
                "title": request.title,
                "content": request.content,
                "tags": request.tags,
            },
        ).to_dict()

    @register_tool("lab.reflexion.read", "Read recent reflexion entries.", "low", category="lab")
    def tool_lab_reflexion_read(payload: ToolPayload) -> ToolResult:
        request = ReflexionReadRequest.from_payload(error_cls, payload)
        rows = read_reflexion(request.project_id, limit=request.limit)
        return {"project_id": request.project_id, "count": len(rows), "entries": [row.to_dict() for row in rows]}

    @register_tool("lab.apoptosis.trigger", "Terminate jobs and optionally hard-reset repo state after repeated failure.", "critical", category="lab", approval_required=True, mutating=True)
    def tool_lab_apoptosis_trigger(payload: ToolPayload) -> ToolResult:
        request = ApoptosisTriggerRequest.from_payload(error_cls, payload)
        actions: list[str] = []
        terminated: list[str] = []
        if request.terminate_running_jobs:
            for job_id, proc in list(running_jobs.items()):
                try:
                    proc.kill()
                    terminated.append(job_id)
                except Exception:
                    pass
                finally:
                    running_jobs.pop(job_id, None)
            actions.append("terminate_running_jobs")
        root = get_project_root(request.project_id)
        if request.git_reset_hard:
            subprocess.run(["git", "reset", "--hard", "HEAD"], cwd=str(root), capture_output=True, text=True, timeout=60)
            actions.append("git_reset_hard")
        if request.git_clean_fd:
            subprocess.run(["git", "clean", "-fd"], cwd=str(root), capture_output=True, text=True, timeout=60)
            actions.append("git_clean_fd")
        session_id = _get_str(payload, "session_id").strip()
        if session_id:
            try:
                end_session(request.project_id, session_id, status="apoptosis")
            except Exception:
                pass
        append_reflexion(request.project_id, {"title": "software_apoptosis", "content": request.reason, "tags": ["apoptosis", "recovery"]})
        return {"project_id": request.project_id, "actions": actions, "terminated_jobs": terminated, "time": utc_now()}
