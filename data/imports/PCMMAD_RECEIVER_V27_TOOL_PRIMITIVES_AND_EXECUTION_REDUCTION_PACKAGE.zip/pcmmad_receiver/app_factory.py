from __future__ import annotations

from dataclasses import dataclass

from flask import Flask
from control_plane_models import BootReport, BootRuntimeStatus


@dataclass(frozen=True)
class BlueprintLoadSpec:
    module_name: str
    blueprint_name: str
    is_required: bool = True


REQUIRED_BLUEPRINTS = (
    BlueprintLoadSpec('legacy_routes', 'legacy_bp', True),
    BlueprintLoadSpec('execution_routes', 'execution_bp', True),
    BlueprintLoadSpec('power_routes', 'power_bp', True),
    BlueprintLoadSpec('lab_routes', 'lab_bp', True),
)

OPTIONAL_BLUEPRINTS = (
    BlueprintLoadSpec('research_routes', 'research_bp', False),
    BlueprintLoadSpec('context_routes', 'context_bp', False),
)


def _register_blueprint(app: Flask, spec: BlueprintLoadSpec, boot_report: BootReport) -> None:
    try:
        module = __import__(spec.module_name, fromlist=[spec.blueprint_name])
        blueprint = getattr(module, spec.blueprint_name)
        app.register_blueprint(blueprint)
        boot_report.record_loaded(module=spec.module_name, blueprint=spec.blueprint_name)
    except Exception as exc:  # pragma: no cover - runtime validation depends on host env
        error = f'{type(exc).__name__}: {exc}'
        boot_report.record_failure(
            module=spec.module_name,
            blueprint=spec.blueprint_name,
            error=error,
            required=spec.is_required,
        )
        if spec.is_required:
            raise RuntimeError(
                f"Failed to load required blueprint {spec.blueprint_name} from {spec.module_name}: {exc}"
            ) from exc
        app.logger.warning(
            'optional blueprint failed to load: module=%s blueprint=%s error=%s',
            spec.module_name,
            spec.blueprint_name,
            exc,
        )


def create_app() -> Flask:
    app = Flask(__name__)
    boot_report = BootReport()

    for spec in REQUIRED_BLUEPRINTS:
        _register_blueprint(app, spec, boot_report)
    for spec in OPTIONAL_BLUEPRINTS:
        _register_blueprint(app, spec, boot_report)

    boot_runtime = BootRuntimeStatus()
    try:
        from execution_routes import _ensure_scheduler_started
        _ensure_scheduler_started()
        boot_runtime.execution_started = True
    except Exception as exc:  # pragma: no cover
        boot_runtime.execution_error = f'{type(exc).__name__}: {exc}'
    try:
        from lab_routes import _ensure_batch_executor
        _ensure_batch_executor()
        boot_runtime.lab_executor_started = True
    except Exception as exc:  # pragma: no cover
        boot_runtime.lab_executor_error = f'{type(exc).__name__}: {exc}'
    app.config['PCMMAD_BOOT_REPORT'] = boot_report.to_dict()
    app.config['PCMMAD_BOOT_RUNTIME'] = boot_runtime.to_dict()
    app.config['PCMMAD_BOOT_DEGRADED'] = bool(boot_report.degraded() or boot_runtime.degraded())
    return app
