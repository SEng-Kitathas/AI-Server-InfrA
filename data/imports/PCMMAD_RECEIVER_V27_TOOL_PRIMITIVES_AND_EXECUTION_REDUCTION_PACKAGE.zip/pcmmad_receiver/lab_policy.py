from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


@dataclass
class PolicyDecision:
    allowed: bool
    mode: str
    approved: bool
    reason: str
    warning: str | None = None


def policy_mode() -> str:
    mode = os.environ.get("PCMMAD_LAB_POLICY_MODE", "strict").strip().lower()
    return mode if mode in {"strict", "advisory", "open"} else "strict"


def _approval_present(approval: Any) -> bool:
    if not isinstance(approval, dict):
        return False
    return bool(approval.get("permit") is True or str(approval.get("decision", "")).lower() in {"allow", "approve", "approved"})


def _spec_attr(spec: Any, name: str, default: Any) -> Any:
    if hasattr(spec, name):
        return getattr(spec, name)
    if isinstance(spec, dict):
        return spec.get(name, default)
    return default


def evaluate_tool_call(spec: Any, payload: dict[str, Any]) -> PolicyDecision:
    mode = policy_mode()
    approval = payload.get("approval") if isinstance(payload, dict) else None
    approved = _approval_present(approval)
    danger_tier = str(_spec_attr(spec, "danger_tier", "medium"))
    approval_required = bool(_spec_attr(spec, "approval_required", False) or danger_tier in {"high", "critical"} or _spec_attr(spec, "mutating", False))
    if mode == "open":
        return PolicyDecision(True, mode, approved, "open mode permits all tool calls")
    if not approval_required:
        return PolicyDecision(True, mode, approved, "tool does not require approval")
    if approved:
        return PolicyDecision(True, mode, True, "explicit approval attached to payload")
    if mode == "advisory":
        return PolicyDecision(True, mode, False, "advisory mode permits call without approval", warning="approval missing for mutating/high-risk call")
    return PolicyDecision(False, mode, False, "explicit approval is required for this tool in strict mode")
