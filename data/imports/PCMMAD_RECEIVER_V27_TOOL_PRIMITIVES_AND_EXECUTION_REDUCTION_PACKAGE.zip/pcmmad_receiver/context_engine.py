from __future__ import annotations
import json, os, re, time, zipfile, struct
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any
from shared_core import ARCHIVE_EXTENSIONS, MODEL_EXTENSIONS, TEXT_EXTENSIONS, get_mount_roots, get_project_root
from context_config import (
    ARCHIVE_INSPECT_DEFAULT_MAX_ENTRIES,
    ARCHIVE_LIST_DEFAULT_LIMIT,
    DEFAULT_ALLOWED_ROOTS,
    DEFAULT_LIST_LIMIT,
    DEFAULT_READ_BYTES,
    DEFAULT_REHYDRATE_BUDGET_BYTES,
    DEFAULT_SEARCH_LIMIT,
    INDEX_CACHE_MAX_BYTES,
    INDEX_CACHE_TTL_SECONDS,
    MAX_LIST_RESULTS,
    MAX_READ_BYTES,
    MAX_READ_LINES,
    MAX_REHYDRATE_BUDGET_BYTES,
    MAX_REHYDRATE_ITEMS,
    MAX_SEARCH_FILE_BYTES,
    MAX_SEARCH_HITS,
    MODEL_LIST_DEFAULT_LIMIT,
)

TOKEN_RE = re.compile(r"[A-Za-z0-9_./:-]{3,}")
STOPWORDS = {"the","and","for","that","with","from","this","have","their","into","using","used","are","was","were","has","had","but","not","you","your","can","will","they","its","than","then","such","over","also","these","those","our","out","all","one","two","may","via","use","file","files","data","notes","note","read","search","project","state","context","latest","current","work","line"}
_INDEX_CACHE: "OrderedDict[str, dict[str, Any]]" = OrderedDict()
_INDEX_CACHE_TOTAL_BYTES = 0

class ContextPlaneError(Exception): error_code = "CONTEXT_ERROR"
class UnauthorizedError(ContextPlaneError): error_code = "UNAUTHORIZED"
class BadPathError(ContextPlaneError): error_code = "BAD_PATH"
class NotFoundError(ContextPlaneError): error_code = "NOT_FOUND"

def _norm(text: str) -> str: return " ".join(text.lower().split())
def _tokens(text: str) -> list[str]: return [t.lower() for t in TOKEN_RE.findall(text) if t.lower() not in STOPWORDS]
def get_allowed_roots() -> list[Path]:
    roots = get_mount_roots()
    return [Path(p).resolve() for p in (roots or DEFAULT_ALLOWED_ROOTS)]
def get_root_summary() -> list[str]: return [str(p) for p in get_allowed_roots()]
def project_root_path(project_id: str) -> str: return str(get_project_root(project_id))

def _artifact_class_from_path(path: Path) -> str:
    parts = [p.lower() for p in path.parts]
    s = str(path).lower()
    if "continuity" in parts and "live_shadow" in parts: return "continuity.live_shadow"
    if "continuity" in parts and "design_thread_stream" in parts: return "continuity.design_thread_stream"
    if "checkpoints" in parts: return "continuity.checkpoint"
    if "notes" in parts and "maintenance" in parts: return "notes.maintenance"
    if "state" in parts and "current" in parts: return "state.current"
    if "state" in parts and "next_steps" in parts: return "state.next_steps"
    if "state" in parts and "doctrine_snapshot" in parts: return "state.doctrine_snapshot"
    if "state" in parts and "revisit_ledger" in parts: return "state.revisit_ledger"
    if "state" in parts and "trace_matrix" in parts: return "state.trace_matrix"
    if path.suffix.lower() in MODEL_EXTENSIONS: return "model.binary"
    if path.suffix.lower() in ARCHIVE_EXTENSIONS or path.name.lower().endswith(".tar.gz"): return "archive.binary"
    if "code" in parts or path.suffix.lower() == ".py": return "code"
    if "cil" in s: return "cilnx.related"
    return "generic"

ARTIFACT_PRIORS = {"continuity.live_shadow":3.2,"continuity.checkpoint":2.7,"continuity.design_thread_stream":2.4,"state.current":2.1,"state.next_steps":2.0,"notes.maintenance":1.6,"code":1.4,"generic":1.0}

def resolve_user_path(user_path: str, base_root: str | None = None) -> Path:
    allowed_roots = get_allowed_roots()
    root = Path(base_root).resolve() if base_root else allowed_roots[0]
    if not any(ar == root or ar in root.parents for ar in allowed_roots):
        raise BadPathError("base_root is not an allowed root")
    user_path = user_path or "."
    candidate = (root / user_path).resolve() if not Path(user_path).is_absolute() else Path(user_path).resolve()
    if not any(ar == candidate or ar in candidate.parents for ar in allowed_roots):
        raise BadPathError("resolved path escapes allowed roots")
    return candidate

def _safe_stat(path: Path) -> dict[str, Any]:
    st = path.stat()
    return {"path":str(path),"name":path.name,"is_dir":path.is_dir(),"size_bytes":st.st_size,"modified_at":st.st_mtime,"extension":path.suffix.lower(),"artifact_class":_artifact_class_from_path(path)}

def _walk(root: Path, recursive: bool, limit: int):
    results=[]; warnings=[]; skipped=[]; partial=False
    def scan(path: Path):
        nonlocal partial
        try:
            with os.scandir(path) as it:
                for entry in it:
                    p = Path(entry.path)
                    results.append(p)
                    if len(results) >= limit:
                        partial = True; return
                    if recursive and entry.is_dir(follow_symlinks=False):
                        scan(p)
                        if len(results) >= limit: return
        except (FileNotFoundError, PermissionError, OSError) as e:
            warnings.append({"kind":"walk_skip","message":str(e),"path":str(path)}); skipped.append(str(path)); partial=True
    scan(root)
    return results, warnings, skipped, partial

def list_files(path="", base_root=None, recursive=False, contains=None, limit=None):
    target = resolve_user_path(path or ".", base_root=base_root)
    if not target.exists(): raise NotFoundError("target path does not exist")
    if not target.is_dir(): raise BadPathError("list target must be a directory")
    limit = max(1, min(limit or DEFAULT_LIST_LIMIT, MAX_LIST_RESULTS))
    items, warnings, skipped, partial = _walk(target, recursive, limit)
    needle = _norm(contains) if contains else None
    out=[]
    for p in items:
        try: info = _safe_stat(p)
        except Exception as e:
            warnings.append({"kind":"stat_skip","message":str(e),"path":str(p)}); skipped.append(str(p)); partial=True; continue
        if needle and needle not in _norm(info["name"]) and needle not in _norm(info["path"]): continue
        out.append(info)
    out.sort(key=lambda x:(x["is_dir"] is False,x["path"]))
    return FileListResponse(
        ok=True,
        partial=partial,
        warnings=[_warn_item(w) for w in warnings],
        skipped_paths=skipped,
        root_summary=get_root_summary(),
        target=str(target),
        recursive=recursive,
        count=len(out),
        items=[_file_item(item) for item in out],
    )

def read_file(path, base_root=None, start_line=None, end_line=None, max_bytes=None):
    target = resolve_user_path(path, base_root=base_root)
    if not target.exists() or not target.is_file(): raise NotFoundError("file not found")
    if target.suffix.lower() not in TEXT_EXTENSIONS: raise BadPathError("file is not readable as text; use model/archive inspect")
    raw = target.read_text(encoding="utf-8", errors="replace")
    max_bytes = min(max_bytes or DEFAULT_READ_BYTES, MAX_READ_BYTES)
    lines = raw.splitlines(); total=len(lines)
    if start_line is None and end_line is None:
        content = raw[:max_bytes]; rs=1; re=min(total, content.count("\n")+1 if content else 0)
    else:
        s=max(1,start_line or 1); e=min(total, end_line or min(total, s+MAX_READ_LINES-1)); e=max(e,s)
        content="\n".join(lines[s-1:e])[:max_bytes]; rs, re = s, e
    return FileReadResponse(
        ok=True,
        file=_file_item(_safe_stat(target)),
        slice=FileSlice(start_line=rs, end_line=re, max_bytes=max_bytes),
        content=content,
    )

def _cache_key(path: Path): return str(path)
def _estimate_size(obj): return len(json.dumps(obj, ensure_ascii=False).encode("utf-8"))
def _cache_prune():
    global _INDEX_CACHE_TOTAL_BYTES
    now = time.time()
    expired=[k for k,v in list(_INDEX_CACHE.items()) if now-v["created_at"] > INDEX_CACHE_TTL_SECONDS]
    for k in expired:
        rem=_INDEX_CACHE.pop(k,None)
        if rem: _INDEX_CACHE_TOTAL_BYTES -= rem["size_bytes"]
    while _INDEX_CACHE_TOTAL_BYTES > INDEX_CACHE_MAX_BYTES and _INDEX_CACHE:
        _, rem=_INDEX_CACHE.popitem(last=False); _INDEX_CACHE_TOTAL_BYTES -= rem["size_bytes"]

def _cache_get(path: Path):
    rec=_INDEX_CACHE.get(_cache_key(path))
    if not rec: return None
    if time.time()-rec["created_at"] > INDEX_CACHE_TTL_SECONDS:
        rem=_INDEX_CACHE.pop(_cache_key(path),None)
        global _INDEX_CACHE_TOTAL_BYTES
        if rem: _INDEX_CACHE_TOTAL_BYTES -= rem["size_bytes"]
        return None
    _INDEX_CACHE.move_to_end(_cache_key(path)); return rec["payload"]

def _cache_put(path: Path, payload):
    global _INDEX_CACHE_TOTAL_BYTES
    size=_estimate_size(payload)
    if size > INDEX_CACHE_MAX_BYTES: return
    old=_INDEX_CACHE.pop(_cache_key(path),None)
    if old: _INDEX_CACHE_TOTAL_BYTES -= old["size_bytes"]
    _INDEX_CACHE[_cache_key(path)]={"created_at":time.time(),"size_bytes":size,"payload":payload}
    _INDEX_CACHE_TOTAL_BYTES += size
    _INDEX_CACHE.move_to_end(_cache_key(path)); _cache_prune()

def get_index_cache_stats():
    _cache_prune()
    return {"entries":len(_INDEX_CACHE),"bytes":max(_INDEX_CACHE_TOTAL_BYTES,0),"max_bytes":INDEX_CACHE_MAX_BYTES,"ttl_seconds":INDEX_CACHE_TTL_SECONDS}

def _index_file(path: Path):
    if path.suffix.lower() not in TEXT_EXTENSIONS: return None
    cached=_cache_get(path)
    if cached is not None: return cached
    raw=path.read_text(encoding="utf-8", errors="replace")[:MAX_SEARCH_FILE_BYTES]
    payload={"tokens":Counter(_tokens(raw)),"content":raw,"lines":raw.splitlines(),"artifact_class":_artifact_class_from_path(path),"modified_at":path.stat().st_mtime}
    _cache_put(path,payload); return payload

def search_files(query, base_root=None, path="", artifact_classes=None, recursive=True, limit=None):
    if not query.strip(): raise ContextPlaneError("query is required")
    target=resolve_user_path(path or ".", base_root=base_root)
    if not target.exists(): raise NotFoundError("search target does not exist")
    qtokens=_tokens(query)
    if not qtokens: raise ContextPlaneError("query did not produce meaningful tokens")
    limit=max(1,min(limit or DEFAULT_SEARCH_LIMIT, MAX_SEARCH_HITS))
    if target.is_file():
        files=[target]; warnings=[]; skipped=[]; partial=False
    else:
        all_items,warnings,skipped,partial=_walk(target,recursive,limit*8); files=[p for p in all_items if p.is_file()]
    hits=[]
    for p in files:
        art=_artifact_class_from_path(p)
        if artifact_classes and art not in artifact_classes: continue
        try: indexed=_index_file(p)
        except Exception as e:
            warnings.append({"kind":"index_skip","message":str(e),"path":str(p)}); skipped.append(str(p)); partial=True; continue
        if not indexed: continue
        counts=indexed["tokens"]; match_count=sum(counts.get(t,0) for t in qtokens)
        if match_count <= 0: continue
        lexical=sum(min(counts.get(t,0),10)*0.35 for t in qtokens)
        prior=ARTIFACT_PRIORS.get(art,1.0)
        age=max(time.time()-indexed["modified_at"],1.0); rec=0.8 if age<86400 else (0.4 if age<86400*7 else 0.0)
        score=round(lexical+prior+rec,4)
        lines=indexed["lines"]; best_line,best_score=1,-1
        for i,line in enumerate(lines, start=1):
            ls=sum(1 for t in qtokens if t in _tokens(line))
            if ls>best_score: best_score,best_line=ls,i
        s=max(1,best_line-3); e=min(len(lines),best_line+3)
        excerpt="\n".join(lines[s-1:e])[:4000]
        hits.append({"path":str(p),"artifact_class":art,"score":score,"best_window":{"start_line":s,"end_line":e},"excerpt":excerpt})
    hits.sort(key=lambda h:h["score"], reverse=True); hits=hits[:limit]
    return FileSearchResponse(
        ok=True,
        partial=partial,
        warnings=[_warn_item(w) for w in warnings],
        skipped_paths=skipped,
        query=query,
        target=str(target),
        count=len(hits),
        hits=[
            SearchHit(
                path=str(h["path"]),
                artifact_class=str(h["artifact_class"]),
                score=float(h["score"]),
                best_window=SearchWindow(
                    start_line=int(h["best_window"]["start_line"]),
                    end_line=int(h["best_window"]["end_line"]),
                ),
                excerpt=str(h["excerpt"]),
            )
            for h in hits
        ],
        index_cache=_index_cache_stats(get_index_cache_stats()),
    )

def rehydrate_context(topic, base_root=None, path="", budget_bytes=None, debug=False):
    if not topic.strip(): raise ContextPlaneError("topic is required")
    budget=max(1,min(budget_bytes or DEFAULT_REHYDRATE_BUDGET_BYTES, MAX_REHYDRATE_BUDGET_BYTES))
    target=resolve_user_path(path or ".", base_root=base_root)
    if not target.exists(): raise NotFoundError("rehydration target does not exist")
    search=search_files(query=topic, base_root=base_root, path=path, recursive=True, limit=30)
    hits=search.hits; selected=[]; used=0; picked=set()
    warnings=list(search.warnings); skipped_paths=list(search.skipped_paths); partial=search.partial
    priority=["continuity.live_shadow","continuity.checkpoint","continuity.design_thread_stream","state.current","state.next_steps","notes.maintenance","code","generic","cilnx.related"]
    for art in priority:
        art_hits=[h for h in hits if h.artifact_class==art]
        art_hits.sort(key=lambda h:h.score, reverse=True)
        for hit in art_hits:
            if len(selected)>=MAX_REHYDRATE_ITEMS: break
            size=len(hit.excerpt.encode("utf-8"))
            if used+size > budget and selected: continue
            selected.append({"path":hit.path,"artifact_class":hit.artifact_class,"score":hit.score,"window":hit.best_window.to_dict(),"excerpt":hit.excerpt})
            used += size; picked.add(hit.artifact_class)
        if len(selected)>=MAX_REHYDRATE_ITEMS: break
    # recent-artifact fallback
    if not selected and target.is_dir():
        files,w2,s2,p2=_walk(target, True, 50)
        warnings.extend(_warn_item(w) for w in w2); skipped_paths.extend(s2); partial = partial or p2
        recent=[]
        for p in files:
            if not p.is_file() or p.suffix.lower() not in TEXT_EXTENSIONS: continue
            try: recent.append((p.stat().st_mtime,p))
            except Exception: pass
        recent.sort(reverse=True)
        for _,p in recent:
            art=_artifact_class_from_path(p)
            if art not in {"continuity.live_shadow","continuity.design_thread_stream","continuity.checkpoint","state.current","state.next_steps","notes.maintenance","code"}: continue
            excerpt=p.read_text(encoding="utf-8", errors="replace")[:4000]
            size=len(excerpt.encode("utf-8"))
            if used+size > budget and selected: continue
            selected.append({"path":str(p),"artifact_class":art,"score":0.1,"window":{"start_line":1,"end_line":min(200,excerpt.count("\\n")+1)},"excerpt":excerpt})
            used += size; picked.add(art)
            if len(selected)>=MAX_REHYDRATE_ITEMS: break
    open_seams=[]
    if "continuity.live_shadow" not in picked: open_seams.append("No live shadow selected; continuity state may be weaker.")
    if "continuity.design_thread_stream" not in picked: open_seams.append("No design-thread chronology selected; recovery path may be incomplete.")
    if not selected: open_seams.append("No relevant local artifacts found for requested topic.")
    resp={"ok":True,"partial":search["partial"],"warnings":search["warnings"],"skipped_paths":search["skipped_paths"],"header":{"topic":topic,"target":str(target),"selected_items":len(selected),"budget_bytes":budget,"used_bytes":used},"selected":selected,"open_seams":open_seams,"index_cache":get_index_cache_stats()}
    if debug: resp["debug_trace"]={"search_hit_count":len(hits)}
    return resp

def _infer_model_type(path: Path) -> str:
    s=path.suffix.lower()
    return {" .safetensors":"safetensors",".safetensors":"safetensors",".gguf":"gguf",".onnx":"onnx",".bin":"bin",".pt":"pt",".pth":"pth"}.get(s,"auto")

def list_models(project_id, path=".", recursive=True, model_type="auto", limit=None):
    listing=list_files(path=path, base_root=project_root_path(project_id), recursive=recursive, limit=(limit or MODEL_LIST_DEFAULT_LIMIT)*8)
    items=[]
    for item in listing.items:
        if item.is_dir: continue
        p=Path(item.path); mt=_infer_model_type(p)
        if p.suffix.lower() not in MODEL_EXTENSIONS: continue
        if model_type!="auto" and mt!=model_type: continue
        items.append({"path":item.path,"name":item.name,"model_type":mt,"size_bytes":item.size_bytes,"modified_at":item.modified_at})
        if len(items) >= (limit or MODEL_LIST_DEFAULT_LIMIT): break
    return ModelListResponse(
        ok=True,
        partial=listing.partial,
        warnings=listing.warnings,
        skipped_paths=listing.skipped_paths,
        count=len(items),
        items=[ModelItem(path=str(i["path"]), name=str(i["name"]), model_type=str(i["model_type"]), size_bytes=int(i["size_bytes"]), modified_at=float(i["modified_at"])) for i in items],
    )

def inspect_model(project_id, path, model_type="auto"):
    target=resolve_user_path(path, base_root=project_root_path(project_id))
    if not target.exists() or not target.is_file(): raise NotFoundError("model file not found")
    mt=_infer_model_type(target) if model_type=="auto" else model_type
    size=target.stat().st_size; meta={"name":target.name,"suffix":target.suffix.lower()}; warnings=[]
    try:
        if mt=="safetensors":
            with target.open("rb") as f:
                head=f.read(8)
                if len(head)==8:
                    header_len=struct.unpack("<Q", head)[0]
                    meta["header_bytes"]=int(header_len)
                    if 0 < header_len < 10_000_000:
                        hdr=f.read(min(header_len,200000))
                        try:
                            j=json.loads(hdr.decode("utf-8", errors="replace"))
                            meta["tensor_count"]=len(j.keys()); meta["tensor_names_preview"]=list(j.keys())[:20]
                        except Exception as e:
                            warnings.append({"kind":"partial_parse","message":str(e),"path":str(target)})
        elif mt=="gguf":
            with target.open("rb") as f:
                meta["magic"]=f.read(4).decode("latin1", errors="replace"); meta["version"]=int.from_bytes(f.read(4),"little",signed=False)
        else:
            with target.open("rb") as f:
                meta["magic_preview"]=f.read(16).hex()
    except Exception as e:
        warnings.append({"kind":"inspect_partial","message":str(e),"path":str(target)})
    return ModelInspectResponse(
        ok=True,
        path=str(target),
        model_type=mt,
        size_bytes=size,
        metadata=meta,
        partial=bool(warnings),
        warnings=[_warn_item(w) for w in warnings],
    )

def _infer_archive_type(path: Path) -> str:
    name=path.name.lower()
    if name.endswith(".tar.gz") or name.endswith(".tgz"): return "tar.gz"
    if name.endswith(".zip"): return "zip"
    if name.endswith(".tar"): return "tar"
    if name.endswith(".7z"): return "7z"
    if name.endswith(".gz"): return "gz"
    return "auto"

def list_archives(project_id, path=".", recursive=True, archive_type="auto", limit=None):
    listing=list_files(path=path, base_root=project_root_path(project_id), recursive=recursive, limit=(limit or ARCHIVE_LIST_DEFAULT_LIMIT)*8)
    items=[]
    for item in listing.items:
        if item.is_dir: continue
        p=Path(item.path); at=_infer_archive_type(p)
        if p.suffix.lower() not in ARCHIVE_EXTENSIONS and not p.name.lower().endswith(".tar.gz"): continue
        if archive_type!="auto" and at!=archive_type: continue
        items.append({"path":item.path,"name":item.name,"archive_type":at,"size_bytes":item.size_bytes,"modified_at":item.modified_at})
        if len(items) >= (limit or ARCHIVE_LIST_DEFAULT_LIMIT): break
    return ArchiveListResponse(
        ok=True,
        partial=listing.partial,
        warnings=listing.warnings,
        skipped_paths=listing.skipped_paths,
        count=len(items),
        items=[ArchiveItem(path=str(i["path"]), name=str(i["name"]), archive_type=str(i["archive_type"]), size_bytes=int(i["size_bytes"]), modified_at=float(i["modified_at"])) for i in items],
    )

def inspect_archive(project_id, path, archive_type="auto", max_entries=None):
    target=resolve_user_path(path, base_root=project_root_path(project_id))
    if not target.exists() or not target.is_file(): raise NotFoundError("archive file not found")
    at=_infer_archive_type(target) if archive_type=="auto" else archive_type
    max_entries=max(1,min(max_entries or ARCHIVE_INSPECT_DEFAULT_MAX_ENTRIES,5000))
    warnings=[]; entries=[]; total=0
    try:
        if at=="zip":
            with zipfile.ZipFile(target) as zf:
                names=zf.namelist(); entries=names[:max_entries]; total=len(names)
        else:
            warnings.append({"kind":"unsupported_archive_type","message":f"Inspection for {at} is limited in this build","path":str(target)})
    except Exception as e:
        warnings.append({"kind":"inspect_partial","message":str(e),"path":str(target)})
    return ArchiveInspectResponse(
        ok=True,
        path=str(target),
        archive_type=at,
        entry_count=total,
        entries=entries,
        partial=bool(warnings),
        warnings=[_warn_item(w) for w in warnings],
    )

def extract_archive(project_id, path, destination_path, archive_type="auto", selected_entries=None, overwrite=False):
    target=resolve_user_path(path, base_root=project_root_path(project_id))
    dest=resolve_user_path(destination_path, base_root=project_root_path(project_id)); dest.mkdir(parents=True, exist_ok=True)
    if not target.exists() or not target.is_file(): raise NotFoundError("archive file not found")
    at=_infer_archive_type(target) if archive_type=="auto" else archive_type
    warnings=[]; extracted=0; partial=False
    if at=="zip":
        with zipfile.ZipFile(target) as zf:
            names=selected_entries or zf.namelist()
            for name in names:
                try:
                    out=(dest / name).resolve()
                    if dest.resolve() not in [out,*out.parents]:
                        warnings.append({"kind":"extract_skip","message":"entry escaped destination","path":name}); partial=True; continue
                    if out.exists() and not overwrite:
                        warnings.append({"kind":"extract_skip","message":"destination exists","path":str(out)}); partial=True; continue
                    zf.extract(name, path=dest); extracted += 1
                except Exception as e:
                    warnings.append({"kind":"extract_skip","message":str(e),"path":name}); partial=True
    else:
        warnings.append({"kind":"unsupported_archive_type","message":f"Extraction for {at} is limited in this build","path":str(target)}); partial=True
    return ArchiveExtractResponse(
        ok=True,
        path=str(target),
        destination_path=str(dest),
        extracted_count=extracted,
        partial=partial,
        warnings=[_warn_item(w) for w in warnings],
    )
