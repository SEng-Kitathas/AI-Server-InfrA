from __future__ import annotations

import json
import time
from dataclasses import dataclass
from lab_tool_primitives import ToolPayload, ToolResult, payload_bool, payload_optional_int, payload_optional_str, payload_str
from typing import Callable


@dataclass(frozen=True)
class BrowserFillRequest:
    session_id: str
    selector: str
    text: str
    timeout_seconds: int


@dataclass(frozen=True)
class BrowserPromptCaptureRequest:
    session_id: str
    input_selector: str
    prompt: str
    timeout_seconds: int
    max_wait_seconds: int
    poll_interval_seconds: float
    capture_mode: str
    response_selector: str | None
    page_index: int | None
    submit_selector: str | None
    submit_key: str
    take_screenshot: bool
    screenshot_name: str | None


def register_browser_tools(
    register_tool: Callable[..., Callable[[Callable[[ToolPayload], ToolResult]], Callable[[ToolPayload], ToolResult]]],
    *,
    bridge_call: Callable[[str, str, ToolResult | None, int], ToolResult],
    bridge_payload_subset: Callable[[ToolPayload, tuple[str, ...] | list[str]], ToolResult],
    bridge_timeout: Callable[[ToolPayload, int, int], int],
    error_cls: type[Exception],
) -> None:

    def _capture_request(payload: ToolPayload) -> BrowserPromptCaptureRequest:
        session_id = payload_str(payload, "session_id").strip()
        input_selector = _payload_str(payload, "input_selector").strip()
        if not session_id or not input_selector:
            raise error_cls("BAD_REQUEST", "session_id and input_selector are required", 400)
        timeout_seconds = bridge_timeout(payload, 30, 120)
        return BrowserPromptCaptureRequest(
            session_id=session_id,
            input_selector=input_selector,
            prompt=_payload_str(payload, "prompt"),
            timeout_seconds=timeout_seconds,
            max_wait_seconds=max(0, min(int(payload.get("max_wait_seconds", payload.get("wait_seconds", 8))), 300)),
            poll_interval_seconds=max(0.1, min(float(payload.get("poll_interval_seconds", 1.0)), 10.0)),
            capture_mode=_payload_str(payload, "capture_mode", "body_text"),
            response_selector=payload_optional_str(payload, "response_selector"),
            page_index=_payload_optional_int(payload, "page_index"),
            submit_selector=_payload_optional_str(payload, "submit_selector"),
            submit_key=_payload_str(payload, "submit_key", "Enter"),
            take_screenshot=_payload_bool(payload, "take_screenshot", True),
            screenshot_name=_payload_optional_str(payload, "screenshot_name"),
        )

    def _capture_browser_payload(session_id: str, capture_mode: str, response_selector: str | None, timeout_seconds: int) -> ToolResult:
        if capture_mode == "html":
            return bridge_call("POST", "/content", {"session_id": session_id}, timeout_seconds)
        if response_selector:
            return bridge_call("POST", "/text", {"session_id": session_id, "selector": response_selector}, timeout_seconds)
        return bridge_call("POST", "/evaluate", {"session_id": session_id, "expression": "() => document.body.innerText"}, timeout_seconds)

    def _browser_capture_signature(captured: ToolPayload) -> str:
        try:
            return json.dumps(captured, sort_keys=True, ensure_ascii=False)
        except Exception:
            return str(captured)

    def _browser_capture_has_signal(captured: ToolPayload) -> bool:
        for key in ("text", "content", "raw", "result"):
            value = captured.get(key)
            if isinstance(value, str) and value.strip():
                return True
        return bool(captured)

    def _wait_for_browser_capture(
        session_id: str,
        capture_mode: str,
        response_selector: str | None,
        timeout_seconds: int,
        max_wait_seconds: int,
        poll_interval_seconds: float,
    ) -> tuple[ToolResult, bool, int]:
        baseline = _capture_browser_payload(session_id, capture_mode, response_selector, timeout_seconds)
        baseline_signature = _browser_capture_signature(baseline)
        deadline = time.time() + max_wait_seconds
        attempts = 0
        latest = baseline
        while time.time() < deadline:
            attempts += 1
            time.sleep(poll_interval_seconds)
            latest = _capture_browser_payload(session_id, capture_mode, response_selector, timeout_seconds)
            if _browser_capture_signature(latest) != baseline_signature and _browser_capture_has_signal(latest):
                return latest, False, attempts
        return latest, True, attempts

    def _bridge_browser_post(payload: ToolPayload, path: str, *, fields: tuple[str, ...] | list[str], timeout_default: int, timeout_max: int) -> ToolResult:
        return bridge_call("POST", path, bridge_payload_subset(payload, fields), bridge_timeout(payload, timeout_default, timeout_max))

    def _bridge_browser_get(path: str, payload: ToolPayload, *, timeout_default: int, timeout_max: int) -> ToolResult:
        return bridge_call("GET", path, None, bridge_timeout(payload, timeout_default, timeout_max))

    @register_tool("browser.health", "Check browser automation bridge health.", "low", category="browser", input_schema={"type": "object", "properties": {"timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 30}}, "additionalProperties": False})
    def tool_browser_health(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_get("/health", payload, timeout_default=10, timeout_max=30)

    @register_tool("browser.sessions.list", "List active browser bridge sessions.", "low", category="browser", input_schema={"type": "object", "properties": {"timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 30}}, "additionalProperties": False})
    def tool_browser_sessions_list(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_get("/sessions", payload, timeout_default=10, timeout_max=30)

    @register_tool("browser.session.attach", "Attach to a running debug browser session via the local bridge.", "high", category="browser", mutating=True, approval_required=True, input_schema={"type": "object", "required": ["cdp_url"], "properties": {"cdp_url": {"type": "string", "minLength": 1}, "browser": {"type": "string"}, "profile_name": {"type": "string"}, "url": {"type": "string"}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_session_attach(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/session/attach", fields=("cdp_url", "browser", "profile_name", "url"), timeout_default=30, timeout_max=120)

    @register_tool("browser.session.start", "Start a browser session through the local bridge.", "high", category="browser", mutating=True, approval_required=True, input_schema={"type": "object", "properties": {"browser": {"type": "string"}, "headless": {"type": "boolean"}, "url": {"type": "string"}, "persistent": {"type": "boolean"}, "profile_name": {"type": "string"}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_session_start(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/session/start", fields=("browser", "headless", "url", "persistent", "profile_name"), timeout_default=30, timeout_max=120)

    @register_tool("browser.session.stop", "Stop a browser bridge session.", "high", category="browser", mutating=True, approval_required=True, input_schema={"type": "object", "required": ["session_id"], "properties": {"session_id": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_session_stop(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/session/stop", fields=("session_id",), timeout_default=30, timeout_max=120)

    @register_tool("browser.pages.list", "List tabs/pages in a browser bridge session.", "low", category="browser", input_schema={"type": "object", "required": ["session_id"], "properties": {"session_id": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 60}}, "additionalProperties": False})
    def tool_browser_pages_list(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/pages/list", fields=("session_id",), timeout_default=15, timeout_max=60)

    @register_tool("browser.pages.select", "Select a tab/page in a browser bridge session.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id", "index"], "properties": {"session_id": {"type": "string", "minLength": 1}, "index": {"type": "integer", "minimum": 0}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 60}}, "additionalProperties": False})
    def tool_browser_pages_select(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/pages/select", fields=("session_id", "index"), timeout_default=15, timeout_max=60)

    @register_tool("browser.pages.new", "Open a new tab in a browser bridge session.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id"], "properties": {"session_id": {"type": "string", "minLength": 1}, "url": {"type": "string"}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 60}}, "additionalProperties": False})
    def tool_browser_pages_new(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/pages/new", fields=("session_id", "url"), timeout_default=15, timeout_max=60)

    @register_tool("browser.pages.close", "Close a tab in a browser bridge session.", "high", category="browser", mutating=True, approval_required=True, input_schema={"type": "object", "required": ["session_id", "index"], "properties": {"session_id": {"type": "string", "minLength": 1}, "index": {"type": "integer", "minimum": 0}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 60}}, "additionalProperties": False})
    def tool_browser_pages_close(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/pages/close", fields=("session_id", "index"), timeout_default=15, timeout_max=60)

    @register_tool("browser.navigate", "Navigate the current browser bridge page.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id", "url"], "properties": {"session_id": {"type": "string", "minLength": 1}, "url": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_navigate(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/navigate", fields=("session_id", "url"), timeout_default=30, timeout_max=120)

    @register_tool("browser.fill", "Fill a selector in the browser bridge.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id", "selector", "text"], "properties": {"session_id": {"type": "string", "minLength": 1}, "selector": {"type": "string", "minLength": 1}, "text": {"type": "string"}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_fill(payload: ToolPayload) -> ToolResult:
        request = BrowserFillRequest(
            session_id=payload_str(payload, "session_id").strip(),
            selector=_payload_str(payload, "selector").strip(),
            text=_payload_str(payload, "text"),
            timeout_seconds=bridge_timeout(payload, 30, 120),
        )
        bridge_payload = {"session_id": request.session_id, "selector": request.selector, "text": request.text}
        return bridge_call("POST", "/fill", bridge_payload, request.timeout_seconds)

    @register_tool("browser.click", "Click a selector in the browser bridge.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id", "selector"], "properties": {"session_id": {"type": "string", "minLength": 1}, "selector": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_click(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/click", fields=("session_id", "selector"), timeout_default=30, timeout_max=120)

    @register_tool("browser.press", "Press a key on a selector in the browser bridge.", "medium", category="browser", mutating=True, input_schema={"type": "object", "required": ["session_id", "selector", "key"], "properties": {"session_id": {"type": "string", "minLength": 1}, "selector": {"type": "string", "minLength": 1}, "key": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_press(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/press", fields=("session_id", "selector", "key"), timeout_default=30, timeout_max=120)

    @register_tool("browser.content", "Capture page HTML from the browser bridge.", "medium", category="browser", input_schema={"type": "object", "required": ["session_id"], "properties": {"session_id": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_content(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/content", fields=("session_id",), timeout_default=30, timeout_max=120)

    @register_tool("browser.evaluate", "Evaluate JavaScript in the browser bridge.", "high", category="browser", mutating=False, approval_required=True, input_schema={"type": "object", "required": ["session_id", "expression"], "properties": {"session_id": {"type": "string", "minLength": 1}, "expression": {"type": "string", "minLength": 1}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_evaluate(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/evaluate", fields=("session_id", "expression"), timeout_default=30, timeout_max=120)

    @register_tool("browser.screenshot", "Capture a screenshot through the browser bridge.", "medium", category="browser", input_schema={"type": "object", "required": ["session_id"], "properties": {"session_id": {"type": "string", "minLength": 1}, "name": {"type": "string"}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}}, "additionalProperties": False})
    def tool_browser_screenshot(payload: ToolPayload) -> ToolResult:
        return _bridge_browser_post(payload, "/screenshot", fields=("session_id", "name"), timeout_default=30, timeout_max=120)

    @register_tool("procedure.browser.prompt_capture", "Server-side browser prompt, submit, wait, and capture procedure.", "high", category="procedure", mutating=True, approval_required=True, input_schema={"type": "object", "required": ["session_id", "input_selector", "prompt"], "properties": {"session_id": {"type": "string", "minLength": 1}, "input_selector": {"type": "string", "minLength": 1}, "prompt": {"type": "string"}, "page_index": {"type": "integer", "minimum": 0}, "submit_selector": {"type": "string"}, "submit_key": {"type": "string"}, "response_selector": {"type": "string"}, "capture_mode": {"type": "string", "enum": ["body_text", "html"]}, "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120}, "max_wait_seconds": {"type": "integer", "minimum": 0, "maximum": 300}, "wait_seconds": {"type": "integer", "minimum": 0, "maximum": 300}, "poll_interval_seconds": {"type": "number", "minimum": 0.1, "maximum": 10}, "take_screenshot": {"type": "boolean"}, "screenshot_name": {"type": "string"}}, "additionalProperties": False})
    def tool_procedure_browser_prompt_capture(payload: ToolPayload) -> ToolResult:
        request = _capture_request(payload)
        if request.page_index is not None:
            bridge_call("POST", "/pages/select", {"session_id": request.session_id, "index": request.page_index}, request.timeout_seconds)
        bridge_call("POST", "/fill", {"session_id": request.session_id, "selector": request.input_selector, "text": request.prompt}, request.timeout_seconds)
        if request.submit_selector:
            bridge_call("POST", "/click", {"session_id": request.session_id, "selector": request.submit_selector}, request.timeout_seconds)
        else:
            bridge_call("POST", "/press", {"session_id": request.session_id, "selector": request.input_selector, "key": request.submit_key}, request.timeout_seconds)
        captured, timed_out, poll_attempts = _wait_for_browser_capture(
            request.session_id,
            request.capture_mode,
            request.response_selector,
            request.timeout_seconds,
            request.max_wait_seconds,
            request.poll_interval_seconds,
        )
        shot = None
        screenshot_error = None
        if request.take_screenshot:
            try:
                shot = bridge_call("POST", "/screenshot", {"session_id": request.session_id, "name": request.screenshot_name}, request.timeout_seconds)
            except Exception as exc:
                screenshot_error = str(exc)
        return {
            "session_id": request.session_id,
            "capture_mode": request.capture_mode,
            "captured": captured,
            "timed_out": timed_out,
            "poll_attempts": poll_attempts,
            "max_wait_seconds": request.max_wait_seconds,
            "poll_interval_seconds": request.poll_interval_seconds,
            "response_selector": request.response_selector,
            "screenshot": shot,
            "screenshot_error": screenshot_error,
        }
