from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from shared_core import ensure_parent, get_project_root, resolve_mount_spec, sha256_bytes, utc_now, validate_project_id

MANIFEST_NAME = "manifest-sha256.txt"
LEDGER_NAME = "92 CORPUS_CHAIN_LEDGER.csv"
MERKLE_NAME = "93 CORPUS_MERKLE_ROOT.txt"
README_NAME = "README__SHALL_START_AT_00.md"
ZERO_SHA256 = "0" * 64
TRAVERSAL_RE = re.compile(r"^\s*\d+[A-Z]?\.\s+`([^`]+)`\s*$")
MERKLE_ROOT_RE = re.compile(r"^Merkle root .*?:\s*([0-9a-f]{64})\s*$", re.IGNORECASE)
SAFE_CORPUS_RE = re.compile(r"[^A-Za-z0-9._-]+")


class SopError(Exception):
    def __init__(self, code: str, message: str, *, extra: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = extra or {}


@dataclass(frozen=True)
class PackageFile:
    name: str
    data: bytes

    @property
    def sha256(self) -> str:
        return sha256_bytes(self.data)

    @property
    def text(self) -> str:
        return self.data.decode("utf-8", errors="replace")


class PackageSource:
    def __init__(self, source_path: Path) -> None:
        self.source_path = source_path.resolve()
        self.is_zip = self.source_path.is_file()
        self.is_dir = self.source_path.is_dir()
        if not self.is_zip and not self.is_dir:
            raise SopError("SOP_SOURCE_NOT_FOUND", f"source path not found: {self.source_path}")
        if self.is_zip and self.source_path.suffix.lower() != ".zip":
            raise SopError("SOP_UNSUPPORTED_SOURCE", "only .zip archives or extracted directories are supported")
        if self.is_zip:
            with zipfile.ZipFile(self.source_path) as zf:
                self._names = [name for name in zf.namelist() if not name.endswith("/")]
        else:
            self._names = [str(p.relative_to(self.source_path)).replace("\\", "/") for p in sorted(self.source_path.rglob("*")) if p.is_file()]

    def names(self) -> list[str]:
        return list(self._names)

    def read_bytes(self, name: str) -> bytes:
        if self.is_zip:
            with zipfile.ZipFile(self.source_path) as zf:
                return zf.read(name)
        return (self.source_path / name).read_bytes()

    def read_text(self, name: str) -> str:
        return self.read_bytes(name).decode("utf-8", errors="replace")

    def file(self, name: str) -> PackageFile:
        return PackageFile(name=name, data=self.read_bytes(name))

    def archive_meta(self) -> dict[str, Any]:
        if self.is_zip:
            raw = self.source_path.read_bytes()
            return {
                "source_kind": "zip",
                "source_path": str(self.source_path),
                "archive_bytes": len(raw),
                "archive_sha256": sha256_bytes(raw),
            }
        return {
            "source_kind": "directory",
            "source_path": str(self.source_path),
            "archive_bytes": None,
            "archive_sha256": None,
        }


def _corpora_root(project_id: str) -> Path:
    root = get_project_root(validate_project_id(project_id)) / "system" / "lab" / "corpora"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _corpus_dir(project_id: str, corpus_id: str) -> Path:
    path = _corpora_root(project_id) / corpus_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def _meta_path(project_id: str, corpus_id: str) -> Path:
    return _corpus_dir(project_id, corpus_id) / "meta.json"


def _state_path(project_id: str, corpus_id: str) -> Path:
    return _corpus_dir(project_id, corpus_id) / "state.json"


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def _save_json(path: Path, payload: Any) -> None:
    ensure_parent(path)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _sanitize_corpus_id(raw: str) -> str:
    cleaned = SAFE_CORPUS_RE.sub("-", raw.strip()).strip("-._")
    return cleaned[:96] or f"corpus-{uuid.uuid4().hex[:10]}"


def _parse_manifest(text: str) -> dict[str, str]:
    rows: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"\s{2,}", line, maxsplit=1)
        if len(parts) != 2:
            continue
        digest, name = parts[0].strip(), parts[1].strip()
        if re.fullmatch(r"[0-9a-f]{64}", digest):
            rows[name] = digest
    if not rows:
        raise SopError("SOP_MANIFEST_INVALID", "manifest-sha256.txt did not yield any file hash rows")
    return rows


def _parse_ledger(text: str) -> list[dict[str, str]]:
    reader = csv.DictReader(text.splitlines())
    rows = [dict(row) for row in reader]
    if not rows:
        raise SopError("SOP_LEDGER_INVALID", "chain ledger is empty or unreadable")
    return rows


def _parse_readme_order(text: str) -> list[str]:
    order: list[str] = []
    for line in text.splitlines():
        m = TRAVERSAL_RE.match(line)
        if m:
            order.append(m.group(1))
    return order


def _compute_entry_sha(row: dict[str, str]) -> str:
    joined = "|".join([
        str(row.get("seq", "")),
        str(row.get("file_name", "")),
        str(row.get("artifact_class", "")),
        str(row.get("authority_scope", "")),
        str(row.get("file_sha256", "")),
        str(row.get("prev_entry_sha256", "")),
        str(row.get("default_read_next_file", "")),
    ])
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()


def _verify_ledger(rows: list[dict[str, str]], manifest: dict[str, str]) -> dict[str, Any]:
    prev = ZERO_SHA256
    mismatches: list[dict[str, Any]] = []
    by_name: dict[str, dict[str, str]] = {}
    for idx, row in enumerate(rows, start=1):
        by_name[row["file_name"]] = row
        expected = _compute_entry_sha(row)
        if row.get("prev_entry_sha256") != prev:
            mismatches.append({"seq": idx, "file_name": row.get("file_name"), "kind": "prev_entry_sha256", "expected": prev, "actual": row.get("prev_entry_sha256")})
        if row.get("entry_sha256") != expected:
            mismatches.append({"seq": idx, "file_name": row.get("file_name"), "kind": "entry_sha256", "expected": expected, "actual": row.get("entry_sha256")})
        manifest_hash = manifest.get(row.get("file_name", ""))
        if manifest_hash and row.get("file_sha256") != manifest_hash:
            mismatches.append({"seq": idx, "file_name": row.get("file_name"), "kind": "file_sha256", "expected": manifest_hash, "actual": row.get("file_sha256")})
        prev = expected
    return {"ok": not mismatches, "mismatches": mismatches, "by_name": by_name, "last_entry_sha256": prev}


def _parse_merkle_root(text: str) -> str:
    for line in text.splitlines():
        m = MERKLE_ROOT_RE.match(line)
        if m:
            return m.group(1).lower()
    raise SopError("SOP_MERKLE_INVALID", "93 CORPUS_MERKLE_ROOT.txt did not contain a parseable merkle root")


def _compute_merkle_root(files: dict[str, PackageFile]) -> tuple[str, list[str]]:
    leaf_names = sorted(name for name in files if name not in {MANIFEST_NAME, LEDGER_NAME, MERKLE_NAME})
    level = [files[name].sha256 for name in leaf_names]
    if not level:
        raise SopError("SOP_MERKLE_INVALID", "no payload leaves available for merkle fold")
    while len(level) > 1:
        if len(level) % 2 == 1:
            level = level + [level[-1]]
        next_level: list[str] = []
        for i in range(0, len(level), 2):
            next_level.append(hashlib.sha256((level[i] + level[i + 1]).encode("utf-8")).hexdigest())
        level = next_level
    return level[0], leaf_names


def _build_traversal_order(readme_order: list[str], ledger_rows: list[dict[str, str]], package_names: list[str]) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        if name in package_names and name not in seen:
            ordered.append(name)
            seen.add(name)

    for name in readme_order:
        add(name)
    for row in ledger_rows:
        add(str(row.get("file_name", "")))
    for name in sorted(package_names):
        add(name)
    return ordered


def inspect_package(source_path: str | Path) -> dict[str, Any]:
    source = PackageSource(Path(source_path))
    files = {name: source.file(name) for name in source.names()}
    required = [README_NAME, MANIFEST_NAME, LEDGER_NAME, MERKLE_NAME]
    missing = [name for name in required if name not in files]
    if missing:
        raise SopError("SOP_PACKAGE_INCOMPLETE", "required package files are missing", extra={"missing": missing})

    manifest = _parse_manifest(files[MANIFEST_NAME].text)
    manifest_mismatches = []
    for name, expected in manifest.items():
        if name not in files:
            manifest_mismatches.append({"file_name": name, "kind": "missing_from_package", "expected": expected, "actual": None})
            continue
        actual = files[name].sha256
        if actual != expected:
            manifest_mismatches.append({"file_name": name, "kind": "sha256", "expected": expected, "actual": actual})

    ledger_rows = _parse_ledger(files[LEDGER_NAME].text)
    ledger = _verify_ledger(ledger_rows, manifest)
    declared_root = _parse_merkle_root(files[MERKLE_NAME].text)
    computed_root, leaf_names = _compute_merkle_root(files)
    readme_order = _parse_readme_order(files[README_NAME].text)
    traversal_order = _build_traversal_order(readme_order, ledger_rows, list(files.keys()))

    index_files: list[dict[str, Any]] = []
    ledger_by_name = ledger["by_name"]
    for seq, name in enumerate(traversal_order, start=1):
        package_file = files[name]
        ledger_row = ledger_by_name.get(name, {})
        index_files.append({
            "seq": seq,
            "file_name": name,
            "bytes": len(package_file.data),
            "sha256": package_file.sha256,
            "chars": len(package_file.text),
            "artifact_class": ledger_row.get("artifact_class"),
            "authority_scope": ledger_row.get("authority_scope"),
            "default_read_next_file": ledger_row.get("default_read_next_file"),
        })

    return {
        **source.archive_meta(),
        "required_files_present": not missing,
        "required_files_missing": missing,
        "package_names": sorted(files.keys()),
        "manifest": {
            "ok": not manifest_mismatches,
            "count": len(manifest),
            "mismatches": manifest_mismatches,
        },
        "ledger": {
            "ok": ledger["ok"],
            "count": len(ledger_rows),
            "mismatches": ledger["mismatches"],
            "last_entry_sha256": ledger["last_entry_sha256"],
        },
        "merkle": {
            "ok": declared_root == computed_root,
            "declared_root": declared_root,
            "computed_root": computed_root,
            "leaf_count": len(leaf_names),
            "leaf_names": leaf_names,
        },
        "readme_order": readme_order,
        "traversal_order": traversal_order,
        "files": index_files,
        "verified": not missing and not manifest_mismatches and ledger["ok"] and declared_root == computed_root,
    }


def register_package(project_id: str, source_path_spec: str, *, corpus_id: str | None = None, chunk_chars: int = 6000, reset: bool = False) -> dict[str, Any]:
    project_id = validate_project_id(project_id)
    source_path = resolve_mount_spec(source_path_spec, default_root=get_project_root(project_id), allow_absolute=True)
    inspection = inspect_package(source_path)
    cid = _sanitize_corpus_id(corpus_id or Path(source_path).stem)
    if _meta_path(project_id, cid).exists() and not reset:
        raise SopError("SOP_CORPUS_EXISTS", f"corpus_id already exists: {cid}")

    meta = {
        "project_id": project_id,
        "corpus_id": cid,
        "registered_at": utc_now(),
        "chunk_chars": max(1000, min(int(chunk_chars), 32000)),
        **inspection,
    }
    state = {
        "project_id": project_id,
        "corpus_id": cid,
        "registered_at": meta["registered_at"],
        "verified": inspection["verified"],
        "current_file_index": 0,
        "current_chunk_index": 0,
        "awaiting_file_completion": False,
        "issued_chunk": None,
        "completed_files": {},
        "acked_chunks": {},
        "completed_at": None,
        "last_action_at": meta["registered_at"],
    }
    _save_json(_meta_path(project_id, cid), meta)
    _save_json(_state_path(project_id, cid), state)
    return {
        "project_id": project_id,
        "corpus_id": cid,
        "verified": inspection["verified"],
        "source_kind": inspection["source_kind"],
        "source_path": inspection["source_path"],
        "file_count": len(inspection["files"]),
        "chunk_chars": meta["chunk_chars"],
        "traversal_order": inspection["traversal_order"],
        "integrity": {
            "manifest_ok": inspection["manifest"]["ok"],
            "ledger_ok": inspection["ledger"]["ok"],
            "merkle_ok": inspection["merkle"]["ok"],
        },
    }


def _load_meta_state(project_id: str, corpus_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    meta = _load_json(_meta_path(project_id, corpus_id), None)
    state = _load_json(_state_path(project_id, corpus_id), None)
    if not isinstance(meta, dict) or not isinstance(state, dict):
        raise SopError("SOP_CORPUS_NOT_FOUND", f"corpus not registered: {corpus_id}")
    return meta, state


def _source_from_meta(meta: dict[str, Any]) -> PackageSource:
    return PackageSource(Path(meta["source_path"]))


def _current_file(meta: dict[str, Any], state: dict[str, Any]) -> dict[str, Any] | None:
    idx = int(state.get("current_file_index", 0))
    files = meta.get("files") or []
    if idx < 0 or idx >= len(files):
        return None
    return files[idx]


def ingestion_status(project_id: str, corpus_id: str) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    current = _current_file(meta, state)
    completed_count = len(state.get("completed_files") or {})
    total = len(meta.get("files") or [])
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "verified": bool(state.get("verified", False)),
        "source_path": meta.get("source_path"),
        "chunk_chars": meta.get("chunk_chars"),
        "completed_files": completed_count,
        "total_files": total,
        "all_files_complete": completed_count == total and total > 0,
        "awaiting_file_completion": bool(state.get("awaiting_file_completion", False)),
        "current_file": current,
        "issued_chunk": state.get("issued_chunk"),
        "completed_at": state.get("completed_at"),
        "last_action_at": state.get("last_action_at"),
    }


def next_chunk(project_id: str, corpus_id: str) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    current = _current_file(meta, state)
    if current is None:
        if not state.get("completed_at"):
            state["completed_at"] = utc_now()
            _save_json(_state_path(project_id, corpus_id), state)
        return {"project_id": project_id, "corpus_id": corpus_id, "done": True, "completed_at": state.get("completed_at")}
    if state.get("awaiting_file_completion"):
        raise SopError("SOP_FILE_RECEIPT_REQUIRED", "current file is fully delivered; call sop.ingest.complete_file before proceeding", extra={"file_name": current["file_name"]})

    source = _source_from_meta(meta)
    package_file = source.file(current["file_name"])
    text = package_file.text
    chunk_chars = int(meta.get("chunk_chars", 6000))
    total_chunks = max(1, math.ceil(len(text) / chunk_chars))
    chunk_index = int(state.get("current_chunk_index", 0))
    if chunk_index >= total_chunks:
        state["awaiting_file_completion"] = True
        state["last_action_at"] = utc_now()
        _save_json(_state_path(project_id, corpus_id), state)
        raise SopError("SOP_FILE_RECEIPT_REQUIRED", "all chunks already delivered for current file; complete the file receipt", extra={"file_name": current["file_name"]})
    start = chunk_index * chunk_chars
    end = min(len(text), start + chunk_chars)
    chunk_text = text[start:end]
    chunk_sha = sha256_bytes(chunk_text.encode("utf-8"))
    ack_token = f"ack-{uuid.uuid4().hex[:16]}"
    state["issued_chunk"] = {
        "file_name": current["file_name"],
        "chunk_index": chunk_index,
        "total_chunks": total_chunks,
        "char_start": start,
        "char_end": end,
        "content_sha256": chunk_sha,
        "ack_token": ack_token,
        "issued_at": utc_now(),
    }
    state["last_action_at"] = utc_now()
    _save_json(_state_path(project_id, corpus_id), state)
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "done": False,
        "file_name": current["file_name"],
        "file_seq": current["seq"],
        "file_sha256": current["sha256"],
        "artifact_class": current.get("artifact_class"),
        "authority_scope": current.get("authority_scope"),
        "default_read_next_file": current.get("default_read_next_file"),
        "chunk_index": chunk_index,
        "total_chunks": total_chunks,
        "char_start": start,
        "char_end": end,
        "content_sha256": chunk_sha,
        "ack_token": ack_token,
        "requires_file_receipt_after_ack": chunk_index == (total_chunks - 1),
        "content": chunk_text,
    }


def ack_chunk(project_id: str, corpus_id: str, ack_token: str, *, content_sha256: str | None = None) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    issued = state.get("issued_chunk") or {}
    current = _current_file(meta, state)
    if not issued or not current:
        raise SopError("SOP_NO_ISSUED_CHUNK", "no issued chunk is waiting for acknowledgment")
    if ack_token != issued.get("ack_token"):
        raise SopError("SOP_BAD_ACK_TOKEN", "ack_token does not match the currently issued chunk")
    if content_sha256 and content_sha256 != issued.get("content_sha256"):
        raise SopError("SOP_BAD_CHUNK_SHA", "content_sha256 does not match the issued chunk", extra={"expected": issued.get("content_sha256"), "actual": content_sha256})

    acked = state.setdefault("acked_chunks", {})
    acked.setdefault(current["file_name"], []).append({
        "chunk_index": issued["chunk_index"],
        "content_sha256": issued["content_sha256"],
        "acked_at": utc_now(),
    })
    state["current_chunk_index"] = int(issued["chunk_index"]) + 1
    state["issued_chunk"] = None
    state["last_action_at"] = utc_now()

    chunk_count = max(1, math.ceil(int(current["chars"]) / int(meta.get("chunk_chars", 6000))))
    delivered_final = state["current_chunk_index"] >= chunk_count
    if delivered_final:
        state["awaiting_file_completion"] = True
    _save_json(_state_path(project_id, corpus_id), state)
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "file_name": current["file_name"],
        "chunk_index": issued["chunk_index"],
        "acked": True,
        "awaiting_file_completion": delivered_final,
        "next_action": "sop.ingest.complete_file" if delivered_final else "sop.ingest.next_chunk",
    }


def complete_file(project_id: str, corpus_id: str, receipt: dict[str, Any]) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    current = _current_file(meta, state)
    if not current:
        raise SopError("SOP_ALREADY_COMPLETE", "ingestion is already complete")
    if not state.get("awaiting_file_completion"):
        raise SopError("SOP_FILE_NOT_READY", "current file is not yet ready for completion receipt")

    required_receipt = {
        "file_name": current["file_name"],
        "file_sha256": current["sha256"],
        "artifact_class": current.get("artifact_class"),
        "default_read_next_file": current.get("default_read_next_file"),
    }
    mismatches = []
    for key, expected in required_receipt.items():
        actual = receipt.get(key)
        if expected is not None and actual != expected:
            mismatches.append({"field": key, "expected": expected, "actual": actual})
    if mismatches:
        raise SopError("SOP_BAD_FILE_RECEIPT", "file completion receipt does not match package metadata", extra={"mismatches": mismatches})

    state.setdefault("completed_files", {})[current["file_name"]] = {
        "completed_at": utc_now(),
        "receipt": receipt,
    }
    state["current_file_index"] = int(state.get("current_file_index", 0)) + 1
    state["current_chunk_index"] = 0
    state["awaiting_file_completion"] = False
    state["issued_chunk"] = None
    state["last_action_at"] = utc_now()
    if state["current_file_index"] >= len(meta.get("files") or []):
        state["completed_at"] = utc_now()
    _save_json(_state_path(project_id, corpus_id), state)
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "file_name": current["file_name"],
        "completed": True,
        "all_files_complete": bool(state.get("completed_at")),
        "completed_at": state.get("completed_at"),
        "next_file": _current_file(meta, state),
    }


def guard_check(project_id: str, corpus_id: str) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    files = meta.get("files") or []
    completed = set((state.get("completed_files") or {}).keys())
    missing = [row["file_name"] for row in files if row["file_name"] not in completed]
    proceed_allowed = bool(state.get("verified")) and not missing and not state.get("awaiting_file_completion")
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "verified": bool(state.get("verified")),
        "proceed_allowed": proceed_allowed,
        "missing_files": missing,
        "awaiting_file_completion": bool(state.get("awaiting_file_completion")),
        "completed_files": len(completed),
        "total_files": len(files),
        "completed_at": state.get("completed_at"),
        "reason": None if proceed_allowed else "ingestion incomplete or integrity not verified",
    }


def reset_ingestion(project_id: str, corpus_id: str) -> dict[str, Any]:
    meta, state = _load_meta_state(project_id, corpus_id)
    state.update({
        "current_file_index": 0,
        "current_chunk_index": 0,
        "awaiting_file_completion": False,
        "issued_chunk": None,
        "completed_files": {},
        "acked_chunks": {},
        "completed_at": None,
        "last_action_at": utc_now(),
    })
    _save_json(_state_path(project_id, corpus_id), state)
    return {
        "project_id": project_id,
        "corpus_id": corpus_id,
        "reset": True,
        "verified": bool(meta.get("verified", False)),
        "file_count": len(meta.get("files") or []),
    }
