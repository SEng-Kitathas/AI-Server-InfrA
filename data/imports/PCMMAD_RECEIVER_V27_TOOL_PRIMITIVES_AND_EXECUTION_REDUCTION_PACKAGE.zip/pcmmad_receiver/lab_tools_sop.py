from __future__ import annotations

from pathlib import Path
from typing import Any, Callable


def register_sop_tools(
    register_tool: Callable[..., Callable[[Callable[[dict[str, Any]], dict[str, Any]]], Callable[[dict[str, Any]], dict[str, Any]]]],
    *,
    error_cls: type[Exception],
    read_required_project_id: Callable[[dict[str, Any]], str],
    ensure_project_layout: Callable[[dict[str, Any]], str],
    resolve_general_path: Callable[..., Path],
    sop_call: Callable[..., dict[str, Any]],
    sop_inspect_package: Callable[..., dict[str, Any]],
    sop_register_package: Callable[..., dict[str, Any]],
    sop_reset_ingestion: Callable[..., dict[str, Any]],
    sop_ingestion_status: Callable[..., dict[str, Any]],
    sop_next_chunk: Callable[..., dict[str, Any]],
    sop_ack_chunk: Callable[..., dict[str, Any]],
    sop_complete_file: Callable[..., dict[str, Any]],
    sop_guard_check: Callable[..., dict[str, Any]],
) -> None:
    @register_tool("sop.package.inspect", "Inspect a SOP/package archive, verify manifest+ledger+merkle integrity, and derive traversal order.", "medium", category="sop")
    def tool_sop_package_inspect(payload: dict[str, Any]) -> dict[str, Any]:
        path = resolve_general_path(payload, "source_path")
        return sop_call(sop_inspect_package, path)

    @register_tool("sop.package.register", "Register a SOP/package archive inside the lab and initialize chunked ingestion state.", "high", category="sop", approval_required=True, mutating=True)
    def tool_sop_package_register(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = ensure_project_layout(payload)
        source_path = str(payload.get("source_path", "")).strip()
        if not source_path:
            raise error_cls("BAD_REQUEST", "source_path is required", 400)
        return sop_call(
            sop_register_package,
            project_id,
            source_path,
            corpus_id=str(payload.get("corpus_id", "")).strip() or None,
            chunk_chars=int(payload.get("chunk_chars", 6000)),
            reset=bool(payload.get("reset", False)),
        )

    @register_tool("sop.ingest.reset", "Reset a registered SOP/package ingestion cursor back to the beginning.", "high", category="sop", approval_required=True, mutating=True)
    def tool_sop_ingest_reset(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = ensure_project_layout(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        if not corpus_id:
            raise error_cls("BAD_REQUEST", "corpus_id is required", 400)
        return sop_call(sop_reset_ingestion, project_id, corpus_id)

    @register_tool("sop.ingest.status", "Read SOP/package ingestion status, current file cursor, and proceed-gate readiness.", "low", category="sop")
    def tool_sop_ingest_status(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = read_required_project_id(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        if not corpus_id:
            raise error_cls("BAD_REQUEST", "corpus_id is required", 400)
        return sop_call(sop_ingestion_status, project_id, corpus_id)

    @register_tool("sop.ingest.next_chunk", "Return the next required chunk from the registered SOP/package traversal order. Does not allow skipping ahead.", "medium", category="sop")
    def tool_sop_ingest_next_chunk(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = read_required_project_id(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        if not corpus_id:
            raise error_cls("BAD_REQUEST", "corpus_id is required", 400)
        return sop_call(sop_next_chunk, project_id, corpus_id)

    @register_tool("sop.ingest.ack_chunk", "Acknowledge the currently issued SOP/package chunk before the next chunk may be served.", "medium", category="sop", mutating=True)
    def tool_sop_ingest_ack_chunk(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = read_required_project_id(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        ack_token = str(payload.get("ack_token", "")).strip()
        if not corpus_id or not ack_token:
            raise error_cls("BAD_REQUEST", "corpus_id and ack_token are required", 400)
        return sop_call(sop_ack_chunk, project_id, corpus_id, ack_token, content_sha256=str(payload.get("content_sha256", "")).strip() or None)

    @register_tool("sop.ingest.complete_file", "Complete the current SOP/package file by submitting a receipt that matches package metadata. This is the proceed-gate between files.", "medium", category="sop", mutating=True)
    def tool_sop_ingest_complete_file(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = read_required_project_id(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        receipt = payload.get("receipt")
        if not corpus_id or not isinstance(receipt, dict):
            raise error_cls("BAD_REQUEST", "corpus_id and receipt object are required", 400)
        return sop_call(sop_complete_file, project_id, corpus_id, receipt)

    @register_tool("sop.guard.check", "Return whether the registered SOP/package has been fully integrity-verified and completely ingested. Use before proceeding to governed work.", "low", category="sop")
    def tool_sop_guard_check(payload: dict[str, Any]) -> dict[str, Any]:
        project_id = read_required_project_id(payload)
        corpus_id = str(payload.get("corpus_id", "")).strip()
        if not corpus_id:
            raise error_cls("BAD_REQUEST", "corpus_id is required", 400)
        return sop_call(sop_guard_check, project_id, corpus_id)
