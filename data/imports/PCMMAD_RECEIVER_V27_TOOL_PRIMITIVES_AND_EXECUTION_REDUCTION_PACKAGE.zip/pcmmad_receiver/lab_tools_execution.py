from __future__ import annotations

import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from lab_tool_primitives import ToolPayload, ToolResult, payload_str, payload_value
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class ExecutionIdentity:
    project_id: str
    job_id: str


@dataclass(frozen=True)
class CommandRequest:
    project_id: str
    command: list[str]
    args: list[str]
    cwd: str | None
    timeout_seconds: int | None
    stdout_max_bytes: int | None
    stderr_max_bytes: int | None


@dataclass(frozen=True)
class WaitRequest:
    identity: ExecutionIdentity
    timeout_seconds: int | None
    max_bytes: int | None


def _require_identity(error_cls: type[Exception], payload: ToolPayload) -> ExecutionIdentity:
    project_id = _payload_str(payload, "project_id").strip()
    job_id = _payload_str(payload, "job_id").strip()
    if not project_id or not job_id:
        raise error_cls("BAD_REQUEST", "project_id and job_id are required", 400)
    return ExecutionIdentity(project_id=project_id, job_id=job_id)


def _read_command_array(error_cls: type[Exception], payload: ToolPayload) -> tuple[list[str], list[str]]:
    command = payload_value(payload, "command")
    args = payload_value(payload, "args") or []
    if not isinstance(command, list) or not command or not all(isinstance(x, str) and x for x in command):
        raise error_cls("BAD_REQUEST", "command must be a non-empty string array", 400)
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        raise error_cls("BAD_REQUEST", "args must be a string array", 400)
    return command, args


def _command_request(
    error_cls: type[Exception],
    payload: ToolPayload,
    *,
    request_optional_positive_int: Callable[..., int | None],
    default_timeout_seconds: int,
    default_stdout_max_bytes: int,
    default_stderr_max_bytes: int,
    max_timeout_seconds: int,
    max_output_bytes: int,
) -> CommandRequest:
    command, args = _read_command_array(error_cls, payload)
    return CommandRequest(
        project_id=_payload_str(payload, "project_id").strip(),
        command=command,
        args=args,
        cwd=_payload_str(payload, "cwd").strip() or None,
        timeout_seconds=request_optional_positive_int(payload.get("timeout_seconds", default_timeout_seconds), default_timeout_seconds, minimum=1, maximum=max_timeout_seconds),
        stdout_max_bytes=request_optional_positive_int(payload.get("stdout_max_bytes", default_stdout_max_bytes), default_stdout_max_bytes, minimum=1024, maximum=max_output_bytes),
        stderr_max_bytes=request_optional_positive_int(payload.get("stderr_max_bytes", default_stderr_max_bytes), default_stderr_max_bytes, minimum=1024, maximum=max_output_bytes),
    )


def _wait_request(
    error_cls: type[Exception],
    payload: ToolPayload,
    *,
    request_optional_positive_int: Callable[..., int | None],
    max_output_bytes: int,
) -> WaitRequest:
    return WaitRequest(
        identity=_require_identity(error_cls, payload),
        timeout_seconds=request_optional_positive_int(payload.get("timeout_seconds", 60), 60, minimum=1),
        max_bytes=request_optional_positive_int(payload.get("max_bytes", 262144), 262144, minimum=1024, maximum=max_output_bytes),
    )


def register_execution_tools(
    register_tool: Callable[..., Callable[[Callable[[ToolPayload], ToolResult]], Callable[[ToolPayload], ToolResult]]],
    *,
    error_cls: type[Exception],
    request_optional_positive_int: Callable[..., int | None],
    resolve_cwd: Callable[[str, str | None], Path],
    exec_env: Callable[[ToolPayload], dict[str, str]],
    finalize_job: Callable[[str, str, ToolResult], ToolResult],
    read_job: Callable[[str, str], ToolResult],
    tail_text: Callable[[Path, int], tuple[str, bool]],
    execution_modes: set[str],
    max_output_bytes: int,
    default_timeout_seconds: int,
    default_stdout_max_bytes: int,
    default_stderr_max_bytes: int,
    max_timeout_seconds: int,
    running_jobs: dict[str, subprocess.Popen[bytes]],
    job_dir: Callable[[str, str], Path],
    write_job: Callable[[str, str, ToolResult], None],
    utc_now: Callable[[], str],
) -> None:
    def _resolved_command_request(payload: ToolPayload) -> tuple[CommandRequest, Path]:
        request = _command_request(
            error_cls,
            payload,
            request_optional_positive_int=request_optional_positive_int,
            default_timeout_seconds=default_timeout_seconds,
            default_stdout_max_bytes=default_stdout_max_bytes,
            default_stderr_max_bytes=default_stderr_max_bytes,
            max_timeout_seconds=max_timeout_seconds,
            max_output_bytes=max_output_bytes,
        )
        return request, resolve_cwd(request.project_id, request.cwd)

    @register_tool("execution.run", "Run a command synchronously inside a project cwd.", "high", category="execution", approval_required=True)
    def tool_execution_run(payload: ToolPayload) -> ToolResult:
        request, cwd = _resolved_command_request(payload)
        proc = subprocess.run(
            request.command + request.args,
            cwd=str(cwd),
            env=exec_env(payload),
            capture_output=True,
            text=False,
            timeout=request.timeout_seconds,
            shell=False,
        )
        stdout = proc.stdout if not request.stdout_max_bytes else proc.stdout[:request.stdout_max_bytes]
        stderr = proc.stderr if not request.stderr_max_bytes else proc.stderr[:request.stderr_max_bytes]
        return {
            "project_id": request.project_id,
            "cwd": str(cwd),
            "command": request.command + request.args,
            "status": "COMPLETED" if proc.returncode == 0 else "FAILED",
            "return_code": proc.returncode,
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "stdout_truncated": bool(request.stdout_max_bytes) and len(proc.stdout) > request.stdout_max_bytes,
            "stderr_truncated": bool(request.stderr_max_bytes) and len(proc.stderr) > request.stderr_max_bytes,
        }

    @register_tool("python.run", "Execute inline Python with project-scoped cwd.", "high", category="execution", approval_required=True)
    def tool_python_run(payload: ToolPayload) -> ToolResult:
        request, cwd = _resolved_command_request(payload)
        code = _payload_str(payload, "code")
        if not code:
            raise error_cls("BAD_REQUEST", "code is required", 400)
        with tempfile.NamedTemporaryFile("w", suffix=".py", encoding="utf-8", delete=False) as tmp:
            tmp.write(code)
            tmp_path = Path(tmp.name)
        try:
            proc = subprocess.run(
                [sys.executable, str(tmp_path)],
                cwd=str(cwd),
                env={**exec_env(payload), "PYTHONIOENCODING": "utf-8"},
                capture_output=True,
                text=False,
                timeout=request.timeout_seconds,
                shell=False,
            )
            stdout = proc.stdout if not request.stdout_max_bytes else proc.stdout[:request.stdout_max_bytes]
            stderr = proc.stderr if not request.stderr_max_bytes else proc.stderr[:request.stderr_max_bytes]
            return {
                "project_id": request.project_id,
                "cwd": str(cwd),
                "runner": sys.executable,
                "status": "COMPLETED" if proc.returncode == 0 else "FAILED",
                "return_code": proc.returncode,
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "stdout_truncated": bool(request.stdout_max_bytes) and len(proc.stdout) > request.stdout_max_bytes,
                "stderr_truncated": bool(request.stderr_max_bytes) and len(proc.stderr) > request.stderr_max_bytes,
            }
        finally:
            tmp_path.unlink(missing_ok=True)

    @register_tool("execution.submit", "Submit an async execution job.", "high", category="execution", approval_required=True)
    def tool_execution_submit(payload: ToolPayload) -> ToolResult:
        request, cwd = _resolved_command_request(payload)
        execution_mode = _payload_str(payload, "execution_mode", "one_shot")
        if execution_mode not in execution_modes:
            raise error_cls("INVALID_EXECUTION_MODE", "invalid execution_mode", 400)
        job_id = f"job-{uuid.uuid4().hex[:12]}"
        work_dir = job_dir(request.project_id, job_id)
        stdout_path = work_dir / "stdout.log"
        stderr_path = work_dir / "stderr.log"
        full_command = request.command + request.args
        out_f = stdout_path.open("wb")
        err_f = stderr_path.open("wb")
        try:
            proc = subprocess.Popen(full_command, cwd=str(cwd), stdout=out_f, stderr=err_f, stdin=subprocess.DEVNULL, shell=False, env=exec_env(payload))
        finally:
            out_f.close()
            err_f.close()
        running_jobs[job_id] = proc
        job = {
            "project_id": request.project_id,
            "job_id": job_id,
            "status": "RUNNING",
            "stage": "runtime",
            "execution_mode": execution_mode,
            "command": full_command,
            "cwd": str(cwd),
            "submitted_at": utc_now(),
            "started_at": utc_now(),
            "deadline_epoch": time.time() + int(request.timeout_seconds or default_timeout_seconds),
            "timeout_seconds": request.timeout_seconds,
            "stdout_path": str(stdout_path),
            "stderr_path": str(stderr_path),
            "stdout_max_bytes": int(request.stdout_max_bytes or default_stdout_max_bytes),
            "stderr_max_bytes": int(request.stderr_max_bytes or default_stderr_max_bytes),
            "pid": proc.pid,
        }
        write_job(request.project_id, job_id, job)
        return job

    @register_tool("execution.status", "Read and finalize async execution job status.", "medium", category="execution")
    def tool_execution_status(payload: ToolPayload) -> ToolResult:
        identity = _require_identity(error_cls, payload)
        try:
            return finalize_job(identity.project_id, identity.job_id, read_job(identity.project_id, identity.job_id))
        except FileNotFoundError:
            raise error_cls("NOT_FOUND", "job not found", 404)

    @register_tool("execution.output", "Read bounded stdout/stderr for an async execution job.", "medium", category="execution")
    def tool_execution_output(payload: ToolPayload) -> ToolResult:
        request = _wait_request(error_cls, payload, request_optional_positive_int=request_optional_positive_int, max_output_bytes=max_output_bytes)
        try:
            job = finalize_job(request.identity.project_id, request.identity.job_id, read_job(request.identity.project_id, request.identity.job_id))
            stdout_text, stdout_truncated = tail_text(Path(job["stdout_path"]), request.max_bytes)
            stderr_text, stderr_truncated = tail_text(Path(job["stderr_path"]), request.max_bytes)
            return {
                "project_id": request.identity.project_id,
                "job_id": request.identity.job_id,
                "status": job.get("status"),
                "stdout": stdout_text,
                "stderr": stderr_text,
                "stdout_truncated": stdout_truncated,
                "stderr_truncated": stderr_truncated,
                "bytes_returned": len(stdout_text.encode("utf-8")) + len(stderr_text.encode("utf-8")),
                "max_bytes": request.max_bytes,
                "last_update_time": utc_now(),
            }
        except FileNotFoundError:
            raise error_cls("NOT_FOUND", "job not found", 404)

    @register_tool("execution.wait", "Long-poll an async execution job until complete or timeout.", "medium", category="execution")
    def tool_execution_wait(payload: ToolPayload) -> ToolResult:
        request = _wait_request(error_cls, payload, request_optional_positive_int=request_optional_positive_int, max_output_bytes=max_output_bytes)
        deadline = None if request.timeout_seconds is None else (time.time() + request.timeout_seconds)
        while deadline is None or time.time() < deadline:
            job = finalize_job(request.identity.project_id, request.identity.job_id, read_job(request.identity.project_id, request.identity.job_id))
            if job.get("status") not in {"RUNNING", "SUBMITTED", "QUEUED", "STARTING"}:
                stdout_text, stdout_truncated = tail_text(Path(job.get("stdout_path", "")), request.max_bytes)
                stderr_text, _ = tail_text(Path(job.get("stderr_path", "")), request.max_bytes)
                return {
                    "job_id": request.identity.job_id,
                    "status": job.get("status"),
                    "timed_out": False,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "return_code": job.get("return_code"),
                    "duration_ms": job.get("duration_ms"),
                    "stdout_truncated": stdout_truncated,
                }
            time.sleep(0.5)
        job = finalize_job(request.identity.project_id, request.identity.job_id, read_job(request.identity.project_id, request.identity.job_id))
        return {
            "job_id": request.identity.job_id,
            "status": job.get("status"),
            "timed_out": True,
            "stdout": "",
            "stderr": "",
            "return_code": job.get("return_code"),
            "duration_ms": job.get("duration_ms"),
            "stdout_truncated": False,
        }

    @register_tool("execution.terminate", "Terminate a running async job.", "critical", category="execution", approval_required=True, mutating=True)
    def tool_execution_terminate(payload: ToolPayload) -> ToolResult:
        identity = _require_identity(error_cls, payload)
        try:
            job = read_job(identity.project_id, identity.job_id)
            proc = running_jobs.get(identity.job_id)
            if proc and proc.poll() is None:
                proc.kill()
                job["status"] = "TERMINATED"
                job["return_code"] = -9
                job["stage"] = "terminated"
                job["finished_at"] = utc_now()
                write_job(identity.project_id, identity.job_id, job)
                running_jobs.pop(identity.job_id, None)
            return job
        except FileNotFoundError:
            raise error_cls("NOT_FOUND", "job not found", 404)
