from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
from contextlib import ExitStack
from itertools import chain
from pathlib import Path
from typing import Any

from flask import Blueprint, jsonify, request

from api_wire_models import (
    CheckpointCreateRequest,
    CheckpointCreateResponse,
    ErrorEnvelope,
    FileTreeItem,
    FileTreeRequest as FileTreeRequestModel,
    FileTreeResponse,
    JournalAppendRequest,
    JournalAppendResponse,
    JournalEntry,
    JournalReadRequest,
    JournalReadResponse,
    PythonExecRequest,
    ReadManyFileResult,
    ReadManyRequest,
    ReadManyResponse,
    SyncExecRequest,
    SyncExecResponse,
    WaitExecutionRequest,
    WaitExecutionResponse,
    WriteFileRequest,
    WriteFileResponse,
    ZipReadRequest,
    ZipReadResponse,
)
from context_engine import read_file
from control_plane_models import TextWindow
from execution_routes import (
    MAX_OUTPUT_BYTES,
    _finalize,
    _limit_for_wire,
    _read_job,
    _request_optional_positive_int,
    _resolve_cwd,
    _tail_text,
    ExecutionRequestError,
    submit_execution_job,
)
from shared_core import ensure_parent, get_project_root, init_project_layout, journal_path_for, require_valid_api_key, sha256_file, utc_now

power_bp = Blueprint("power", __name__, url_prefix="")


def _bounded_zip_entry_text(zf: zipfile.ZipFile, name: str, max_entry_bytes: int) -> SyncExecResponse:
    info = zf.getinfo(name)
    if info.is_dir():
        return {"ok": False, "entry_name": str(name), "error": "entry is a directory"}
    with zf.open(info, "r") as handle:
        data = handle.read(max_entry_bytes + 1)
    truncated = len(data) > max_entry_bytes or info.file_size > max_entry_bytes
    if truncated:
        data = data[:max_entry_bytes]
    return {
        "ok": True,
        "entry_name": str(name),
        "bytes": len(data),
        "original_bytes": info.file_size,
        "truncated": truncated,
        "content": data.decode("utf-8", errors="replace"),
    }


def _error(error_code: str, message: str, status: int, **extra: Any):
    return jsonify(ErrorEnvelope(ok=False, error_code=error_code, message=message, time=utc_now(), extra=extra).to_dict()), status


def _auth():
    try:
        require_valid_api_key(request.headers)
        return None
    except Exception as e:
        return _error("UNAUTHORIZED", str(e), 401)


def _json():
    d = request.get_json(silent=False, force=True)
    if not isinstance(d, dict):
        raise ValueError("JSON request body must be an object")
    return d


def _read_output_with_limit(path: Path, max_bytes: int | None) -> tuple[str, bool, int]:
    if not path.exists():
        return "", False, 0
    size = path.stat().st_size
    if max_bytes is None:
        return path.read_text(encoding="utf-8", errors="replace"), False, size
    text, truncated = _tail_text(path, max_bytes)
    return text, truncated, size


def _stream_exec_to_files(
    project_id: str,
    command: list[str],
    cwd_rel: str | None,
    timeout_seconds: int | None,
    stdout_max_bytes: int | None,
    stderr_max_bytes: int | None,
    env: dict[str, str],
) -> dict[str, Any]:
    cwd = _resolve_cwd(project_id, cwd_rel)
    run_root = cwd / ".pcmmad_sync_runs"
    run_root.mkdir(parents=True, exist_ok=True)
    run_id = f"sync-{uuid.uuid4().hex[:12]}"
    stdout_path = run_root / f"{run_id}.stdout.log"
    stderr_path = run_root / f"{run_id}.stderr.log"
    started = time.time()
    with ExitStack() as stack:
        stdout_handle = stack.enter_context(stdout_path.open("wb"))
        stderr_handle = stack.enter_context(stderr_path.open("wb"))
        proc = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=stdout_handle,
            stderr=stderr_handle,
            shell=False,
        )
        try:
            return_code = proc.wait(timeout=timeout_seconds)
            status = "COMPLETED" if return_code == 0 else "FAILED"
        except subprocess.TimeoutExpired:
            proc.kill()
            return_code = -9
            status = "TIMEOUT"
    stdout_text, stdout_truncated, stdout_bytes = _read_output_with_limit(stdout_path, stdout_max_bytes)
    stderr_text, stderr_truncated, stderr_bytes = _read_output_with_limit(stderr_path, stderr_max_bytes)
    stdout_window = TextWindow(mode="tail" if stdout_max_bytes is not None else "all", file_size=stdout_bytes, requested_bytes=stdout_max_bytes, returned_bytes=len(stdout_text.encode("utf-8")))
    stderr_window = TextWindow(mode="tail" if stderr_max_bytes is not None else "all", file_size=stderr_bytes, requested_bytes=stderr_max_bytes, returned_bytes=len(stderr_text.encode("utf-8")))
    return SyncExecResponse(
        ok=True,
        status=status,
        return_code=return_code,
        stdout=stdout_text,
        stderr=stderr_text,
        stdout_truncated=stdout_truncated,
        stderr_truncated=stderr_truncated,
        stdout_bytes=stdout_bytes,
        stderr_bytes=stderr_bytes,
        stdout_path=str(stdout_path),
        stderr_path=str(stderr_path),
        stdout_window=stdout_window.to_dict(),
        stderr_window=stderr_window.to_dict(),
        duration_ms=int((time.time() - started) * 1000),
    )


def _sync_exec(project_id: str, command: list[str], cwd_rel: str | None, timeout_seconds: int | None, stdout_max_bytes: int | None, stderr_max_bytes: int | None, env: dict[str, str]):
    return _stream_exec_to_files(project_id, command, cwd_rel, timeout_seconds, stdout_max_bytes, stderr_max_bytes, env)


@power_bp.post("/run")
def run_sync():
    ae = _auth()
    if ae:
        return ae
    try:
        req = SyncExecRequest.from_json(_json())
        timeout_seconds = _request_optional_positive_int(req.timeout_seconds, 30, minimum=1)
        stdout_max_bytes = _request_optional_positive_int(req.stdout_max_bytes, 131072, minimum=1024, maximum=MAX_OUTPUT_BYTES)
        stderr_max_bytes = _request_optional_positive_int(req.stderr_max_bytes, 131072, minimum=1024, maximum=MAX_OUTPUT_BYTES)
        full_command = req.command + req.args
        env = {**os.environ.copy(), **req.env}
        return jsonify(_sync_exec(req.project_id, full_command, req.cwd, timeout_seconds, stdout_max_bytes, stderr_max_bytes, env).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except ExecutionRequestError as e:
        return _error(e.error_code, e.message, e.status, **e.extra)
    except Exception as e:
        return _error("RUN_SYNC_FAILED", str(e), 500)


@power_bp.post("/run/python")
def run_python():
    ae = _auth()
    if ae:
        return ae
    try:
        req = PythonExecRequest.from_json(_json())
        if not req.code:
            return _error("BAD_REQUEST", "code is required", 400)
        timeout_seconds = _request_optional_positive_int(req.timeout_seconds, 60, minimum=1)
        stdout_max_bytes = _request_optional_positive_int(req.stdout_max_bytes, 262144, minimum=1024, maximum=MAX_OUTPUT_BYTES)
        stderr_max_bytes = _request_optional_positive_int(req.stderr_max_bytes, 262144, minimum=1024, maximum=MAX_OUTPUT_BYTES)
        _resolve_cwd(req.project_id, req.cwd)
        with tempfile.NamedTemporaryFile("w", suffix=".py", encoding="utf-8", delete=False) as tmp:
            tmp.write(req.code)
            tmp_path = Path(tmp.name)
        try:
            env = {**os.environ.copy(), **req.env, "PYTHONIOENCODING": "utf-8"}
            result = _stream_exec_to_files(req.project_id, [sys.executable, str(tmp_path)], req.cwd, timeout_seconds, stdout_max_bytes, stderr_max_bytes, env)
            return jsonify(result.to_dict())
        finally:
            tmp_path.unlink(missing_ok=True)
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("RUN_PYTHON_FAILED", str(e), 500)


@power_bp.post("/project/files/read_many")
def read_many_project_files():
    ae = _auth()
    if ae:
        return ae
    try:
        req = ReadManyRequest.from_json(_json())
        max_bytes_each = _request_optional_positive_int(req.max_bytes_each, 50000, minimum=1)
        root = get_project_root(req.project_id)
        files = {}
        error_count = 0
        for path in req.paths:
            try:
                result = read_file(path=path, base_root=str(root), max_bytes=(max_bytes_each or 10**12))
                files[path] = ReadManyFileResult(
                    content=result.get("content", ""),
                    size_bytes=result.get("size_bytes", 0),
                    truncated=result.get("truncated", False),
                ).to_dict()
            except Exception as e:
                files[path] = ReadManyFileResult(error=str(e), truncated=False, size_bytes=0).to_dict()
                error_count += 1
        return jsonify(ReadManyResponse(ok=True, files=files, read_count=len(req.paths) - error_count, error_count=error_count).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("READ_MANY_FAILED", str(e), 500)


@power_bp.post("/project/files/write")
def write_project_file():
    ae = _auth()
    if ae:
        return ae
    try:
        req = WriteFileRequest.from_json(_json())
        if not req.project_id or not req.path:
            return _error("BAD_REQUEST", "project_id and path are required", 400)
        root = init_project_layout(req.project_id)
        target = (root / req.path).resolve()
        if root.resolve() not in [target, *target.parents]:
            return _error("BAD_PATH", "path escapes project root", 400)
        if req.mode not in {"overwrite", "append", "create_only"}:
            return _error("BAD_REQUEST", "mode must be overwrite, append, or create_only", 400)
        if req.mode == "create_only" and target.exists():
            return _error("ALREADY_EXISTS", "file exists and mode=create_only", 409)
        ensure_parent(target)
        existed_before = target.exists()
        if req.mode == "append":
            with target.open("a", encoding=req.encoding) as handle:
                handle.write(req.content)
        else:
            target.write_text(req.content, encoding=req.encoding)
        return jsonify({
            "ok": True,
            "project_id": req.project_id,
            "path": req.path,
            "absolute_path": str(target),
            "bytes_written": target.stat().st_size,
            "created": not existed_before,
            "sha256": sha256_file(target),
            "bytes": target.stat().st_size,
            "time": utc_now(),
        })
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("WRITE_FILE_FAILED", str(e), 500)


@power_bp.post("/zip/read")
def read_zip_entries():
    ae = _auth()
    if ae:
        return ae
    try:
        req = ZipReadRequest.from_json(_json())
        if not req.zip_path:
            return _error("BAD_REQUEST", "zip_path is required", 400)
        if req.project_id and not Path(req.zip_path).is_absolute():
            base = get_project_root(req.project_id)
            zip_path = (base / req.zip_path).resolve()
            if base.resolve() not in [zip_path, *zip_path.parents]:
                return _error("BAD_PATH", "zip_path escapes project root", 400)
        else:
            zip_path = Path(req.zip_path).resolve()
        if not zip_path.exists():
            return _error("NOT_FOUND", "zip file not found", 404)
        max_entry_bytes = _request_optional_positive_int(req.max_entry_bytes, 65536, minimum=1024)
        with zipfile.ZipFile(zip_path, "r") as zf:
            listing = [{"name": i.filename, "file_size": i.file_size, "compress_size": i.compress_size, "is_dir": i.is_dir()} for i in zf.infolist()]
            contents = {}
            for name in req.entries:
                try:
                    contents[str(name)] = _bounded_zip_entry_text(zf, str(name), max_entry_bytes or (2**31 - 1))
                except Exception as e:
                    contents[str(name)] = {"ok": False, "entry_name": str(name), "error": str(e)}
        return jsonify(ZipReadResponse(ok=True, zip_path=str(zip_path), listing=listing, contents=contents).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("ZIP_READ_FAILED", str(e), 500)


@power_bp.post("/project/execution/wait")
def wait_for_project_execution():
    ae = _auth()
    if ae:
        return ae
    try:
        req = WaitExecutionRequest.from_json(_json())
        if not req.project_id or not req.job_id:
            return _error("BAD_REQUEST", "project_id and job_id are required", 400)
        timeout_seconds = _request_optional_positive_int(req.timeout_seconds, 60, minimum=1)
        max_bytes = _request_optional_positive_int(req.max_bytes, 262144, minimum=1024, maximum=MAX_OUTPUT_BYTES)
        deadline = None if timeout_seconds is None else (time.time() + timeout_seconds)
        while deadline is None or time.time() < deadline:
            job = _finalize(req.project_id, req.job_id, _read_job(req.project_id, req.job_id))
            if job.get("status") not in {"RUNNING", "SUBMITTED", "QUEUED", "STARTING"}:
                stdout_text, stdout_truncated = _tail_text(Path(job.get("stdout_path", "")), max_bytes)
                stderr_text, _ = _tail_text(Path(job.get("stderr_path", "")), max_bytes)
                return jsonify(
                    WaitExecutionResponse(
                        ok=True,
                        job_id=req.job_id,
                        status=job.get("status"),
                        timed_out=False,
                        stdout=stdout_text,
                        stderr=stderr_text,
                        return_code=job.get("return_code"),
                        duration_ms=job.get("duration_ms"),
                        stdout_truncated=stdout_truncated,
                        max_bytes=_limit_for_wire(max_bytes),
                    ).to_dict()
                )
            time.sleep(0.5)
        job = _finalize(req.project_id, req.job_id, _read_job(req.project_id, req.job_id))
        return jsonify(
            WaitExecutionResponse(
                ok=True,
                job_id=req.job_id,
                status=job.get("status"),
                timed_out=True,
                stdout="",
                stderr="",
                return_code=job.get("return_code"),
                duration_ms=job.get("duration_ms"),
                stdout_truncated=False,
                max_bytes=_limit_for_wire(max_bytes),
            ).to_dict()
        )
    except FileNotFoundError:
        return _error("NOT_FOUND", "job not found", 404)
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("EXECUTION_WAIT_FAILED", str(e), 500)


def _iter_tree(root: Path, depth: int, include_hidden: bool, exclude_dirs: set[str], extensions: set[str] | None, min_size_bytes: int, limit: int):
    items: list[FileTreeItem] = []
    partial = False
    root = root.resolve()
    base_depth = len(root.parts)
    for path in chain((root,), root.rglob("*")):
        if len(items) >= limit:
            partial = True
            break
        rel = path.relative_to(root).as_posix() if path != root else "."
        cur_depth = len(path.parts) - base_depth
        if cur_depth > depth:
            continue
        name = path.name if path != root else root.name
        if not include_hidden and name.startswith(".") and path != root:
            continue
        if path.is_dir() and name in exclude_dirs and path != root:
            continue
        ext = path.suffix.lower() if path.is_file() else ""
        if extensions and path.is_file() and ext not in extensions:
            continue
        size_bytes = path.stat().st_size if path.exists() and path.is_file() else 0
        if path.is_file() and size_bytes < min_size_bytes:
            continue
        items.append(
            FileTreeItem(
                path=str(path),
                rel_path=rel,
                name=name,
                is_dir=path.is_dir(),
                size_bytes=size_bytes,
                depth=cur_depth,
                extension=ext,
            )
        )
    return items, partial


@power_bp.post("/files/tree")
def get_file_tree():
    ae = _auth()
    if ae:
        return ae
    try:
        req = FileTreeRequestModel.from_json(_json())
        if not req.path:
            return _error("BAD_REQUEST", "path is required", 400)
        if req.project_id and not Path(req.path).is_absolute():
            base = get_project_root(req.project_id)
            root = (base / req.path).resolve()
            if base.resolve() not in [root, *root.parents]:
                return _error("BAD_PATH", "path escapes project root", 400)
        else:
            root = Path(req.path).resolve()
        if not root.exists():
            return _error("NOT_FOUND", "root path not found", 404)
        depth = int(req.depth) if str(req.depth).strip() not in {"0", "-1"} else 10**9
        exclude_dirs = set(req.exclude_dirs or ["__pycache__", ".git", "node_modules", ".venv", ".venv_cuda", "vendor"])
        extensions = {str(x).lower() for x in (req.extensions or [])} if req.extensions else None
        limit = _request_optional_positive_int(req.limit, 500, minimum=1)
        items, partial = _iter_tree(root, depth, req.include_hidden, exclude_dirs, extensions, req.min_size_bytes, limit or 10**9)
        return jsonify(FileTreeResponse(ok=True, root=str(root), count=len(items), partial=partial, items=[item.to_dict() for item in items]).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("FILE_TREE_FAILED", str(e), 500)


@power_bp.post("/project/journal/append")
def append_project_journal():
    ae = _auth()
    if ae:
        return ae
    try:
        req = JournalAppendRequest.from_json(_json())
        entry = JournalEntry(
            time=utc_now(),
            entry_type=req.entry_type,
            title=req.title,
            content=req.content,
            tags=req.tags,
            session_id=req.session_id,
        )
        path = journal_path_for(req.project_id)
        ensure_parent(path)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
        return jsonify(JournalAppendResponse(ok=True, project_id=req.project_id, entry=entry.to_dict(), path=str(path)).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("JOURNAL_APPEND_FAILED", str(e), 500)


@power_bp.post("/project/journal/read")
def read_project_journal():
    ae = _auth()
    if ae:
        return ae
    try:
        req = JournalReadRequest.from_json(_json())
        limit = max(1, min(req.limit, 500))
        path = journal_path_for(req.project_id)
        if not path.exists():
            return jsonify(JournalReadResponse(ok=True, project_id=req.project_id, count=0, entries=[]).to_dict())
        entries: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines()[-limit:]:
            try:
                raw = json.loads(line)
                entry = JournalEntry(
                    time=str(raw.get("time", "")),
                    entry_type=str(raw.get("entry_type", "")),
                    title=str(raw.get("title", "")),
                    content=str(raw.get("content", "")),
                    tags=list(raw.get("tags", [])) if isinstance(raw.get("tags", []), list) else [],
                    session_id=raw.get("session_id"),
                )
                entries.append(entry.to_dict())
            except Exception:
                continue
        return jsonify(JournalReadResponse(ok=True, project_id=req.project_id, count=len(entries), entries=entries).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("JOURNAL_READ_FAILED", str(e), 500)


@power_bp.post("/project/checkpoints/create")
def create_project_checkpoint():
    ae = _auth()
    if ae:
        return ae
    try:
        req = CheckpointCreateRequest.from_json(_json())
        root = get_project_root(req.project_id)
        checkpoint_name = req.checkpoint_name or f"checkpoint_{uuid.uuid4().hex[:8]}"
        out_dir = root / "checkpoints"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"{checkpoint_name}.zip"
        exclude_prefixes = {"checkpoints/", "system/logs/execution/"}
        with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for p in root.rglob("*"):
                if not p.is_file():
                    continue
                rel = p.relative_to(root).as_posix()
                if any(rel.startswith(prefix) for prefix in exclude_prefixes):
                    continue
                zf.write(p, arcname=rel)
        return jsonify(CheckpointCreateResponse(ok=True, project_id=req.project_id, checkpoint_name=checkpoint_name, path=str(out_path), bytes=out_path.stat().st_size, time=utc_now()).to_dict())
    except ValueError as e:
        return _error("BAD_REQUEST", str(e), 400)
    except Exception as e:
        return _error("CHECKPOINT_CREATE_FAILED", str(e), 500)
